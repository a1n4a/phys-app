// Baza vežbi.
// Svaka vežba ima:
//  - opis, korake i postavku kamere
//  - metric(): glavna mera pokreta u stepenima (npr. ugao u ramenu)
//  - start/target: prag početka pokreta i ciljni opseg; hold: koliko sekundi zadržati
//  - checks(): provere pravilnog izvođenja; svaka greška ima poruku i tačke koje se boje crveno
//  - demo: ključni položaji za animiranog demonstratora (koristi se kad nema video snimka)

import { LM, J, mid, dist, angle, trunkLean, fromVertical, lineAngle, angleDiff, clamp, DEG } from './geometry.js';

export const REGIONS = [
  { id: 'vrat', name: 'Vrat' },
  { id: 'ramena', name: 'Ramena' },
  { id: 'ruke', name: 'Ruke i laktovi' },
  { id: 'trup', name: 'Leđa i trup' },
  { id: 'kukovi', name: 'Kukovi' },
  { id: 'kolena', name: 'Kolena i butine' },
  { id: 'stopala', name: 'Skočni zglob i list' },
];

const FULL_FRONT = [LM.lSh, LM.rSh, LM.lHip, LM.rHip, LM.lKn, LM.rKn, LM.lAn, LM.rAn];
const ARMS = [LM.lEl, LM.rEl, LM.lWr, LM.rWr];
const sideReq = (s) => [J(s, 'Sh'), J(s, 'Hip'), J(s, 'Kn'), J(s, 'An'), J(s, 'Heel'), J(s, 'Toe')];

const err = (id, msg, joints) => ({ id, msg, joints });

// Provere sa tolerancijom (ctx.tol, npr. 0.1 = 10 %).
// Granice u vežbama su "idealne"; tolerancija proširuje dozvoljeno odstupanje.
// over:      odstupanje (nagib, razlika...) veće od granice
// under:     odnos (širina ramena...) manji od granice
// bentUnder: ugao zgloba koji treba da bude ispružen (180°) savijen više od granice
const tol = (ctx) => ctx.tol || 0;
const over = (ctx, v, lim) => v > lim * (1 + tol(ctx));
const under = (ctx, v, lim) => v < lim * (1 - tol(ctx));
const bentUnder = (ctx, ang, lim) => (180 - ang) > (180 - lim) * (1 + tol(ctx));

// Podizanje ramena ka ušima (u odnosu na kalibraciju)
function shrug(P, ctx) {
  const r = ctx.refs;
  if (!r.earSh || P[LM.lEar].v < 0.4 || P[LM.rEar].v < 0.4) return null;
  const now = ((P[LM.lSh].y - P[LM.lEar].y) + (P[LM.rSh].y - P[LM.rEar].y)) / 2 / r.torso;
  return under(ctx, now, r.earSh * 0.68)
    ? err('shrug', 'Spustite ramena, ne podižite ih ka ušima', [LM.lSh, LM.rSh])
    : null;
}

export const EXERCISES = [
  // ───────────────────────── RAMENA ─────────────────────────
  {
    id: 'lateral-raise',
    name: 'Bočno podizanje ruku',
    region: 'ramena',
    view: 'front',
    focus: ['upperArms'],
    summary: 'Abdukcija u ramenu do visine ramena. Jača deltoidni mišić i stabilizatore lopatice.',
    steps: [
      'Stanite uspravno, stopala u širini kukova, ruke opuštene pored tela.',
      'Ispruženih laktova podignite obe ruke bočno do visine ramena.',
      'Zadržite kratko, pa polako spustite ruke nazad.',
    ],
    mistakes: ['savijeni laktovi', 'podizanje iznad visine ramena', 'nejednako podizanje ruku', 'naginjanje trupa', 'podizanje ramena ka ušima'],
    placement: 'Licem ka kameri, na 2 do 3 metra, tako da se vidi celo telo i ispružene ruke.',
    cue: 'Podignite ruke bočno do visine ramena',
    tooLow: 'Podignite ruke više, do visine ramena',
    defaultReps: 10,
    start: 30, target: 80, hold: 0, max: 130,
    required: () => [...FULL_FRONT, ...ARMS],
    metric(P) {
      const aL = angle(P[LM.lHip], P[LM.lSh], P[LM.lEl]);
      const aR = angle(P[LM.rHip], P[LM.rSh], P[LM.rEl]);
      return { value: (aL + aR) / 2, aL, aR };
    },
    checks(P, ctx, m) {
      const out = [];
      if (m.value > 25) {
        const eL = angle(P[LM.lSh], P[LM.lEl], P[LM.lWr]);
        const eR = angle(P[LM.rSh], P[LM.rEl], P[LM.rWr]);
        if (bentUnder(ctx, Math.min(eL, eR), 145)) out.push(err('elbow', 'Ispravite laktove', [LM.lEl, LM.rEl]));
        if (over(ctx, m.value, 120)) out.push(err('high', 'Ne podižite ruke iznad visine ramena', [LM.lEl, LM.rEl, LM.lWr, LM.rWr]));
        if (over(ctx, Math.abs(m.aL - m.aR), 25)) out.push(err('asym', 'Podižite obe ruke ravnomerno', [LM.lSh, LM.rSh, LM.lEl, LM.rEl]));
        const s = shrug(P, ctx); if (s) out.push(s);
      }
      if (over(ctx, Math.abs(trunkLean(P) - ctx.refs.lean), 12)) out.push(err('lean', 'Ne naginjite trup, stojte uspravno', [LM.lSh, LM.rSh, LM.lHip, LM.rHip]));
      return out;
    },
    demo: {
      view: 'front',
      frames: [
        { p: { abdL: 8, abdR: 8 }, d: 0.6 },
        { p: { abdL: 88, abdR: 88 }, d: 1.4 },
        { p: { abdL: 88, abdR: 88 }, d: 0.5 },
        { p: { abdL: 8, abdR: 8 }, d: 1.6 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person in plain athletic clothing, front view, full body, neutral studio background, slowly raises both straight arms sideways to shoulder height, holds briefly, lowers them. 3 repetitions, steady camera.',
  },
  {
    id: 'overhead-raise',
    name: 'Podizanje ruku iznad glave',
    region: 'ramena',
    view: 'front',
    focus: ['upperArms', 'trunk'],
    summary: 'Puna abdukcija u ramenu. Vraća pokretljivost ramena posle povrede ili imobilizacije.',
    steps: [
      'Stanite uspravno, ruke pored tela, dlanovi okrenuti napred.',
      'Ispruženih laktova podignite ruke kroz stranu što više iznad glave.',
      'Polako spustite ruke istim putem.',
    ],
    mistakes: ['savijeni laktovi', 'nejednako podizanje ruku', 'naginjanje trupa u stranu umesto pokreta u ramenu'],
    placement: 'Licem ka kameri, na 2 do 3 metra. Kamera mora da vidi i šake kada su iznad glave.',
    cue: 'Podignite ruke kroz stranu iznad glave',
    tooLow: 'Podignite ruke više, iznad glave',
    defaultReps: 8,
    start: 35, target: 145, hold: 0, max: 185,
    required: () => [...FULL_FRONT, ...ARMS],
    metric(P) {
      const aL = angle(P[LM.lHip], P[LM.lSh], P[LM.lEl]);
      const aR = angle(P[LM.rHip], P[LM.rSh], P[LM.rEl]);
      return { value: (aL + aR) / 2, aL, aR };
    },
    checks(P, ctx, m) {
      const out = [];
      if (m.value > 30) {
        const eL = angle(P[LM.lSh], P[LM.lEl], P[LM.lWr]);
        const eR = angle(P[LM.rSh], P[LM.rEl], P[LM.rWr]);
        if (bentUnder(ctx, Math.min(eL, eR), 140)) out.push(err('elbow', 'Držite laktove ispružene', [LM.lEl, LM.rEl]));
        if (over(ctx, Math.abs(m.aL - m.aR), 30)) out.push(err('asym', 'Podižite obe ruke ravnomerno', [LM.lSh, LM.rSh, LM.lEl, LM.rEl]));
      }
      if (over(ctx, Math.abs(trunkLean(P) - ctx.refs.lean), 12)) out.push(err('lean', 'Ne naginjite trup u stranu, pokret je samo u ramenima', [LM.lSh, LM.rSh, LM.lHip, LM.rHip]));
      return out;
    },
    demo: {
      view: 'front',
      frames: [
        { p: { abdL: 8, abdR: 8 }, d: 0.6 },
        { p: { abdL: 165, abdR: 165 }, d: 2.0 },
        { p: { abdL: 165, abdR: 165 }, d: 0.5 },
        { p: { abdL: 8, abdR: 8 }, d: 2.0 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person, front view, full body, neutral background, slowly raises both straight arms out to the sides and up over the head, then lowers them the same way. 3 repetitions.',
  },

  // ───────────────────────── RUKE ─────────────────────────
  {
    id: 'elbow-curl',
    name: 'Pregibanje u laktu',
    region: 'ruke',
    view: 'front',
    focus: ['upperArms', 'forearms'],
    summary: 'Fleksija lakta, sa tegom ili bez njega. Jača biceps i vraća opseg pokreta u laktu.',
    steps: [
      'Stanite uspravno, nadlaktice uz telo, dlanovi okrenuti napred.',
      'Savijte laktove i podignite šake ka ramenima.',
      'Polako ispružite ruke nazad. Nadlaktice se ne pomeraju.',
    ],
    mistakes: ['odvajanje laktova od tela', 'zamah trupom', 'savijanje jedne ruke pre druge'],
    placement: 'Licem ka kameri, blago okrenuti (30 do 45 stepeni), na 2 do 3 metra.',
    cue: 'Savijte laktove, šake ka ramenima',
    tooLow: 'Savijte laktove više, šake do ramena',
    defaultReps: 12,
    start: 35, target: 95, hold: 0, max: 160,
    required: () => [LM.lSh, LM.rSh, LM.lHip, LM.rHip, ...ARMS],
    metric(P) {
      const fL = 180 - angle(P[LM.lSh], P[LM.lEl], P[LM.lWr]);
      const fR = 180 - angle(P[LM.rSh], P[LM.rEl], P[LM.rWr]);
      return { value: (fL + fR) / 2, fL, fR };
    },
    checks(P, ctx, m) {
      const out = [];
      const abd = Math.max(angle(P[LM.lHip], P[LM.lSh], P[LM.lEl]), angle(P[LM.rHip], P[LM.rSh], P[LM.rEl]));
      if (over(ctx, abd, 40)) out.push(err('elbows-out', 'Držite laktove uz telo', [LM.lEl, LM.rEl]));
      if (over(ctx, Math.abs(trunkLean(P) - ctx.refs.lean), 12)) out.push(err('swing', 'Ne zamahujte trupom', [LM.lSh, LM.rSh, LM.lHip, LM.rHip]));
      if (m.value > 25 && over(ctx, Math.abs(m.fL - m.fR), 40)) out.push(err('asym', 'Savijajte obe ruke istovremeno', [LM.lWr, LM.rWr]));
      const s = shrug(P, ctx); if (s) out.push(s);
      return out;
    },
    demo: {
      view: 'front',
      frames: [
        { p: { abdL: 6, abdR: 6, elL: 5, elR: 5 }, d: 0.5 },
        { p: { abdL: 6, abdR: 6, elL: 135, elR: 135 }, d: 1.2 },
        { p: { abdL: 6, abdR: 6, elL: 135, elR: 135 }, d: 0.3 },
        { p: { abdL: 6, abdR: 6, elL: 5, elR: 5 }, d: 1.6 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person, front view turned slightly (30 degrees), full body, neutral background, upper arms kept at the sides, slowly bends both elbows bringing hands to shoulders, then lowers. 3 repetitions.',
  },

  // ───────────────────────── VRAT ─────────────────────────
  {
    id: 'neck-tilt',
    name: 'Naginjanje glave u stranu',
    region: 'vrat',
    view: 'front',
    upperOnly: true,
    focus: ['neck'],
    summary: 'Istezanje bočnih mišića vrata (trapezius, skalenusi). Smanjuje ukočenost vrata.',
    steps: [
      'Stanite ili sedite uspravno, ramena opuštena i spuštena.',
      'Polako nagnite glavu tako da uho ide ka ramenu. Gledajte pravo.',
      'Zadržite 2 sekunde, vratite glavu u sredinu i ponovite na drugu stranu.',
    ],
    mistakes: ['podizanje ramena ka uhu', 'okretanje glave umesto naginjanja', 'naginjanje celog tela'],
    placement: 'Licem ka kameri. Dovoljno je da se vide glava i ramena, može i sedeći.',
    cue: 'Nagnite glavu, uho ka ramenu',
    tooLow: 'Nagnite glavu malo više',
    defaultReps: 6,
    start: 7, target: 18, hold: 2, max: 50,
    required: () => [LM.nose, LM.lEar, LM.rEar, LM.lSh, LM.rSh],
    metric(P, ctx) {
      const ear = lineAngle(P[LM.rEar], P[LM.lEar]);
      const sh = lineAngle(P[LM.rSh], P[LM.lSh]);
      const tilt = angleDiff(ear, sh) - (ctx.refs.neck || 0);
      return { value: Math.abs(tilt), signed: tilt };
    },
    checks(P, ctx) {
      const out = [];
      const sh = lineAngle(P[LM.rSh], P[LM.lSh]);
      if (over(ctx, Math.abs(angleDiff(sh, ctx.refs.shLine)), 10)) out.push(err('shoulder', 'Ramena ostaju spuštena i ravna', [LM.lSh, LM.rSh]));
      const em = mid(P[LM.lEar], P[LM.rEar]);
      const ax = P[LM.lEar].x - P[LM.rEar].x, ay = P[LM.lEar].y - P[LM.rEar].y;
      const len = Math.hypot(ax, ay) || 1e-6;
      const proj = ((P[LM.nose].x - em.x) * ax + (P[LM.nose].y - em.y) * ay) / (len * len);
      if (over(ctx, Math.abs(proj - (ctx.refs.noseProj || 0)), 0.28)) out.push(err('rotate', 'Ne okrećite glavu, gledajte pravo', [LM.nose, LM.lEar, LM.rEar]));
      if (P[LM.lHip].v > 0.5 && P[LM.rHip].v > 0.5 && over(ctx, Math.abs(trunkLean(P) - ctx.refs.lean), 12)) {
        out.push(err('lean', 'Naginje se samo glava, telo miruje', [LM.lSh, LM.rSh]));
      }
      return out;
    },
    demo: {
      view: 'front',
      frames: [
        { p: { head: 0 }, d: 0.5 },
        { p: { head: 26 }, d: 1.4 },
        { p: { head: 26 }, d: 2.0 },
        { p: { head: 0 }, d: 1.4 },
        { p: { head: -26 }, d: 1.4 },
        { p: { head: -26 }, d: 2.0 },
        { p: { head: 0 }, d: 1.4 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person, front view, upper body, neutral background, shoulders relaxed, slowly tilts head so the ear moves toward the shoulder, holds 2 seconds, returns, then the other side.',
  },

  // ───────────────────────── TRUP ─────────────────────────
  {
    id: 'side-bend',
    name: 'Bočno savijanje trupa',
    region: 'trup',
    view: 'front',
    focus: ['trunk'],
    summary: 'Lateralna fleksija kičme. Isteže kvadratni mišić slabine i kose trbušne mišiće.',
    steps: [
      'Stanite uspravno, stopala u širini kukova, ruke pored tela.',
      'Savijte trup u stranu, šaka klizi niz butinu. Kukovi ostaju u mestu.',
      'Zadržite 1 sekundu, vratite se uspravno, pa na drugu stranu.',
    ],
    mistakes: ['pomeranje kukova u stranu', 'rotacija trupa', 'savijanje kolena'],
    placement: 'Licem ka kameri, na 2 do 3 metra, celo telo u kadru.',
    cue: 'Savijte trup u stranu, kukovi miruju',
    tooLow: 'Savijte se malo više u stranu',
    defaultReps: 8,
    start: 6, target: 17, hold: 1, max: 45,
    required: () => FULL_FRONT,
    metric(P, ctx) {
      const lean = trunkLean(P) - ctx.refs.lean;
      return { value: Math.abs(lean), signed: lean };
    },
    checks(P, ctx, m) {
      const out = [];
      const r = ctx.refs;
      const hm = mid(P[LM.lHip], P[LM.rHip]);
      if (over(ctx, Math.abs(hm.x - r.hipMidX), 0.28 * r.torso)) out.push(err('hips', 'Kukovi ostaju u mestu, savijajte se u struku', [LM.lHip, LM.rHip]));
      if (under(ctx, dist(P[LM.lSh], P[LM.rSh]), 0.7 * r.shoulderW)) out.push(err('rotate', 'Ne okrećite trup, savijajte se pravo u stranu', [LM.lSh, LM.rSh]));
      if (bentUnder(ctx, Math.min(angle(P[LM.lHip], P[LM.lKn], P[LM.lAn]), angle(P[LM.rHip], P[LM.rKn], P[LM.rAn])), 155)) {
        out.push(err('knees', 'Kolena ostaju ispružena', [LM.lKn, LM.rKn]));
      }
      if (over(ctx, m.value, 45)) out.push(err('far', 'Ne savijajte se preko granice bola', [LM.lSh, LM.rSh]));
      return out;
    },
    demo: {
      view: 'front',
      frames: [
        { p: { lean: 0 }, d: 0.5 },
        { p: { lean: 22, abdL: 4, abdR: 14, elL: 0 }, d: 1.6 },
        { p: { lean: 22, abdL: 4, abdR: 14 }, d: 1.0 },
        { p: { lean: 0 }, d: 1.4 },
        { p: { lean: -22, abdL: 14, abdR: 4 }, d: 1.6 },
        { p: { lean: -22, abdL: 14, abdR: 4 }, d: 1.0 },
        { p: { lean: 0 }, d: 1.4 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person, front view, full body, neutral background, slowly bends the trunk sideways with the hand sliding down the thigh, hips stay still, holds, returns, then the other side.',
  },

  // ───────────────────────── KUKOVI ─────────────────────────
  {
    id: 'hip-abduction',
    name: 'Bočno podizanje noge',
    region: 'kukovi',
    view: 'front',
    focus: ['hips', 'thighs'],
    summary: 'Abdukcija kuka u stojećem stavu. Jača gluteus medius, važan za stabilnost pri hodu.',
    steps: [
      'Stanite uspravno. Ako treba, pridržite se rukom za stolicu.',
      'Ispruženog kolena podignite jednu nogu u stranu, prsti gledaju napred.',
      'Polako spustite nogu i ponovite drugom nogom.',
    ],
    mistakes: ['naginjanje trupa na suprotnu stranu', 'savijanje kolena', 'previsoko podizanje noge', 'podizanje kuka'],
    placement: 'Licem ka kameri, na 2,5 do 3 metra, stopala moraju biti u kadru.',
    cue: 'Podignite nogu u stranu, trup uspravan',
    tooLow: 'Podignite nogu malo više u stranu',
    defaultReps: 10,
    start: 8, target: 22, hold: 0, max: 60,
    required: () => FULL_FRONT,
    metric(P, ctx) {
      const r = ctx.refs;
      const aL = fromVertical(P[LM.lHip], P[LM.lAn]) - (r.legL || 0);
      const aR = fromVertical(P[LM.rHip], P[LM.rAn]) - (r.legR || 0);
      return aL > aR ? { value: aL, side: 'l' } : { value: aR, side: 'r' };
    },
    checks(P, ctx, m) {
      const out = [];
      if (over(ctx, Math.abs(trunkLean(P) - ctx.refs.lean), 12)) out.push(err('lean', 'Ne naginjite trup u stranu, stojte uspravno', [LM.lSh, LM.rSh, LM.lHip, LM.rHip]));
      if (m.value > 8) {
        const s = m.side;
        if (bentUnder(ctx, angle(P[J(s, 'Hip')], P[J(s, 'Kn')], P[J(s, 'An')]), 150)) out.push(err('knee', 'Ispravite koleno noge koju podižete', [J(s, 'Kn')]));
        if (over(ctx, m.value, 50)) out.push(err('high', 'Ne podižite nogu previsoko', [J(s, 'An')]));
        const tilt = angleDiff(lineAngle(P[LM.rHip], P[LM.lHip]), ctx.refs.hipLine);
        if (over(ctx, Math.abs(tilt), 12)) out.push(err('hike', 'Karlica ostaje ravna, ne podižite kuk', [LM.lHip, LM.rHip]));
      }
      return out;
    },
    demo: {
      view: 'front',
      frames: [
        { p: { abdL: 20, abdR: 20 }, d: 0.5 },
        { p: { abdL: 20, abdR: 20, hAbdR: 30 }, d: 1.3 },
        { p: { abdL: 20, abdR: 20, hAbdR: 30 }, d: 0.4 },
        { p: { abdL: 20, abdR: 20, hAbdR: 0 }, d: 1.3 },
        { p: { abdL: 20, abdR: 20, hAbdL: 30 }, d: 1.3 },
        { p: { abdL: 20, abdR: 20, hAbdL: 30 }, d: 0.4 },
        { p: { abdL: 20, abdR: 20, hAbdL: 0 }, d: 1.3 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person, front view, full body, neutral background, standing tall, slowly lifts one straight leg out to the side about 30 degrees, lowers it, then the other leg. Trunk stays upright.',
  },
  {
    id: 'knee-raise',
    name: 'Podizanje kolena u mestu',
    region: 'kukovi',
    view: 'front',
    focus: ['hips', 'thighs'],
    summary: 'Fleksija kuka naizmenično. Jača pregibače kuka i vežba ravnotežu.',
    steps: [
      'Stanite uspravno, ruke pored tela ili na kukovima.',
      'Podignite jedno koleno ka grudima, do visine kuka ako možete.',
      'Spustite nogu i podignite drugo koleno. Trup ostaje uspravan.',
    ],
    mistakes: ['naginjanje trupa', 'savijanje noge na kojoj stojite', 'prenisko podizanje kolena'],
    placement: 'Licem ka kameri, na 2,5 do 3 metra, celo telo u kadru.',
    cue: 'Podignite koleno do visine kuka',
    tooLow: 'Podignite koleno više',
    defaultReps: 12,
    start: 25, target: 60, hold: 0, max: 130,
    required: () => FULL_FRONT,
    metric(P, ctx) {
      const r = ctx.refs;
      const f = (s, ref) => Math.acos(clamp((P[J(s, 'Kn')].y - P[J(s, 'Hip')].y) / (ref || 0.2), -1, 1)) * DEG;
      const fL = f('l', r.thighL), fR = f('r', r.thighR);
      return fL > fR ? { value: fL, side: 'l' } : { value: fR, side: 'r' };
    },
    checks(P, ctx, m) {
      const out = [];
      if (over(ctx, Math.abs(trunkLean(P) - ctx.refs.lean), 12)) out.push(err('lean', 'Držite trup uspravno', [LM.lSh, LM.rSh, LM.lHip, LM.rHip]));
      if (m.value > 25) {
        const st = m.side === 'l' ? 'r' : 'l';
        if (bentUnder(ctx, angle(P[J(st, 'Hip')], P[J(st, 'Kn')], P[J(st, 'An')]), 152)) out.push(err('support', 'Noga na kojoj stojite treba da bude ispružena', [J(st, 'Kn')]));
      }
      return out;
    },
    demo: {
      view: 'front',
      frames: [
        { p: { abdL: 8, abdR: 8 }, d: 0.4 },
        { p: { abdL: 8, abdR: 8, hFlexR: 85, kneeR: 90 }, d: 1.0 },
        { p: { abdL: 8, abdR: 8, hFlexR: 85, kneeR: 90 }, d: 0.3 },
        { p: { abdL: 8, abdR: 8 }, d: 1.0 },
        { p: { abdL: 8, abdR: 8, hFlexL: 85, kneeL: 90 }, d: 1.0 },
        { p: { abdL: 8, abdR: 8, hFlexL: 85, kneeL: 90 }, d: 0.3 },
        { p: { abdL: 8, abdR: 8 }, d: 1.0 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person, front view, full body, neutral background, marching in place slowly, lifting each knee to hip height, trunk upright.',
  },

  // ───────────────────────── KOLENA ─────────────────────────
  {
    id: 'squat',
    name: 'Čučanj do stolice',
    region: 'kolena',
    view: 'side',
    focus: ['thighs', 'hips'],
    summary: 'Kontrolisani čučanj. Jača kvadriceps i gluteuse, osnova za ustajanje i penjanje uz stepenice.',
    steps: [
      'Stanite bočno prema kameri, stopala u širini kukova, ruke ispred sebe.',
      'Gurnite kukove unazad i savijte kolena kao da sedate na stolicu.',
      'Spustite se dok butine ne budu skoro paralelne sa podom, pa se uspravite.',
    ],
    mistakes: ['preveliko naginjanje trupa napred', 'kolena idu daleko ispred prstiju', 'odizanje peta'],
    placement: 'Bočno prema kameri (profil), na 2,5 do 3 metra, stopala u kadru.',
    cue: 'Kukovi unazad, spustite se kao na stolicu',
    tooLow: 'Spustite se malo dublje',
    defaultReps: 10,
    start: 25, target: 70, hold: 0, max: 140,
    required: (ctx) => sideReq(ctx.side),
    metric(P, ctx) {
      const s = ctx.side;
      return { value: 180 - angle(P[J(s, 'Hip')], P[J(s, 'Kn')], P[J(s, 'An')]) };
    },
    checks(P, ctx, m) {
      const out = [];
      const s = ctx.side, r = ctx.refs;
      const sh = P[J(s, 'Sh')], hip = P[J(s, 'Hip')], kn = P[J(s, 'Kn')], toe = P[J(s, 'Toe')], heel = P[J(s, 'Heel')];
      if (m.value > 20) {
        if (over(ctx, fromVertical(hip, sh), 55)) out.push(err('lean', 'Podignite grudi, ne naginjite se previše napred', [J(s, 'Sh'), J(s, 'Hip')]));
        const facing = Math.sign(toe.x - heel.x) || 1;
        if (over(ctx, (kn.x - toe.x) * facing, 0.45 * (r.thighS || 0.2))) out.push(err('knee', 'Gurnite kukove unazad, kolena ne idu daleko ispred prstiju', [J(s, 'Kn'), J(s, 'Toe')]));
        if (over(ctx, m.value, 130)) out.push(err('deep', 'Ne spuštajte se preduboko', [J(s, 'Hip')]));
      }
      if (over(ctx, (toe.y - heel.y) - (r.footDy || 0), 0.4 * (r.foot || 0.05))) out.push(err('heel', 'Pete ostaju na podu', [J(s, 'Heel')]));
      return out;
    },
    demo: {
      view: 'side',
      frames: [
        { p: { a: 70 }, d: 0.5 },
        { p: { a: 85, s: 32, t: 75, r: 38 }, d: 1.8 },
        { p: { a: 85, s: 32, t: 75, r: 38 }, d: 0.4 },
        { p: { a: 70 }, d: 1.5 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person in side profile, full body, neutral background, arms reaching forward, slowly squats by pushing hips back as if sitting on a chair, thighs nearly parallel, heels on the floor, then stands up. 3 repetitions.',
  },

  // ───────────────────────── STOPALA ─────────────────────────
  {
    id: 'calf-raise',
    name: 'Podizanje na prste',
    region: 'stopala',
    view: 'side',
    focus: ['calves'],
    summary: 'Plantarna fleksija stopala. Jača mišiće lista i Ahilovu tetivu, pomaže ravnoteži.',
    steps: [
      'Stanite bočno prema kameri, stopala u širini kukova. Možete se pridržati za stolicu.',
      'Podignite se na prste što više možete, kolena ostaju ispružena.',
      'Zadržite 1 sekundu i polako spustite pete na pod.',
    ],
    mistakes: ['savijanje kolena', 'naginjanje tela napred', 'prenisko podizanje peta'],
    placement: 'Bočno prema kameri, na oko 2 metra. Stopala moraju jasno da se vide.',
    cue: 'Podignite se na prste',
    tooLow: 'Podignite pete više',
    defaultReps: 12,
    start: 6, target: 16, hold: 1, max: 60,
    required: (ctx) => sideReq(ctx.side),
    metric(P, ctx) {
      const s = ctx.side, r = ctx.refs;
      const heel = P[J(s, 'Heel')], toe = P[J(s, 'Toe')];
      const a = Math.asin(clamp((toe.y - heel.y) / (r.foot || dist(heel, toe) || 0.05), -1, 1)) * DEG;
      return { value: a - (r.footAngle || 0) };
    },
    checks(P, ctx) {
      const out = [];
      const s = ctx.side;
      if (bentUnder(ctx, angle(P[J(s, 'Hip')], P[J(s, 'Kn')], P[J(s, 'An')]), 155)) out.push(err('knee', 'Držite kolena ispružena', [J(s, 'Kn')]));
      if (over(ctx, fromVertical(P[J(s, 'Hip')], P[J(s, 'Sh')]), 15)) out.push(err('lean', 'Ne naginjite se napred, telo je pravo', [J(s, 'Sh'), J(s, 'Hip')]));
      return out;
    },
    demo: {
      view: 'side',
      frames: [
        { p: { h: 0 }, d: 0.5 },
        { p: { h: 32 }, d: 1.0 },
        { p: { h: 32 }, d: 1.0 },
        { p: { h: 0 }, d: 1.3 },
      ],
    },
    videoPrompt: 'Physiotherapy demo: a person in side profile, full body, neutral background, slowly rises onto the toes with straight knees, holds one second, lowers heels. 3 repetitions.',
  },
];

export const byId = (id) => EXERCISES.find((e) => e.id === id);
