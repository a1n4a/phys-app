﻿# Pravi FizioKamera.apk od web aplikacije (..\fizio-app) bez Android Studio-a i Gradle-a.
# Pokretanje:  powershell -ExecutionPolicy Bypass -File build-apk.ps1 [-Server https://adresa-servera]
# Potrebno: JDK (javac, keytool) i Android SDK (platforms;android-34, build-tools;34.0.0).
param(
  [string]$Server = '',
  [string]$WebApp = (Join-Path (Split-Path -Parent $PSScriptRoot) 'fizio-app'),
  [string]$Sdk = (Join-Path $env:USERPROFILE 'Android\Sdk'),
  [string]$Jdk = 'C:\Program Files\Java\jdk-19',
  [string]$Version = '1.0',
  [int]$VersionCode = 1
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$bt = Join-Path $Sdk 'build-tools\34.0.0'
$androidJar = Join-Path $Sdk 'platforms\android-34\android.jar'
$env:JAVA_HOME = $Jdk
$env:PATH = "$Jdk\bin;$env:PATH"
$build = Join-Path $root 'build'

function Step($m) { Write-Host "== $m" }
function Run($exe, [string[]]$a) { & $exe @a; if ($LASTEXITCODE -ne 0) { throw "$exe nije uspeo (kod $LASTEXITCODE)" } }

Step 'Čišćenje'
if (Test-Path $build) { Remove-Item -Recurse -Force $build }
New-Item -ItemType Directory -Force "$build\assets\www", "$build\gen", "$build\classes", "$build\dex" | Out-Null

Step 'Kopiranje web aplikacije u assets/www'
# bez serverskih delova (baza, ključevi, PowerShell server, AI šabloni)
$skip = @('data', 'ai', 'start.ps1', 'README.md')
Get-ChildItem $WebApp | Where-Object { $skip -notcontains $_.Name } | Copy-Item -Destination "$build\assets\www" -Recurse
if ($Server) {
  $cfg = "export const DEFAULT_SERVER = '$($Server.TrimEnd('/'))';`n"
  [IO.File]::WriteAllText("$build\assets\www\js\app-config.js", $cfg, (New-Object Text.UTF8Encoding $false))
}

Step 'Resursi (aapt2)'
Run "$bt\aapt2.exe" @('compile', '--dir', "$root\res", '-o', "$build\res.zip")
Run "$bt\aapt2.exe" @('link', '-I', $androidJar, '--manifest', "$root\AndroidManifest.xml", '-o', "$build\base.apk",
  "$build\res.zip", '--java', "$build\gen", '--min-sdk-version', '24', '--target-sdk-version', '34',
  '--version-code', "$VersionCode", '--version-name', $Version, '--auto-add-overlay')

Step 'Java (javac)'
$srcs = @(Get-ChildItem "$root\src", "$build\gen" -Recurse -Filter *.java | ForEach-Object { $_.FullName })
Run "$Jdk\bin\javac.exe" (@('-nowarn', '-Xlint:-options', '-source', '8', '-target', '8', '-encoding', 'UTF-8', '-bootclasspath', $androidJar, '-d', "$build\classes") + $srcs)

Step 'DEX (d8)'
$classes = @(Get-ChildItem "$build\classes" -Recurse -Filter *.class | ForEach-Object { $_.FullName })
Run "$bt\d8.bat" (@('--release', '--min-api', '24', '--lib', $androidJar, '--output', "$build\dex") + $classes)

Step 'Pakovanje APK-a'
Copy-Item "$build\base.apk" "$build\unsigned.apk"
Push-Location "$build\dex"
Run "$bt\aapt.exe" @('add', "$build\unsigned.apk", 'classes.dex')
Pop-Location
# fajlovi aplikacije: putanje u APK-u moraju imati kose crte "/" (aapt2 -A na Windows-u upisuje "\")
Push-Location $build
$assetFiles = @(Get-ChildItem "$build\assets" -Recurse -File | ForEach-Object { $_.FullName.Substring($build.Length + 1).Replace('\', '/') })
Run "$bt\aapt.exe" (@('add', "$build\unsigned.apk") + $assetFiles) | Out-Null
Pop-Location
Run "$bt\zipalign.exe" @('-p', '-f', '4', "$build\unsigned.apk", "$build\aligned.apk")

Step 'Potpisivanje'
$ks = Join-Path $root 'keystore\fiziokamera.jks'
if (-not (Test-Path $ks)) {
  New-Item -ItemType Directory -Force (Split-Path $ks) | Out-Null
  Run "$Jdk\bin\keytool.exe" @('-genkeypair', '-keystore', $ks, '-alias', 'fiziokamera', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
    '-storepass', 'fiziokamera', '-keypass', 'fiziokamera', '-dname', 'CN=FizioKamera, O=FizioKamera prototip, C=RS')
}
$out = Join-Path $root 'FizioKamera.apk'
Run "$bt\apksigner.bat" @('sign', '--ks', $ks, '--ks-key-alias', 'fiziokamera', '--ks-pass', 'pass:fiziokamera', '--key-pass', 'pass:fiziokamera', '--out', $out, "$build\aligned.apk")
Run "$bt\apksigner.bat" @('verify', $out)
Step "Gotovo: $out ($([math]::Round((Get-Item $out).Length / 1MB, 1)) MB)"
