# Video snimci vežbi

Aplikacija uz svaku vežbu prikazuje animiranog demonstratora koji je napravljen u kodu.
Kada za neku vežbu postoji pravi snimak u ovom folderu, aplikacija prikazuje snimak umesto animacije.
Snimci se učitavaju iz same aplikacije, bez spoljnih linkova.

## Kako se dodaje snimak

1. Napravite kratak snimak (5–15 s, MP4 ili WebM, najbolje 720p, bez zvuka) i stavite ga u ovaj folder.
2. U `videos.json` upišite koji fajl pripada kojoj vežbi:

```json
{
  "lateral-raise": "lateral-raise.mp4",
  "squat": "squat.mp4"
}
```

Oznake vežbi: `lateral-raise`, `overhead-raise`, `elbow-curl`, `neck-tilt`, `side-bend`,
`hip-abduction`, `knee-raise`, `squat`, `calf-raise`.

## Generisanje AI snimaka

Snimke sa AI osobom možete napraviti alatom za generisanje videa (npr. Google Veo, Runway, Kling, Sora).
Kao referencu koristite snimke fizioterapeuta, a u alat upišite opis vežbe. Opisi (promptovi) za svaku vežbu
nalaze se u `js/exercises.js`, u polju `videoPrompt`. Primer za bočno podizanje ruku:

> Physiotherapy demo: a person in plain athletic clothing, front view, full body, neutral studio background,
> slowly raises both straight arms sideways to shoulder height, holds briefly, lowers them. 3 repetitions, steady camera.

Saveti:
- Ugao kamere na snimku treba da bude isti kao što aplikacija traži od korisnika (spreda ili sa strane).
- Ceo pokret treba da se vidi, bez rezova. Snimak se pušta u petlji, pa neka počinje i završava se u istom položaju.
- Proverite da AI snimak pokazuje pravilnu tehniku. Generisani snimci ponekad imaju greške u pokretu.
- Pre objavljivanja proverite licencu alata i prava na snimke koje ste koristili kao uzor.
