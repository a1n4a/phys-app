// Čitanje slikanog izveštaja fizioterapeuta (OCR na uređaju, Tesseract.js) i predlog vežbi.
// Predlog se pravi po ključnim rečima (dijagnoza, deo tela) i nije zamena za odluku fizioterapeuta.

const TESS_URL = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';

let tessPromise = null;
function loadTesseract() {
  if (window.Tesseract) return Promise.resolve(window.Tesseract);
  if (!tessPromise) {
    tessPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = TESS_URL;
      s.onload = () => resolve(window.Tesseract);
      s.onerror = () => { tessPromise = null; reject(new Error('tesseract')); };
      document.head.appendChild(s);
    });
  }
  return tessPromise;
}

// Prepoznaje tekst na slici (latinica, ćirilica, engleski)
export async function recognize(file, onProgress) {
  const T = await loadTesseract();
  const opts = { logger: (m) => { if (m.status === 'recognizing text' && onProgress) onProgress(m.progress); } };
  let worker;
  try { worker = await T.createWorker(['srp_latn', 'srp', 'eng'], 1, opts); }
  catch { worker = await T.createWorker('eng', 1, opts); }   // ako jezički paketi za srpski nisu dostupni
  try {
    const { data } = await worker.recognize(file);
    return data.text || '';
  } finally {
    await worker.terminate();
  }
}

// ── Scan-to-Plan: prepoznavanje NAZIVA već propisanih vežbi i doziranja ──
// (ne zaključuje terapiju iz dijagnoze; terapeut proverava i odobrava)
const ALIASES = {
  'lateral-raise': ['bocno podizanje ruku', 'abdukcija ramena', 'abdukcija u ramenu', 'odizanje ruku u stranu', 'lateral raise', 'lateral arm raise', 'shoulder abduction'],
  'overhead-raise': ['podizanje ruku iznad glave', 'fleksija ramena', 'elevacija ruku', 'overhead raise', 'overhead arm raise', 'shoulder flexion'],
  'elbow-curl': ['pregibanje u laktu', 'fleksija lakta', 'fleksija u laktu', 'biceps', 'elbow curl', 'elbow flexion'],
  'neck-tilt': ['naginjanje glave', 'lateralna fleksija vrata', 'istezanje vrata', 'neck tilt', 'neck side tilt', 'lateral neck'],
  'side-bend': ['bocno savijanje trupa', 'bocno savijanje', 'lateralna fleksija trupa', 'otklon trupa', 'side bend', 'trunk side bend'],
  'hip-abduction': ['bocno podizanje noge', 'abdukcija kuka', 'odizanje noge u stranu', 'hip abduction', 'side leg raise'],
  'knee-raise': ['podizanje kolena', 'marsiranje', 'fleksija kuka', 'knee raise', 'marching', 'hip flexion'],
  'squat': ['cucanj', 'mini cucanj', 'ustajanje sa stolice', 'squat', 'sit to stand', 'chair squat'],
  'calf-raise': ['podizanje na prste', 'propinjanje na prste', 'plantarna fleksija', 'calf raise', 'heel raise'],
};

export function parsePlan(text) {
  const lines = text.split(/\n|;|•/).map((l) => normalize(l).trim()).filter(Boolean);
  const items = [];
  for (const line of (lines.length ? lines : [normalize(text)])) {
    for (const [exId, names] of Object.entries(ALIASES)) {
      const hit = names.find((nm) => line.includes(nm));
      if (!hit || items.some((i) => i.exId === exId)) continue;
      const m = line.match(/(\d{1,2})\s*[x×]\s*(\d{1,2})/);
      const r = line.match(/(\d{1,2})\s*(ponavlj|rep)/);
      const s = line.match(/(\d{1,2})\s*(serij|set)/);
      items.push({
        exId, line: hit,
        sets: m ? Number(m[1]) : s ? Number(s[1]) : null,
        reps: m ? Number(m[2]) : r ? Number(r[1]) : null,
      });
    }
  }
  return items;
}

// ── analiza teksta ──
const CYR = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', ђ: 'dj', е: 'e', ж: 'z', з: 'z', и: 'i', ј: 'j', к: 'k', л: 'l', љ: 'lj', м: 'm', н: 'n', њ: 'nj', о: 'o', п: 'p', р: 'r', с: 's', т: 't', ћ: 'c', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'c', џ: 'dz', ш: 's' };
export function normalize(text) {
  return text.toLowerCase()
    .replace(/[а-џ]/g, (c) => CYR[c] ?? c)
    .replace(/[čć]/g, 'c').replace(/š/g, 's').replace(/ž/g, 'z').replace(/đ/g, 'dj')
    .replace(/\s+/g, ' ');
}

// Pravila: ključne reči (bez dijakritika) -> vežbe
const RULES = [
  { area: 'neck', words: ['vrat', 'cervik', 'tortikol', 'torticol', 'neck', 'cervical', 'trapez', 'whiplash'], ex: ['neck-tilt'] },
  { area: 'shoulder', words: ['rame', 'ramen', 'humer', 'impingement', 'periartrit', 'periarthrit', 'rotator', 'zamrznut', 'smrznut', 'frozen', 'adheziv', 'shoulder', 'supraspinat', 'deltoid', 'skapul', 'lopatic'], ex: ['lateral-raise', 'overhead-raise'] },
  { area: 'elbow', words: ['lakat', 'lakt', 'epikondil', 'epicondyl', 'teniski', 'tennis elbow', 'golfer', 'elbow', 'biceps', 'podlakt', 'radijus', 'radius'], ex: ['elbow-curl'] },
  { area: 'back', words: ['lumbal', 'lumbag', 'krsta', 'ledj', 'diskus', 'discus', 'hernij', 'hernia', 'skolioz', 'scolios', 'kicm', 'spondil', 'spondyl', 'lumbar', 'back pain', 'spine', 'isijas', 'ishijas', 'sciatica', 'lds'], ex: ['side-bend', 'knee-raise'] },
  { area: 'hip', words: ['kuk', 'koks', 'coxa', 'coxarthr', 'trohanter', 'trochanter', 'hip', 'glute', 'glutea', 'tep kuka'], ex: ['hip-abduction', 'knee-raise'] },
  { area: 'knee', words: ['kolen', 'gonartr', 'gonarthr', 'menisk', 'menisc', 'acl', 'lca', 'ukrsten', 'patel', 'knee', 'kvadriceps', 'quadriceps', 'tep kolena'], ex: ['squat', 'knee-raise'] },
  { area: 'ankle', words: ['skocn', 'glezanj', 'gleznj', 'ahil', 'achill', 'uganuc', 'distorz', 'stopal', 'ankle', 'calf', 'plantar', 'potkolen'], ex: ['calf-raise'] },
  { area: 'balance', words: ['ravnotez', 'balance', 'padov', 'fall risk', 'vrtoglav'], ex: ['calf-raise', 'knee-raise'] },
];

// Upozorenja: stvari zbog kojih predlog treba proveriti sa fizioterapeutom
const CAUTIONS = [
  { key: 'acute', words: ['akutn', 'acute'] },
  { key: 'rest', words: ['mirovanj', 'imobiliz', 'immobiliz', 'bez opterecenj', 'ne opterecivati', 'non weight', 'zabranjen'] },
  { key: 'surgery', words: ['operacij', 'postoperativ', 'post-op', 'postop', 'surgery', 'artroskop', 'arthroscop', 'rekonstrukc', 'reconstruct'] },
  { key: 'prosthesis', words: ['endoprotez', 'proteza', 'tep ', 'arthroplasty', 'replacement'] },
  { key: 'fracture', words: ['frakt', 'prelom', 'fractur'] },
];

// kratke ključne reči (npr. "kuk", "acl") moraju biti na početku reči, da ne bi pogodile deo neke druge reči
// "kuk", "hip", "acl"... su cele reči (sa padežnim nastavcima), ostale kratke reči su početak reči ("koks" -> koksartroza)
const WHOLE = new Set(['kuk', 'hip', 'acl', 'lca', 'lds', 'tep']);
const has = (n, w) => {
  const k = w.trim();
  if (WHOLE.has(k)) return new RegExp(`(^|[^a-z])${k}(a|u|e|i|om|ov|ovi|ova|ove|ima|ama|s)?([^a-z]|$)`).test(n);
  if (k.length <= 4) return new RegExp('(^|[^a-z])' + k).test(n);
  return n.includes(w);
};

export function suggest(text) {
  const n = normalize(text);
  const found = new Map(); // exId -> {areas:Set, words:Set}
  const areas = new Set();
  for (const r of RULES) {
    const hits = r.words.filter((w) => has(n, w));
    if (!hits.length) continue;
    areas.add(r.area);
    for (const id of r.ex) {
      const f = found.get(id) || { areas: new Set(), words: new Set() };
      f.areas.add(r.area); hits.forEach((h) => f.words.add(h));
      found.set(id, f);
    }
  }
  const cautions = CAUTIONS.filter((c) => c.words.some((w) => has(n, w))).map((c) => c.key);

  // posle ugradnje veštačkog kuka: oprez sa savijanjem kuka preko 90°
  const hipProsthesis = areas.has('hip') && cautions.includes('prosthesis');
  const careful = new Set(hipProsthesis ? ['squat', 'knee-raise'] : []);

  // doziranje, npr. "3x10", "3 x 12 ponavljanja"
  const m = n.match(/(\d{1,2})\s*[x×]\s*(\d{1,2})/);
  const dosage = m ? { sets: Number(m[1]), reps: Number(m[2]) } : null;

  const matches = [...found.entries()].map(([exId, f]) => ({
    exId, areas: [...f.areas], words: [...f.words], careful: careful.has(exId),
  }));
  return { matches, cautions, dosage, areas: [...areas] };
}
