// Provera prostora pre vežbe: svetlo, udaljenost, da li pokret staje u kadar, prepreke u zoni pokreta.

// Koliko dodatnog mesta pokret traži, u delovima visine tela:
// side = sa svake strane tela, up = iznad glave
export const SPACE = {
  'lateral-raise': { side: 0.32, up: 0.02 },
  'overhead-raise': { side: 0.3, up: 0.25 },
  'elbow-curl': { side: 0.06, up: 0 },
  'neck-tilt': { side: 0.03, up: 0, upperOnly: true },
  'side-bend': { side: 0.18, up: 0 },
  'hip-abduction': { side: 0.28, up: 0, chair: true },
  'knee-raise': { side: 0.06, up: 0, chair: true },
  'squat': { side: 0.38, up: 0, chair: true },
  'calf-raise': { side: 0.06, up: 0.06, chair: true },
};

// Predmeti koje ne smatramo preprekom (sitni ili nebitni)
const IGNORE = new Set(['person', 'cup', 'cell phone', 'remote', 'book', 'mouse', 'keyboard', 'spoon', 'fork', 'knife', 'toothbrush', 'scissors', 'wine glass', 'clock', 'tie', 'handbag']);

const BODY_IDX = [0, 7, 8, 11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32];

function iou(a, b) {
  const x0 = Math.max(a.x, b.x), y0 = Math.max(a.y, b.y);
  const x1 = Math.min(a.x + a.w, b.x + b.w), y1 = Math.min(a.y + a.h, b.y + b.h);
  const inter = Math.max(0, x1 - x0) * Math.max(0, y1 - y0);
  return inter / (a.w * a.h + b.w * b.h - inter || 1);
}
function overlapFrac(a, env) { // deo predmeta a koji je u zoni env
  const x0 = Math.max(a.x, env.x0), y0 = Math.max(a.y, env.y0);
  const x1 = Math.min(a.x + a.w, env.x1), y1 = Math.min(a.y + a.h, env.y1);
  return (Math.max(0, x1 - x0) * Math.max(0, y1 - y0)) / (a.w * a.h || 1);
}

// Svetlina kadra (0-255), ukupno i u delu gde je osoba
export function measureLight(video, box, cnv) {
  const w = 64, h = 36;
  cnv.width = w; cnv.height = h;
  const c = cnv.getContext('2d', { willReadFrequently: true });
  c.drawImage(video, 0, 0, w, h);
  const d = c.getImageData(0, 0, w, h).data;
  let all = 0, pin = 0, pn = 0, out = 0, on = 0;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4;
    const l = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2];
    all += l;
    const nx = x / w, ny = y / h;
    if (box && nx >= box.x0 && nx <= box.x1 && ny >= box.y0 && ny <= box.y1) { pin += l; pn++; } else { out += l; on++; }
  }
  return { mean: all / (w * h), person: pn ? pin / pn : null, bg: on ? out / on : null };
}

export function bodyBox(N) {
  const pts = BODY_IDX.map((i) => N[i]).filter((p) => p && p.v > 0.5);
  if (pts.length < 5) return null;
  const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y);
  return { x0: Math.min(...xs), x1: Math.max(...xs), y0: Math.min(...ys) - 0.04, y1: Math.max(...ys) };
}

// samples: [{N, box, light, dets:[{label, score, box:{x,y,w,h}}], allIn}]
// vraća {verdict: 'ok'|'warn'|'bad', items:[{status, key, vars}], env, obstacles}
export function analyzeSpace(samples, ex, { aspect, child }) {
  const spec = SPACE[ex.id] || { side: 0.2, up: 0.05 };
  const items = [];
  const add = (status, key, vars) => items.push({ status, key, vars });

  const seen = samples.filter((s) => s.allIn && s.box);
  if (seen.length < samples.length * 0.6) {
    add('bad', 'spNotVisible');
    return finish(items, null, []);
  }
  add('ok', 'spVisible');

  // svetlo
  const mean = avg(samples.map((s) => s.light.mean));
  const pl = avg(seen.map((s) => s.light.person).filter((v) => v != null));
  const bl = avg(seen.map((s) => s.light.bg).filter((v) => v != null));
  if (mean < 50) add('bad', 'spDark');
  else if (mean < 80) add('warn', 'spDim');
  else if (pl != null && bl != null && bl - pl > 45) add('warn', 'spBacklight');
  else add('ok', 'spLight');

  // udaljenost i veličina tela u kadru
  const box = {
    x0: median(seen.map((s) => s.box.x0)), x1: median(seen.map((s) => s.box.x1)),
    y0: median(seen.map((s) => s.box.y0)), y1: median(seen.map((s) => s.box.y1)),
  };
  const H = box.y1 - box.y0;
  if (!spec.upperOnly) {
    if (H > 0.95) add('bad', 'spTooClose');
    else if (H < 0.35) add('warn', 'spTooFar');
    else add('ok', 'spDistance');
  }

  // zona pokreta
  const dx = (spec.side * H) / aspect;
  const env = { x0: box.x0 - dx, x1: box.x1 + dx, y0: box.y0 - spec.up * H, y1: box.y1 };
  // na slici kamere (bez ogledala) leva strana slike je desna strana osobe okrenute ka kameri
  const outImgLeft = env.x0 < 0.01, outImgRight = env.x1 > 0.99, outTop = env.y0 < 0;
  if (outImgLeft || outImgRight || outTop) {
    const where = [outImgLeft && 'right', outImgRight && 'left', outTop && 'top'].filter(Boolean);
    add('bad', 'spNoRoom', { where });
  } else add('ok', 'spRoom');

  // mirnoća kamere
  const cx = seen.map((s) => (s.box.x0 + s.box.x1) / 2), cy = seen.map((s) => s.box.y1);
  if (std(cx) > 0.03 || std(cy) > 0.03) add('warn', 'spShaky');

  // prepreke: predmet viđen u bar 40 % uzoraka, koji zalazi u zonu pokreta
  const withDets = samples.filter((s) => s.dets);
  const groups = [];
  for (const s of withDets) for (const d of s.dets) {
    if (IGNORE.has(d.label)) continue;
    let g = groups.find((g) => g.label === d.label && iou(g.box, d.box) > 0.3);
    if (!g) { g = { label: d.label, box: d.box, hits: 0 }; groups.push(g); }
    g.hits++;
  }
  const stable = groups.filter((g) => g.hits >= Math.max(1, withDets.length * 0.4));
  const obstacles = [];
  for (const g of stable) {
    if (overlapFrac(g.box, env) > 0.15) {
      const gx = g.box.x + g.box.w / 2, bx = (box.x0 + box.x1) / 2;
      obstacles.push({ ...g, side: gx < bx ? 'right' : 'left' });
    }
  }
  for (const o of obstacles) add('warn', 'spObstacle', { label: o.label, side: o.side });
  if (!obstacles.length && withDets.length) add('ok', 'spNoObstacles');

  if (spec.chair) {
    if (stable.some((g) => g.label === 'chair')) add('info', 'spChairFound');
    else add('info', 'spChairTip');
  }
  if (child) add('info', 'spChild');
  return finish(items, env, obstacles);
}

// ── HomeAdapt: uslovi kod kuće ──
// home = {equipment: {chair, wall, mat, band, weight}, space: 'ok'|'limited', camera: 'both'|'front'|'side'|'close'}
const NEEDS = {
  'squat': { chair: true, sideCam: true, room: true },
  'calf-raise': { support: true, sideCam: true },
  'hip-abduction': { support: true, room: true },
  'knee-raise': { support: true },
  'lateral-raise': { room: true },
  'overhead-raise': { room: true },
  'side-bend': {},
  'elbow-curl': {},
  'neck-tilt': { upperOnly: true },
};
export const DEFAULT_HOME = { equipment: { chair: true, wall: true, mat: false, band: false, weight: false }, space: 'ok', camera: 'both' };

// Vraća razloge zbog kojih vežba nije izvodljiva (prazno = izvodljiva) i preporuke
export function feasibility(ex, home = DEFAULT_HOME, spaceResult = null) {
  const n = NEEDS[ex.id] || {};
  const eq = home.equipment || {};
  const blockers = [], tips = [];
  if (n.chair && !eq.chair) blockers.push('haNoChair');
  if (n.support && !eq.chair && !eq.wall) tips.push('haNoSupport');
  if (n.room && home.space === 'limited') blockers.push('haNoRoom');
  if (ex.view === 'side' && (home.camera === 'front' || home.camera === 'close')) blockers.push('haNoSideCam');
  if (ex.view === 'front' && home.camera === 'side') blockers.push('haNoFrontCam');
  if (!n.upperOnly && home.camera === 'close') blockers.push('haTooClose');
  if (spaceResult && spaceResult.items.some((i) => i.key === 'spNoRoom')) blockers.push('haScanNoRoom');
  return { ok: !blockers.length, blockers: [...new Set(blockers)], tips };
}

// Izvodljive zamene: prvo isti deo tela, pa vežbe koje rade isti mišić
export function alternatives(ex, all, home = DEFAULT_HOME) {
  const ok = all.filter((e) => e.id !== ex.id && feasibility(e, home).ok);
  const same = ok.filter((e) => e.region === ex.region);
  const focus = ok.filter((e) => e.region !== ex.region && e.focus.some((f) => ex.focus.includes(f)));
  return [...same, ...focus].slice(0, 3);
}

function finish(items, env, obstacles) {
  const verdict = items.some((i) => i.status === 'bad') ? 'bad' : items.some((i) => i.status === 'warn') ? 'warn' : 'ok';
  return { verdict, items, env, obstacles };
}
const avg = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : null);
const median = (a) => { const b = [...a].sort((x, y) => x - y); return b[Math.floor(b.length / 2)]; };
const std = (a) => { const m = avg(a); return Math.sqrt(avg(a.map((v) => (v - m) ** 2)) || 0); };
