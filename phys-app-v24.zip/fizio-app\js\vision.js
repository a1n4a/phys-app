// Učitavanje MediaPipe modela: prepoznavanje poze tela i prepoznavanje predmeta (za proveru prostora).

const MP_VER = '0.10.14';
const MP_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MP_VER}/vision_bundle.mjs`;
const WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MP_VER}/wasm`;
const IS_MOBILE = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const POSE_URL = IS_MOBILE
  ? 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task'
  : 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task';
const DET_URL = 'https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float16/1/efficientdet_lite0.task';

const once = (fn) => { let p = null; return () => { if (!p) { p = fn(); p.catch(() => { p = null; }); } return p; }; };

const getVision = once(async () => {
  const mod = await import(MP_URL);
  const fileset = await mod.FilesetResolver.forVisionTasks(WASM_URL);
  return { mod, fileset };
});

async function create(Task, options) {
  const { fileset } = await getVision();
  const withDelegate = (delegate) => ({ ...options, baseOptions: { ...options.baseOptions, delegate } });
  try { return await Task.createFromOptions(fileset, withDelegate('GPU')); }
  catch { return await Task.createFromOptions(fileset, withDelegate('CPU')); }
}

export const getLandmarker = once(async () => {
  const { mod } = await getVision();
  return create(mod.PoseLandmarker, {
    baseOptions: { modelAssetPath: POSE_URL },
    runningMode: 'VIDEO', numPoses: 1,
    minPoseDetectionConfidence: 0.5, minPosePresenceConfidence: 0.5, minTrackingConfidence: 0.5,
  });
});

export const getDetector = once(async () => {
  const { mod } = await getVision();
  return create(mod.ObjectDetector, {
    baseOptions: { modelAssetPath: DET_URL },
    runningMode: 'VIDEO', scoreThreshold: 0.4, maxResults: 12,
  });
});
