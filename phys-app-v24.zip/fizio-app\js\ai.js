// AI asistent: iz slobodnog teksta (ili slike) izveštaja fizioterapeuta pravi program vežbi.
// Server (start.ps1) poziva Claude API sa pretragom interneta; ključ nikad ne dolazi u browser.
import { callApi } from './api.js';
import { byId } from './exercises.js';
import { t, exText, getLang } from './i18n.js';
import { kindOf } from './docs.js';

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export async function aiStatus(role) {
  try { return (await callApi('ai/status', null, role)).configured; } catch { return false; }
}
export const saveKey = (key) => callApi('ai/key', { key }, 'therapist');

// Smanjuje fotografiju (manje podataka, brže slanje); AI čita sliku direktno, bolje od OCR-a
async function toJpeg(file) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 1800 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.85).split(',')[1];
}

// Pokreće AI posao i čeka rezultat. onTick(sekunde) za prikaz napretka.
const toBase64 = (file) => new Promise((res, rej) => {
  const r = new FileReader();
  r.onload = () => res(String(r.result).split(',')[1]);
  r.onerror = rej;
  r.readAsDataURL(file);
});

export async function generate({ role, text = '', file = null, onTick }) {
  const body = { text, lang: getLang() };
  if (file && kindOf(file) === 'image') { body.image = await toJpeg(file); body.mediaType = 'image/jpeg'; }
  else if (file && kindOf(file) === 'pdf') { body.image = await toBase64(file); body.mediaType = 'application/pdf'; }
  const { jobId } = await callApi('ai/plan', body, role);
  const t0 = Date.now();
  for (;;) {
    await new Promise((r) => setTimeout(r, 2500));
    if (onTick) onTick(Math.round((Date.now() - t0) / 1000));
    const s = await callApi('ai/job?id=' + encodeURIComponent(jobId), null, role);
    if (s.status === 'done') return s.result;
    if (s.status === 'error') throw Object.assign(new Error(s.error), { code: s.error, detail: s.detail });
    if (Date.now() - t0 > 8 * 60000) throw Object.assign(new Error('timeout'), { code: 'timeout' });
  }
}

export function errorText(e) {
  const k = 'aiErr_' + (e.code || 'api_error');
  const s = t(k);
  return s === k ? t('aiErr_api_error') : s;
}

// ── višejezičnost AI teksta ──
// AI rezultat ima program na jeziku izveštaja i prevode: result.translations = {sr: program, en: program}
export const programFor = (result, lang = getLang()) => (result && result.translations && result.translations[lang]) || (result && result.program) || {};

// Za svaki jezik iz prevoda izračuna vrednost; vraća {sr: ..., en: ...} ili null
function perLang(result, fn) {
  if (!result || !result.translations) return null;
  const out = {};
  for (const [l, p] of Object.entries(result.translations)) { const v = fn(p); if (v != null) out[l] = v; }
  return Object.keys(out).length ? out : null;
}
const AVOID = { sr: 'Izbegavati', en: 'Avoid' };
const planNoteText = (p, lang) => [p.frequencyNote, p.avoid && p.avoid.length ? (AVOID[lang] || AVOID.en) + ': ' + p.avoid.join('; ') : '', p.progression].filter(Boolean).join('\n');
export const aiPlanNote = (result) => planNoteText(programFor(result), getLang());
export const aiPlanNotes = (result) => (result && result.translations ? Object.fromEntries(Object.entries(result.translations).map(([l, p]) => [l, planNoteText(p, l)])) : null);
export const aiSummaries = (result) => perLang(result, (p) => p.summary || null);

// AI stavke -> stavke plana terapije (sa tekstom na svim dostupnim jezicima)
export function toPlanItems(result) {
  const main = programFor(result);
  return (main.items || []).map((it, i) => {
    const lib = it.kind === 'library' && it.exId && byId(it.exId);
    const at = (p) => (p.items && p.items[i]) || null;
    const base = { sets: Math.max(1, it.sets || 1), reps: Math.max(1, it.reps || 10), side: it.side || 'both', tol: 0.1, note: '' };
    if (lib) {
      return { ...base, exId: it.exId, romTarget: it.romTarget > 0 ? Math.round(it.romTarget) : null, romMax: it.romMax > 0 ? Math.round(it.romMax) : null,
        note: it.cautions && it.cautions[0] ? it.cautions[0] : '',
        noteI18n: perLang(result, (p) => { const x = at(p); return x ? (x.cautions && x.cautions[0]) || '' : null; }) };
    }
    return { ...base, exId: `custom-${i + 1}`, custom: {
      name: it.name, instructions: it.instructions || [], holdSec: Math.max(0, it.holdSec || 0), cautions: it.cautions || [],
      i18n: perLang(result, (p) => { const x = at(p); return x ? { name: x.name, instructions: x.instructions || [], cautions: x.cautions || [] } : null; }),
    } };
  });
}

// Tekst stavke / plana na trenutnom jeziku (pada na sačuvani tekst ako prevoda nema)
export const customField = (it, f) => {
  const loc = it.custom && it.custom.i18n && it.custom.i18n[getLang()];
  return (loc && loc[f] != null && loc[f] !== '') ? loc[f] : (it.custom ? it.custom[f] : undefined);
};
export const itemName = (it) => (it.custom ? customField(it, 'name') : byId(it.exId) ? exText(byId(it.exId), 'name') : it.exId);
export const itemNote = (it) => (it.noteI18n && it.noteI18n[getLang()] != null ? it.noteI18n[getLang()] : it.note || '');
// Kratak naziv programa (2–4 reči): AI ga daje u summary.title; za starije programe se skraćuje dijagnoza
// do prvog zareza, crte ili zagrade ("Patelofemoralni bolni sindrom – bol ispred kolena (...)" -> "Patelofemoralni bolni sindrom")
export function shortTitle(text) {
  if (!text) return '';
  let s = String(text).split(/\s[–—-]\s|\s\(|,|;|:|\s(?:sa|bez|with|without)\s/i)[0].trim();
  const words = s.split(/\s+/);
  if (words.length > 4) s = words.slice(0, 4).join(' ');
  return s;
}
export const planShortTitle = (plan) => {
  const s = planSummary(plan);
  if (!s) return '';
  return (s.title && s.title.trim()) || shortTitle(s.condition);
};
export const planSummary = (plan) => (plan && ((plan.aiSummaryI18n && plan.aiSummaryI18n[getLang()]) || plan.aiSummary)) || null;
export const planNote = (plan) => (plan ? (plan.noteI18n && plan.noteI18n[getLang()] != null ? plan.noteI18n[getLang()] : plan.note || '') : '');

// Prikaz rezultata (sažetak + program + izvori)
// opts.program === false: bez liste vežbi i rasporeda (u Therapy Builder-u su u delu za pregled i odobravanje)
export function renderResult(result, opts = {}) {
  const showProgram = opts.program !== false;
  const p = programFor(result);
  const s = p.summary || {};
  const sideTxt = { left: t('side_left'), right: t('side_right'), both: t('side_both'), none: '–' };
  const dosage = (it) => (it.holdSec > 0 ? `${it.sets} × ${it.reps} × ${it.holdSec} s` : `${it.sets} × ${it.reps}`);
  const srcs = [...(p.sources || [])];
  for (const x of result.searched || []) if (!srcs.some((y) => y.url === x.url)) srcs.push(x);
  const safeUrl = (u) => (/^https?:\/\//i.test(u) ? u : '#');
  const list = (arr) => (arr && arr.length ? `<ul>${arr.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : '');

  return `<div class="ai-result">
    <div class="ai-head"><span class="pill">${result.model === 'preset' ? t('presetPill') : 'AI'}</span>${result.model === 'demo' ? `<span class="pill demo" title="${esc(t('aiDemoTip'))}">${t('aiDemo')}</span>` : ''}<h3>${esc(s.condition || '')}</h3></div>
    <dl class="ai-meta">
      <div><dt>${t('aiRegion')}</dt><dd>${esc(s.region || '–')} · ${sideTxt[s.side] || '–'}</dd></div>
      <div><dt>${t('aiIrritability')}</dt><dd>${esc(t('irr_' + s.irritability) || s.irritability || '–')}</dd></div>
      <div><dt>${t('aiPhase')}</dt><dd>${esc(s.phase || '–')}</dd></div>
    </dl>
    ${s.redFlags && s.redFlags.length ? `<div class="caution"><strong>${t('aiRedFlags')}</strong>${list(s.redFlags)}</div>` : ''}
    ${s.keyFindings && s.keyFindings.length ? `<details open><summary>${t('aiFindings')}</summary>${list(s.keyFindings)}</details>` : ''}
    ${s.romFindings && s.romFindings.length ? `<details open><summary>${t('aiRom')}</summary><div class="table-wrap"><table class="rp-table"><tbody>
      ${s.romFindings.map((r) => `<tr><td>${esc(r.movement)}</td><td><strong>${esc(r.value)}</strong></td><td>${esc(r.note)}</td></tr>`).join('')}</tbody></table></div></details>` : ''}
    ${s.goals && s.goals.length ? `<details><summary>${t('aiGoals')}</summary>${list(s.goals)}</details>` : ''}

    ${showProgram ? `<h4>${t('aiProgram')}</h4>
    <ol class="ai-items">
      ${(p.items || []).map((it) => {
        const lib = it.kind === 'library' && byId(it.exId);
        return `<li>
          <div class="ai-item-h"><strong>${esc(lib ? exText(lib, 'name') : it.name)}</strong>
            <span class="tag ${lib ? 'cam' : ''}">${lib ? t('aiCam') : t('aiNoCam')}</span></div>
          <div class="ai-dose">${dosage(it)}${it.side && it.side !== 'both' ? ' · ' + sideTxt[it.side] : ''}${it.romTarget > 0 ? ' · ' + t('aiRomTarget', { v: Math.round(it.romTarget) }) : ''}${it.romMax > 0 ? ' · ' + t('aiRomMax', { v: Math.round(it.romMax) }) : ''}</div>
          <p class="muted small">${esc(it.reason)}</p>
          ${it.instructions && it.instructions.length ? `<details><summary>${t('aiHow')}</summary><ol>${it.instructions.map((x) => `<li>${esc(x)}</li>`).join('')}</ol></details>` : ''}
          ${it.cautions && it.cautions.length ? `<p class="small down">${it.cautions.map(esc).join(' · ')}</p>` : ''}
        </li>`;
      }).join('')}
    </ol>
    ${p.avoid && p.avoid.length ? `<p><strong>${t('aiAvoid')}:</strong> ${p.avoid.map(esc).join('; ')}</p>` : ''}
    ${p.frequencyNote ? `<p><strong>${t('aiFreq')}:</strong> ${esc(p.frequencyNote)}</p>` : ''}
    ${p.progression ? `<p><strong>${t('aiProgression')}:</strong> ${esc(p.progression)}</p>` : ''}` : ''}
    ${srcs.length ? `<details><summary>${t('aiSources')} (${srcs.length})</summary><ul class="ai-src">${srcs.map((x) => `<li><a href="${esc(safeUrl(x.url))}" target="_blank" rel="noopener">${esc(x.title || x.url)}</a></li>`).join('')}</ul></details>` : ''}
    <p class="muted small">${t('aiDisclaimer')}</p>
  </div>`;
}
