// Nova vežba iz videa.
//
// 1) Video se prolazi kadar po kadar istim modelom koji koristi kamera (MediaPipe Pose, 33 tačke).
// 2) Za svaki merljiv pokret (ugao u ramenu, laktu, kuku, kolenu, nagib trupa, glave, podizanje na prste)
//    računa se niz vrednosti kroz video; glavni pokret je onaj koji se najviše menja.
// 3) Iz glavnog pokreta: početni položaj, cilj (koliko daleko se ide), zadržavanje, broj ponavljanja u videu.
// 4) Delovi tela koji u videu miruju postaju pravila ("držite laktove ispružene", "ne naginjite trup").
// 5) Iz položaja na početku i na vrhu pokreta pravi se animirani demonstrator.
// Rezultat je opis vežbe (JSON) koji se čuva na uređaju; buildExercise() od njega pravi vežbu
// istog oblika kao ugrađene (metric, checks, required, demo).

import { LM, J, mid, dist, angle, trunkLean, fromVertical, lineAngle, angleDiff, clamp, DEG } from './geometry.js';
import { getLandmarker } from './vision.js';
import { getLang } from './i18n.js';

// ─────────────── merljivi pokreti ───────────────
// fn(P, s, refs) -> vrednost u stepenima, raste sa pokretom (0 ili mala vrednost = mirovanje)
const flexAt = (a, b, c) => 180 - angle(a, b, c);
const footAngle = (P, s) => {
  const heel = P[J(s, 'Heel')], toe = P[J(s, 'Toe')];
  const d = dist(heel, toe) || 1e-6;
  return Math.asin(clamp((toe.y - heel.y) / d, -1, 1)) * DEG;
};
export const MOVES = {
  sh: { paired: true, views: ['front', 'side'], region: 'ramena', focus: ['upperArms'],
    joints: (s) => [J(s, 'Sh'), J(s, 'El'), J(s, 'Wr'), J(s, 'Hip')],
    fn: (P, s) => angle(P[J(s, 'Hip')], P[J(s, 'Sh')], P[J(s, 'El')]) },
  el: { paired: true, views: ['front', 'side'], region: 'ruke', focus: ['forearms'],
    joints: (s) => [J(s, 'Sh'), J(s, 'El'), J(s, 'Wr')],
    fn: (P, s) => flexAt(P[J(s, 'Sh')], P[J(s, 'El')], P[J(s, 'Wr')]) },
  hipAbd: { paired: true, views: ['front'], region: 'kukovi', focus: ['hips', 'thighs'],
    joints: (s) => [J(s, 'Hip'), J(s, 'Kn'), J(s, 'An')],
    fn: (P, s) => fromVertical(P[J(s, 'Hip')], P[J(s, 'Kn')]) },
  // spreda se savijanje u kuku vidi kao "skraćivanje" butine u odnosu na butinu u stojećem položaju
  hipFlex: { paired: true, views: ['front', 'side'], region: 'kukovi', focus: ['hips', 'thighs'],
    joints: (s) => [J(s, 'Sh'), J(s, 'Hip'), J(s, 'Kn'), J(s, 'An')],
    fn: (P, s, refs, view) => {
      if (view === 'side') return flexAt(P[J(s, 'Sh')], P[J(s, 'Hip')], P[J(s, 'Kn')]);
      const ref = refs && refs['thigh' + s.toUpperCase()];
      if (!ref) return 0;
      return Math.acos(clamp((P[J(s, 'Kn')].y - P[J(s, 'Hip')].y) / ref, 0, 1)) * DEG;
    } },
  knee: { paired: true, views: ['front', 'side'], region: 'kolena', focus: ['thighs', 'hips'],
    joints: (s) => [J(s, 'Hip'), J(s, 'Kn'), J(s, 'An')],
    fn: (P, s) => flexAt(P[J(s, 'Hip')], P[J(s, 'Kn')], P[J(s, 'An')]) },
  trunkSide: { paired: false, views: ['front'], region: 'trup', focus: ['trunk'],
    joints: () => [LM.lSh, LM.rSh, LM.lHip, LM.rHip],
    fn: (P, s, refs) => Math.abs(trunkLean(P) - ((refs && refs.lean) || 0)) },
  trunkFlex: { paired: false, views: ['side'], region: 'trup', focus: ['trunk'],
    joints: (s) => [J(s, 'Sh'), J(s, 'Hip')],
    fn: (P, s) => fromVertical(P[J(s, 'Hip')], P[J(s, 'Sh')]) },
  neck: { paired: false, views: ['front'], region: 'vrat', focus: ['neck'],
    joints: () => [LM.lEar, LM.rEar, LM.lSh, LM.rSh],
    fn: (P, s, refs) => Math.abs(angleDiff(lineAngle(P[LM.rEar], P[LM.lEar]), lineAngle(P[LM.rSh], P[LM.lSh])) - ((refs && refs.neck) || 0)) },
  heel: { paired: false, views: ['side'], region: 'stopala', focus: ['calves'],
    joints: (s) => [J(s, 'Kn'), J(s, 'An'), J(s, 'Heel'), J(s, 'Toe')],
    fn: (P, s, refs) => Math.max(0, footAngle(P, s) - ((refs && refs.footAngle) || 0)) },
};

// ─────────────── tekstovi (oba jezika se čuvaju uz vežbu) ───────────────
const TXT = {
  sr: {
    name: { sh_front: 'Podizanje ruku u stranu', sh_side: 'Podizanje ruku napred', el: 'Savijanje laktova', hipAbd: 'Odvođenje noge u stranu',
      hipFlex: 'Podizanje noge napred', hipFlexKnee: 'Podizanje kolena', knee: 'Savijanje kolena', squat: 'Čučanj', trunkSide: 'Bočno naginjanje trupa',
      trunkFlex: 'Pretklon trupa', neck: 'Naginjanje glave u stranu', heel: 'Podizanje na prste' },
    verb: { sh_front: 'Podignite ruke u stranu', sh_side: 'Podignite ruke napred', el: 'Savijte laktove', hipAbd: 'Podignite nogu u stranu',
      hipFlex: 'Podignite nogu napred', hipFlexKnee: 'Podignite koleno', knee: 'Savijte koleno', squat: 'Spustite se u čučanj', trunkSide: 'Nagnite trup u stranu',
      trunkFlex: 'Pretklonite se', neck: 'Nagnite glavu u stranu', heel: 'Podignite se na prste' },
    sideL: 'leva strana', sideR: 'desna strana', alt: 'naizmenično',
    start: 'Zauzmite početni položaj kao na početku videa.',
    to: (v, tg) => `${v} do oko ${tg}°, kao u videu.`,
    hold: (h) => `Zadržite ${h} s.`,
    back: 'Polako se vratite u početni položaj.',
    summary: (n, a, b, h) => `Vežba napravljena iz videa. Glavni pokret: ${n.toLowerCase()}, opseg ${a}°–${b}°${h ? `, zadržavanje ${h} s` : ''}.`,
    tooLow: (tg) => `Idite dalje, do ${tg}° kao u videu`,
    place: { front: 'Licem ka kameri, na 2 do 3 metra, da se vidi celo telo.', side: 'Bočno prema kameri, na 2 do 3 metra, da se vidi celo telo.' },
    err: { v_elbow: 'Držite laktove ispružene', v_elbowKeep: 'Zadržite ugao u laktu kao u videu', v_knee: 'Ne savijajte kolena',
      v_kneeKeep: 'Zadržite ugao u kolenu kao u videu', v_lean: 'Ne naginjite trup u stranu', v_bend: 'Držite leđa uspravno',
      v_hip: 'Ne savijajte se u kukovima', v_over: 'Ne idite preko opsega iz videa', v_asym: 'Pomerajte obe strane ravnomerno' },
  },
  en: {
    name: { sh_front: 'Arm raise to the side', sh_side: 'Forward arm raise', el: 'Elbow bend', hipAbd: 'Side leg raise',
      hipFlex: 'Forward leg raise', hipFlexKnee: 'Knee raise', knee: 'Knee bend', squat: 'Squat', trunkSide: 'Side bend',
      trunkFlex: 'Forward bend', neck: 'Neck side tilt', heel: 'Heel raise' },
    verb: { sh_front: 'Raise your arms to the side', sh_side: 'Raise your arms forward', el: 'Bend your elbows', hipAbd: 'Lift your leg to the side',
      hipFlex: 'Lift your leg forward', hipFlexKnee: 'Lift your knee', knee: 'Bend your knee', squat: 'Lower into a squat', trunkSide: 'Lean your trunk to the side',
      trunkFlex: 'Bend forward', neck: 'Tilt your head to the side', heel: 'Rise onto your toes' },
    sideL: 'left side', sideR: 'right side', alt: 'alternating',
    start: 'Take the starting position shown at the beginning of the video.',
    to: (v, tg) => `${v} to about ${tg}°, as in the video.`,
    hold: (h) => `Hold for ${h} s.`,
    back: 'Slowly return to the starting position.',
    summary: (n, a, b, h) => `Exercise created from a video. Main movement: ${n.toLowerCase()}, range ${a}°–${b}°${h ? `, hold ${h} s` : ''}.`,
    tooLow: (tg) => `Go further, to ${tg}° as in the video`,
    place: { front: 'Facing the camera, 2 to 3 metres away, whole body visible.', side: 'Side-on to the camera, 2 to 3 metres away, whole body visible.' },
    err: { v_elbow: 'Keep your elbows straight', v_elbowKeep: 'Keep the elbow angle as in the video', v_knee: 'Don’t bend your knees',
      v_kneeKeep: 'Keep the knee angle as in the video', v_lean: 'Don’t lean your trunk sideways', v_bend: 'Keep your back upright',
      v_hip: 'Don’t bend at the hips', v_over: 'Don’t go beyond the range shown in the video', v_asym: 'Move both sides evenly' },
  },
};
const L = () => (getLang() === 'en' ? 'en' : 'sr');

// ─────────────── 1) poze iz videa ───────────────
let lastTs = 0;
const nextTs = () => { lastTs = Math.max(lastTs + 1, performance.now()); return lastTs; };
const seek = (v, t) => new Promise((res) => {
  const done = () => { v.removeEventListener('seeked', done); clearTimeout(to); res(); };
  const to = setTimeout(done, 1500);
  v.addEventListener('seeked', done);
  v.currentTime = t;
});

// video: <video> sa učitanim fajlom. onFrame(i, n, landmarks|null) za prikaz napretka i kostura.
export async function extractPoses(video, { onFrame, signal } = {}) {
  if (video.readyState < 1) await new Promise((res, rej) => { video.onloadedmetadata = res; video.onerror = () => rej(Object.assign(new Error('video'), { code: 'video' })); });
  const dur = video.duration;
  if (!Number.isFinite(dur) || dur <= 0.5) throw Object.assign(new Error('short'), { code: 'short' });
  if (dur > 120) throw Object.assign(new Error('long'), { code: 'long' });
  const lm = await getLandmarker();
  const fps = clamp(240 / dur, 4, 12);
  const n = Math.max(8, Math.floor(dur * fps));
  const aspect = (video.videoWidth || 16) / (video.videoHeight || 9);
  const frames = [];
  video.pause();
  for (let i = 0; i < n; i++) {
    if (signal && signal.aborted) throw Object.assign(new Error('abort'), { code: 'abort' });
    const t = Math.min(dur - 0.05, (i / fps));
    await seek(video, t);
    let pts = null;
    try {
      const r = lm.detectForVideo(video, nextTs());
      const l = r.landmarks && r.landmarks[0];
      if (l) pts = l.map((p, k) => ({ x: p.x, y: p.y, v: r.landmarks[0][k].visibility ?? 1 }));
    } catch { pts = null; }
    frames.push({ t, N: pts, P: pts ? pts.map((p) => ({ x: p.x * aspect, y: p.y, v: p.v })) : null });
    if (onFrame) onFrame(i + 1, n, pts);
  }
  return { frames, fps, duration: dur, aspect };
}

// ─────────────── 2–5) analiza ───────────────
const sorted = (a) => a.slice().sort((x, y) => x - y);
const pct = (a, p) => { if (!a.length) return null; const s = sorted(a); return s[Math.min(s.length - 1, Math.max(0, Math.round((s.length - 1) * p)))]; };
const median = (a) => pct(a, 0.5);
const vis = (P, idx) => idx.every((i) => P[i] && P[i].v > 0.45);

// klizna medijana (5 kadrova) da trzaji modela ne liče na pokret
function smooth(series) {
  return series.map((v, i) => {
    if (v == null) return null;
    const w = series.slice(Math.max(0, i - 2), i + 3).filter((x) => x != null);
    return median(w);
  });
}
// popuni rupe (kadrovi bez osobe) najbližom poznatom vrednošću
function fill(series) {
  const out = series.slice();
  let last = null;
  for (let i = 0; i < out.length; i++) { if (out[i] == null) out[i] = last; else last = out[i]; }
  last = null;
  for (let i = out.length - 1; i >= 0; i--) { if (out[i] == null) out[i] = last; else last = out[i]; }
  return out;
}
function corr(a, b) {
  const n = Math.min(a.length, b.length);
  const ma = a.reduce((s, v) => s + v, 0) / n, mb = b.reduce((s, v) => s + v, 0) / n;
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < n; i++) { num += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2; }
  return num / (Math.sqrt(da * db) || 1e-6);
}

// pogled: spreda su ramena široka u odnosu na trup, sa strane se preklapaju
function detectView(frames) {
  const r = frames.filter((f) => f.P).map((f) => {
    const P = f.P;
    const torso = dist(mid(P[LM.lSh], P[LM.rSh]), mid(P[LM.lHip], P[LM.rHip])) || 1e-6;
    return dist(P[LM.lSh], P[LM.rSh]) / torso;
  });
  return median(r) < 0.38 ? 'side' : 'front';
}
// sa strane: koja strana tela je bliža kameri (bolje vidljiva)
function visibleSide(frames) {
  let l = 0, r = 0;
  for (const f of frames) if (f.P) for (const k of ['Sh', 'Hip', 'Kn', 'An', 'El']) { l += f.P[J('l', k)].v; r += f.P[J('r', k)].v; }
  return l >= r ? 'l' : 'r';
}

function seriesFor(frames, key, s, refs, view) {
  const M = MOVES[key];
  const idx = M.joints(s || 'l');
  const raw = frames.map((f) => (f.P && vis(f.P, idx) ? M.fn(f.P, s, refs, view) : null));
  const known = raw.filter((v) => v != null).length;
  if (known < Math.max(6, frames.length * 0.4)) return null;
  const sm = fill(smooth(raw));
  return { values: sm, range: pct(sm, 0.95) - pct(sm, 0.05), known };
}

// ponavljanja: prelazak preko gornjeg praga pa povratak ispod donjeg
function findReps(v, fps) {
  const rest = pct(v, 0.1), top = pct(v, 0.9);
  const span = Math.max(1, top - rest);
  const hi = rest + 0.6 * span, lo = rest + 0.35 * span;
  const reps = [];
  let st = 'rest', start = 0, peak = -Infinity, peakI = 0;
  for (let i = 0; i < v.length; i++) {
    if (st === 'rest' && v[i] > lo) { st = 'up'; start = i; peak = v[i]; peakI = i; }
    if (st !== 'rest') {
      if (v[i] > peak) { peak = v[i]; peakI = i; }
      if (v[i] > hi) st = 'top';
      if (v[i] < lo) {
        if (st === 'top') {
          const near = peak - Math.max(4, 0.08 * (peak - rest));
          let holdN = 0; for (let k = start; k <= i; k++) if (v[k] >= near) holdN++;
          reps.push({ start, end: i, peak, peakI, hold: holdN / fps });
        }
        st = 'rest'; peak = -Infinity;
      }
    }
  }
  return { reps, rest, top };
}

// avatar: položaj tela iz tačaka (isti parametri kao ugrađene vežbe)
function frontParams(P, refs, restLean, restNeck) {
  const p = {};
  for (const s of ['l', 'r']) {
    const S = s.toUpperCase();
    p['abd' + S] = Math.round(angle(P[J(s, 'Hip')], P[J(s, 'Sh')], P[J(s, 'El')]));
    p['el' + S] = Math.round(Math.max(0, flexAt(P[J(s, 'Sh')], P[J(s, 'El')], P[J(s, 'Wr')])));
    p['hAbd' + S] = Math.round(Math.max(0, fromVertical(P[J(s, 'Hip')], P[J(s, 'Kn')]) - 3));
    const thigh = refs['thigh' + S] || dist(P[J(s, 'Hip')], P[J(s, 'Kn')]);
    const shin = refs['shin' + S] || dist(P[J(s, 'Kn')], P[J(s, 'An')]);
    const flex = Math.acos(clamp((P[J(s, 'Kn')].y - P[J(s, 'Hip')].y) / thigh, 0, 1)) * DEG;
    const shinF = Math.acos(clamp((P[J(s, 'An')].y - P[J(s, 'Kn')].y) / shin, 0, 1)) * DEG;
    p['hFlex' + S] = Math.round(flex);
    p['knee' + S] = Math.round(Math.max(0, flex - shinF));
  }
  // avatar je kao ogledalo: nagib ka levoj strani osobe ide ka levoj strani ekrana
  p.lean = Math.round(-(trunkLean(P) - restLean));
  p.head = Math.round(-(angleDiff(lineAngle(P[LM.rEar], P[LM.lEar]), lineAngle(P[LM.rSh], P[LM.lSh])) - restNeck));
  return p;
}
function sideParams(P, s, f, restH) {
  const sh = P[J(s, 'Sh')], el = P[J(s, 'El')], hip = P[J(s, 'Hip')], kn = P[J(s, 'Kn')], an = P[J(s, 'An')];
  const heel = P[J(s, 'Heel')], toe = P[J(s, 'Toe')];
  const h = Math.atan2(toe.y - heel.y, f * (toe.x - heel.x)) * DEG;
  return {
    r: Math.round(Math.atan2(f * (sh.x - hip.x), hip.y - sh.y) * DEG),
    t: Math.round(Math.atan2(f * (kn.x - hip.x), kn.y - hip.y) * DEG),
    s: Math.round(Math.atan2(f * (kn.x - an.x), an.y - kn.y) * DEG),
    a: Math.round(Math.atan2(f * (el.x - sh.x), el.y - sh.y) * DEG),
    h: Math.round(Math.max(0, h - restH)),
  };
}
// prosečan položaj oko kadra i (±2 kadra) da animacija ne podrhtava
function poseAround(frames, i, mk) {
  const ps = [];
  for (let k = Math.max(0, i - 2); k <= Math.min(frames.length - 1, i + 2); k++) if (frames[k].P) ps.push(mk(frames[k].P));
  if (!ps.length) return null;
  const out = {};
  for (const key of Object.keys(ps[0])) out[key] = Math.round(median(ps.map((p) => p[key])));
  return out;
}

export function analyze(data) {
  const { frames, fps } = data;
  const seen = frames.filter((f) => f.P).length;
  if (seen < Math.max(6, frames.length * 0.4)) return { error: 'noPerson' };
  const view = detectView(frames);
  const vSide = visibleSide(frames);
  // referentne vrednosti iz videa (kao kalibracija kod kamere): mirovanje = prvih ~15 % kadrova
  const restFrames = frames.filter((f) => f.P).slice(0, Math.max(3, Math.round(seen * 0.15))).map((f) => f.P);
  const refs = { lean: median(restFrames.map(trunkLean)), neck: median(restFrames.map((P) => angleDiff(lineAngle(P[LM.rEar], P[LM.lEar]), lineAngle(P[LM.rSh], P[LM.lSh])))) };
  for (const s of ['l', 'r']) {
    const S = s.toUpperCase();
    refs['thigh' + S] = pct(frames.filter((f) => f.P).map((f) => dist(f.P[J(s, 'Hip')], f.P[J(s, 'Kn')])), 0.95);
    refs['shin' + S] = pct(frames.filter((f) => f.P).map((f) => dist(f.P[J(s, 'Kn')], f.P[J(s, 'An')])), 0.95);
  }
  refs.footAngle = median(restFrames.map((P) => footAngle(P, vSide)));

  // svi kandidati za glavni pokret
  const cands = [];
  for (const [key, M] of Object.entries(MOVES)) {
    if (!M.views.includes(view)) continue;
    if (view === 'side' || !M.paired) {
      const sr = seriesFor(frames, key, vSide, refs, view);
      if (sr) cands.push({ key, mode: view === 'side' ? 'side' : 'single', side: view === 'side' ? vSide : null, ...sr });
      continue;
    }
    const a = seriesFor(frames, key, 'l', refs, view), b = seriesFor(frames, key, 'r', refs, view);
    if (!a && !b) continue;
    if (a && b && Math.min(a.range, b.range) >= 0.6 * Math.max(a.range, b.range)) {
      const c = corr(a.values, b.values);
      if (c >= 0.3) cands.push({ key, mode: 'both', side: null, values: a.values.map((v, i) => (v + b.values[i]) / 2), L: a.values, R: b.values, range: (a.range + b.range) / 2 });
      else cands.push({ key, mode: 'alt', side: null, values: a.values.map((v, i) => Math.max(v, b.values[i])), L: a.values, R: b.values, range: Math.max(a.range, b.range) });
    } else {
      const one = !b || (a && a.range >= b.range) ? { s: 'l', sr: a } : { s: 'r', sr: b };
      cands.push({ key, mode: 'one', side: one.s, ...one.sr });
    }
  }
  if (!cands.length) return { error: 'noPerson' };
  // spreda se savijanje kolena kod čučnja vidi slabije od "skraćivanja" butine: blaga prednost kolenu i ramenu
  const weight = { knee: 1.1, sh: 1.05, el: 0.9 };
  cands.sort((x, y) => y.range * (weight[y.key] || 1) - x.range * (weight[x.key] || 1));
  const main = cands[0];
  if (main.range < 15) return { error: 'noMove' };

  const { reps, rest } = findReps(main.values, fps);
  const peaks = reps.length ? reps.map((r) => r.peak) : [pct(main.values, 0.95)];
  const medPeak = median(peaks);
  const restR = Math.round(rest);
  const target = Math.round(rest + 0.9 * (medPeak - rest));
  const start = Math.round(Math.max(rest + 5, rest + 0.3 * (target - rest)));
  const maxPeak = Math.max(...peaks);
  const max = Math.round(maxPeak + Math.max(15, 0.2 * (maxPeak - rest)));
  const holdMed = reps.length ? median(reps.map((r) => r.hold)) : 0;
  const hold = holdMed >= 1.2 ? Math.round(holdMed) : 0;

  // pravila: delovi tela koji tokom pokreta miruju
  const active = main.values.map((v) => v > start);
  const stable = (key, s) => {
    const sr = seriesFor(frames, key, s, refs, view);
    if (!sr) return null;
    const vals = sr.values.filter((_, i) => active[i]);
    if (vals.length < 3) return null;
    const range = pct(vals, 0.9) - pct(vals, 0.1);
    return range < 15 ? { ref: Math.round(median(vals)), range } : null;
  };
  const sidesOf = () => (main.mode === 'side' ? [main.side] : main.mode === 'one' ? [main.side] : ['l', 'r']);
  const checks = [];
  const addKeep = (key, straightId, keepId, straightMax) => {
    if (key === main.key) return;
    const res = sidesOf().map((s) => ({ s, st: stable(key, s) })).filter((x) => x.st);
    if (!res.length || res.length < sidesOf().length) return;
    const ref = Math.max(...res.map((x) => x.st.ref));
    if (ref <= straightMax) checks.push({ id: straightId, key, sides: sidesOf(), kind: 'above', ref, lim: Math.max(25, ref + 20) });
    else checks.push({ id: keepId, key, sides: sidesOf(), kind: 'abs', ref, lim: 25 });
  };
  if (main.key !== 'el' && ['sh'].includes(main.key)) addKeep('el', 'v_elbow', 'v_elbowKeep', 30);
  if (!['knee', 'hipFlex'].includes(main.key)) addKeep('knee', 'v_knee', 'v_kneeKeep', 25);
  if (view === 'front' && main.key !== 'trunkSide') {
    const st = stable('trunkSide', null);
    if (st) checks.push({ id: 'v_lean', key: 'trunkSide', kind: 'above', ref: 0, lim: 12 });
  }
  if (view === 'side' && !['trunkFlex', 'hipFlex', 'knee'].includes(main.key)) {
    const st = stable('trunkFlex', main.side);
    if (st) checks.push({ id: 'v_bend', key: 'trunkFlex', sides: [main.side], kind: 'abs', ref: st.ref, lim: 15 });
  }
  checks.push({ id: 'v_over', key: main.key, kind: 'main', lim: max });
  if (main.mode === 'both') checks.push({ id: 'v_asym', key: main.key, kind: 'asym', lim: Math.max(20, Math.round(0.3 * (target - rest))) });

  // naziv i tekstovi
  const kneeAlso = main.key === 'hipFlex' && (() => { const k = seriesFor(frames, 'knee', main.side || 'l', refs, view); return k && k.range > 45; })();
  const nameKey = main.key === 'sh' ? 'sh_' + view : main.key === 'knee' && main.mode === 'both' ? 'squat' : kneeAlso ? 'hipFlexKnee' : main.key;
  const i18n = {};
  for (const lg of ['sr', 'en']) {
    const T = TXT[lg];
    const suffix = main.mode === 'one' || (main.mode === 'side' && MOVES[main.key].paired && !['knee', 'sh', 'el'].includes(main.key))
      ? ` (${main.side === 'l' ? T.sideL : T.sideR})` : main.mode === 'alt' ? ` (${T.alt})` : '';
    const name = T.name[nameKey] + suffix;
    const verb = T.verb[nameKey];
    const steps = [T.start, T.to(verb, target)];
    if (hold) steps.push(T.hold(hold));
    steps.push(T.back);
    i18n[lg] = { name, summary: T.summary(T.name[nameKey], restR, target, hold), steps, mistakes: checks.map((c) => T.err[c.id]),
      placement: T.place[view], cue: verb, tooLow: T.tooLow(target) };
  }

  // animirani demonstrator: mirovanje -> vrh pokreta -> zadržavanje -> mirovanje
  const rep = reps[0] || { start: 0, peakI: main.values.indexOf(Math.max(...main.values)), end: main.values.length - 1, hold: 0 };
  let restBest = 0, restVal = Infinity;
  for (let i = 0; i <= Math.max(rep.start, 2); i++) if (frames[i] && frames[i].P && main.values[i] < restVal) { restVal = main.values[i]; restBest = i; }
  let mk;
  if (view === 'front') {
    mk = (P) => frontParams(P, refs, refs.lean, refs.neck);
  } else {
    const s = vSide;
    const facing = median(frames.filter((f) => f.P).map((f) => f.P[LM.nose].x - f.P[J(s, 'Ear')].x)) >= 0 ? 1 : -1;
    const restH = median(restFrames.map((P) => Math.atan2(P[J(s, 'Toe')].y - P[J(s, 'Heel')].y, facing * (P[J(s, 'Toe')].x - P[J(s, 'Heel')].x)) * DEG));
    mk = (P) => sideParams(P, s, facing, restH);
  }
  const pRest = poseAround(frames, restBest, mk);
  const pPeak = poseAround(frames, rep.peakI, mk);
  const up = clamp((rep.peakI - rep.start) / fps, 0.6, 3);
  const down = clamp((rep.end - rep.peakI - rep.hold * fps) / fps, 0.6, 3);
  const demo = { view, frames: [{ p: pRest, d: 0.6 }, { p: pPeak, d: up }, { p: pPeak, d: Math.max(0.4, hold || 0.4) }, { p: pRest, d: down }] };

  return {
    spec: {
      v: 1, key: main.key, mode: main.mode, side: main.side, view, region: MOVES[main.key].region,
      rest: restR, start, target, max, hold, defaultReps: 10, checks, demo, i18n,
    },
    info: { reps: reps.length, range: Math.round(main.range), view, mode: main.mode, side: main.side, seen, total: frames.length },
  };
}

// ─────────────── vežba iz opisa (isti oblik kao ugrađene) ───────────────
export function buildExercise(spec) {
  const M = MOVES[spec.key];
  const T = () => TXT[L()];
  const errMsgs = {};
  for (const c of spec.checks) errMsgs[c.id] = { sr: TXT.sr.err[c.id], en: TXT.en.err[c.id] };
  const one = (P, s, ctx) => M.fn(P, s, ctx.refs, spec.view);
  const sideOf = (ctx) => (spec.mode === 'side' ? ctx.side || spec.side : spec.side);
  const ex = {
    id: spec.id, mine: true, fromVideo: true, i18n: spec.i18n,
    ...spec.i18n.sr,
    region: spec.region, view: spec.view, focus: M.focus,
    start: spec.start, target: spec.target, hold: spec.hold, max: spec.max, defaultReps: spec.defaultReps || 10,
    demo: spec.demo, errMsgs, createdAt: spec.createdAt, hasVideo: !!spec.hasVideo,
    required(ctx) {
      const s = spec.mode === 'side' ? (ctx.side || spec.side) : null;
      const torso = s ? [J(s, 'Sh'), J(s, 'Hip')] : [LM.lSh, LM.rSh, LM.lHip, LM.rHip];
      const joints = !M.paired ? M.joints(s || 'l') : spec.mode === 'both' || spec.mode === 'alt' ? [...M.joints('l'), ...M.joints('r')] : M.joints(sideOf(ctx));
      return [...new Set([...torso, ...joints])];
    },
    metric(P, ctx) {
      if (!M.paired) return { value: one(P, sideOf(ctx) || 'l', ctx) };
      if (spec.mode === 'both') { const aL = one(P, 'l', ctx), aR = one(P, 'r', ctx); return { value: (aL + aR) / 2, aL, aR }; }
      if (spec.mode === 'alt') { const aL = one(P, 'l', ctx), aR = one(P, 'r', ctx); return aL >= aR ? { value: aL, side: 'l', aL, aR } : { value: aR, side: 'r', aL, aR }; }
      const s = sideOf(ctx);
      return { value: one(P, s, ctx), side: s };
    },
    checks(P, ctx, m) {
      const out = [];
      const tl = ctx.tol || 0;
      const msg = (id) => T().err[id];
      for (const c of spec.checks) {
        if (c.kind === 'main') { if (m.value > c.lim * (1 + tl)) out.push({ id: c.id, msg: msg(c.id), joints: [] }); continue; }
        if (m.value <= spec.start) continue; // pravila važe tokom pokreta
        if (c.kind === 'asym') { if (Math.abs((m.aL || 0) - (m.aR || 0)) > c.lim * (1 + tl)) out.push({ id: c.id, msg: msg(c.id), joints: [] }); continue; }
        const CM = MOVES[c.key];
        const sides = c.sides || [sideOf(ctx) || 'l'];
        let worst = 0, jts = [];
        for (const s of sides) {
          const s2 = spec.mode === 'side' ? (ctx.side || s) : s;
          const v = CM.fn(P, s2, ctx.refs, spec.view);
          const d = c.kind === 'above' ? v - c.ref : Math.abs(v - c.ref);
          if (d > worst) { worst = d; jts = CM.joints(s2); }
        }
        if (worst > c.lim * (1 + tl)) out.push({ id: c.id, msg: msg(c.id), joints: jts });
      }
      return out;
    },
  };
  return ex;
}

// ─────────────── čuvanje na uređaju ───────────────
const KEY = 'fizio-myex';
export function loadSpecs() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } }
export function saveSpec(spec) {
  const all = loadSpecs().filter((s) => s.id !== spec.id);
  all.push(spec);
  try { localStorage.setItem(KEY, JSON.stringify(all)); } catch { /* */ }
}
export function deleteSpec(id) {
  try { localStorage.setItem(KEY, JSON.stringify(loadSpecs().filter((s) => s.id !== id))); } catch { /* */ }
  deleteVideo(id);
}

// snimak vežbe (za prikaz umesto animacije) u IndexedDB
function db() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('fizio-videos', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('v');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
export async function putVideo(id, blob) {
  try { const d = await db(); await new Promise((res, rej) => { const tx = d.transaction('v', 'readwrite'); tx.objectStore('v').put(blob, id); tx.oncomplete = res; tx.onerror = () => rej(tx.error); }); return true; } catch { return false; }
}
export async function getVideo(id) {
  try { const d = await db(); return await new Promise((res) => { const q = d.transaction('v').objectStore('v').get(id); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); }); } catch { return null; }
}
async function deleteVideo(id) {
  try { const d = await db(); d.transaction('v', 'readwrite').objectStore('v').delete(id); } catch { /* */ }
}

// kostur preko videa tokom analize (leva strana svetlo teget, desna tirkizna)
const BONES = [[11, 12], [11, 13], [13, 15], [12, 14], [14, 16], [11, 23], [12, 24], [23, 24], [23, 25], [25, 27], [24, 26], [26, 28], [27, 29], [29, 31], [27, 31], [28, 30], [30, 32], [28, 32]];
export function drawPose(canvas, N) {
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);
  if (!N) return;
  ctx.lineCap = 'round';
  ctx.lineWidth = Math.max(3, H * 0.008);
  for (const [a, b] of BONES) {
    if (N[a].v < 0.4 || N[b].v < 0.4) continue;
    ctx.strokeStyle = [11, 13, 15, 23, 25, 27, 29, 31].includes(a) ? '#7FA7DA' : '#2ECFC3';
    ctx.beginPath(); ctx.moveTo(N[a].x * W, N[a].y * H); ctx.lineTo(N[b].x * W, N[b].y * H); ctx.stroke();
  }
}
