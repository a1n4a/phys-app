# FizioKamera (prototip)

Web aplikacija za vežbe sa fizikalne terapije. Korisnik bira deo tela, gleda demonstraciju vežbe,
a zatim vežba ispred kamere. Aplikacija u realnom vremenu prepoznaje položaj tela (MediaPipe Pose),
broji ponavljanja, meri opseg pokreta i glasom i porukom na ekranu upozorava na greške.

## Pokretanje na računaru

```
powershell -ExecutionPolicy Bypass -File start.ps1
```

Otvara se `http://localhost:8080`. Kamera u pregledaču radi samo na `localhost` ili preko `https`.
Pri prvom pokretanju vežbe preuzima se model za prepoznavanje poze (oko 6–9 MB), pa je potreban internet.

## Pokretanje na telefonu

Telefon mora da otvori aplikaciju preko **https** adrese, inače pregledač ne daje pristup kameri. Najlakše:

- **Netlify Drop** (app.netlify.com/drop): prevucite ceo folder `fizio-app` i dobijate https link.
- **GitHub Pages**: postavite folder u repozitorijum i uključite Pages.

U Chrome-u na Androidu ili Safari-ju na iPhone-u može se dodati na početni ekran („Add to Home screen“).

## Šta je u prototipu

- 9 vežbi u 7 grupa: vrat, ramena, ruke, trup, kukovi, kolena, skočni zglob.
- Animirani demonstrator za svaku vežbu (radi bez interneta) + podrška za prave video snimke (`videos/`).
- Provera da li je celo telo u kadru, kalibracija početnog položaja (3 s), brojanje ponavljanja,
  zadržavanje položaja (vežbe istezanja), pokazivač opsega pokreta.
- Detekcija grešaka po vežbi (savijeni laktovi, naginjanje trupa, kolena ispred prstiju, podizanje ramena…),
  crvene tačke na kosturu tamo gde je greška, glasovne poruke na srpskom.
- Rezime treninga sa najčešćim greškama; istorija se čuva na uređaju.

## Novo u verziji 3

- **Srpski / engleski**: dugme SR | EN gore desno, izbor u profilu, ili `?lang=en` u adresi.
- **Profil**: pol i uzrast (dete do 12 / 12 i više). Menja izgled demonstratora, broj ponavljanja kod dece i pohvale.
- **Jasnije obeležen demonstrator i kostur**: leva strana plava, desna ljubičasta, zglobovi kao tačke,
  žuti oreol oko dela tela koji se pomera, roze traka na mišiću koji radi.
- **Provera prostora** (dugme na stranici vežbe): svetlo, udaljenost, da li ceo pokret staje u kadar,
  prepreke u zoni pokreta (stolica, sto, kauč…), mirnoća kamere. Daje odgovor da li je vežba moguća na tom mestu.
- **Dnevnik**: bol (0–10), pokretljivost (1–5), subjektivni napredak (1–5) i napomena, posle svake vežbe ili posebno.
- **Izveštaj za fizioterapeuta** posle 3 dana praćenja: grafikoni bola i napretka, opseg pokreta po vežbi,
  tačnost, najčešće greške, napomene. Štampa / PDF, CSV i deljenje.
  Za prikaz sa primerom podataka otvorite `index.html?demo=1#izvestaj` (primer se briše u dnevniku).
- **Slika izveštaja fizioterapeuta**: tekst se čita na uređaju (Tesseract.js, latinica, ćirilica, engleski),
  a aplikacija po ključnim rečima predlaže vežbe, upozorava na operacije, proteze, prelome i akutnu fazu
  i prepoznaje doziranje (npr. 3×10). Izabrane vežbe se čuvaju kao „Moj program“.

## Novo u verziji 4: Home-to-Clinic Feedback Loop

`start.ps1` je sada i server sa bazom (`data\db.json`): nalozi terapeuta, pacijenti, planovi, sesije, dnevnik, prijave i predlozi.

1. **FizioKamera Clinic** (`#klinika`, dugme „Za fizioterapeute“): nalog terapeuta, dashboard sa pacijentima,
   brojevima (pacijenti, za pregled, sesije danas), statusima *Pregled / Podsetnik / U toku* i sažetkom dana.
2. **Therapy Builder**: vežbe, serije, ponavljanja, strana tela, dozvoljeni opseg (max °), tolerancija, napomene, dani.
   Svako čuvanje pravi novu verziju plana (istorija ostaje). Pacijent dobija kod, link (`?join=KOD`) i QR kod.
3. **Vođena terapija**: „Započni današnju terapiju“ vodi kroz sve vežbe i serije, sa pauzama (30 s / 45 s).
   Dugme „Ne mogu da uradim“ šalje razlog terapeutu. Na kraju ocena simptoma.
4. **Smart Alerts**: povećanje bola, „gore mi je“, prijave „ne mogu“, predlozi na čekanju, propušteni zakazani dani,
   niska pouzdanost kamere. Pragove podešava terapeut. Ništa se ne menja automatski.
5. **Recovery Detective**: kratak sažetak po pacijentu; svaka tvrdnja ima izvore (datume zapisa) i oznaku pouzdanosti.
   Pravi se pravilima iz stvarnih zapisa (bez jezičkog modela), pa ne može da izmisli zaključke.
6. **HomeAdapt**: u proveri prostora pitanja o opremi, prostoru i postavljanju kamere. Ako vežba nije izvodljiva,
   aplikacija nudi zamene, a **samo terapeut odobrava** zamenu (nova verzija plana).
7. **Scan-to-Plan**: terapeut (ili pacijent) slika papirni plan; prepoznaju se nazivi propisanih vežbi i doziranje,
   terapeut proverava u Therapy Builder-u i šalje. Iz same dijagnoze se ne propisuje terapija.

Probni nalog terapeuta u priloženoj bazi (ako postoji `data\db.json`): `test@primer.rs` / `tajna123`.

## Novo u verziji 5: AI program iz izveštaja

- Terapeut (Therapy Builder → „AI asistent“) ili pacijent (ekran „Slikaj izveštaj“) nalepi ili slika izveštaj u bilo kom obliku.
- Server šalje izveštaj Claude-u (`claude-opus-5-5`) sa pretragom interneta. AI tumači problem (dijagnoza, strana, iritabilnost,
  nalazi, opseg pokreta, upozorenja, ciljevi), proverava preporuke (smernice, NICE, JOSPT, Physiopedia…) i predlaže program.
- Vežbe koje kamera prati dobijaju ciljni i maksimalni opseg (°) iz izveštaja; ostale vežbe (npr. klizanje nerva, most,
  nagib karlice) idu kao „vežbe bez kamere“ sa uputstvom, a u vođenoj terapiji se broje dugmetom ili tajmerom zadržavanja.
- Rezultat je uvek predlog: kod terapeuta se puni u Therapy Builder, povezan pacijent ga šalje terapeutu na odobrenje,
  a nepovezan pacijent ga može koristiti kao lokalni program uz upozorenje.
- **Potreban je Anthropic API ključ** (console.anthropic.com): unosi se jednom u Therapy Builder-u (čuva se u `data\config.json`)
  ili kao promenljiva okruženja `ANTHROPIC_API_KEY`. Bez naloga je dozvoljeno najviše 5 AI analiza na sat po korisniku.
- Šablon zahteva i uputstvo za AI: `ai/program-template.json`.
- **Demo režim:** dok API ključ nije unet, AI posle ~9 s vraća unapred pripremljen odgovor iz `ai/demo/`
  (rame ili leđa, srpski ili engleski, bira se po tekstu izveštaja). Rezultat nosi oznaku „Demo režim“.
  Čim se unese ključ, radi prava AI analiza bilo kog izveštaja.

## Struktura

| Fajl | Uloga |
|---|---|
| `js/exercises.js` | baza vežbi: opis, pragovi, pravila za greške, ključni položaji animacije |
| `js/engine.js` | brojanje ponavljanja i praćenje grešaka |
| `js/geometry.js` | uglovi i mere nad tačkama tela |
| `js/avatar.js` | animirani demonstrator |
| `js/coach.js` | poruke, glas, zvučni signali |
| `js/app.js` | ekrani, kamera, tok treninga, provera prostora, dnevnik, skeniranje |
| `js/i18n.js`, `js/exercises-en.js` | prevodi (srpski / engleski) |
| `js/store.js` | profil, treninzi, dnevnik i program (čuvaju se na uređaju) |
| `js/vision.js` | učitavanje MediaPipe modela (poza i predmeti) |
| `js/space.js` | provera prostora |
| `js/report.js` | izveštaj za fizioterapeuta |
| `js/ocr.js` | čitanje slike izveštaja i predlog vežbi |

Nova vežba se dodaje kao novi objekat u `EXERCISES` (`js/exercises.js`).

## Ograničenja

- Pragovi uglova su postavljeni okvirno i treba ih podesiti sa fizioterapeutom i testiranjem na ljudima.
- Kamera vidi 2D sliku: pokreti ka kameri (npr. pregibanje lakta spreda) mere se manje precizno.
- Srpski glas zavisi od uređaja. Ako ga nema, koristi se hrvatski/bosanski ako postoji, inače podrazumevani glas.
- Prototip nije medicinski uređaj.
