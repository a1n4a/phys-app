// Povratna informacija korisniku: poruka na ekranu, glas i kratki zvučni signali.
import { getLang, onLangChange, t } from './i18n.js';

const NUM = ['nula', 'jedan', 'dva', 'tri', 'četiri', 'pet', 'šest', 'sedam', 'osam', 'devet', 'deset',
  'jedanaest', 'dvanaest', 'trinaest', 'četrnaest', 'petnaest', 'šesnaest', 'sedamnaest', 'osamnaest', 'devetnaest', 'dvadeset'];
export const numberWord = (n) => (getLang() === 'en' ? String(n) : NUM[n] || String(n));

export class Coach {
  constructor(banner) {
    this.banner = banner;
    this.voiceOn = true;
    this.voice = null;
    this.lastSaid = {};
    this.lastWarn = 0;
    this.transient = null;
    this.audio = null;
    this.pickVoice();
    if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => this.pickVoice();
    onLangChange(() => this.pickVoice());
  }

  pickVoice() {
    if (!('speechSynthesis' in window)) return;
    const vs = speechSynthesis.getVoices();
    this.voice = getLang() === 'en'
      ? vs.find((v) => /^en-(GB|US)/i.test(v.lang)) || vs.find((v) => /^en/i.test(v.lang)) || null
      : vs.find((v) => /^sr/i.test(v.lang)) || vs.find((v) => /^(hr|bs)/i.test(v.lang)) || null;
  }

  hasLocalVoice() { return !!this.voice; }

  unlockAudio() {
    try {
      this.audio = this.audio || new (window.AudioContext || window.webkitAudioContext)();
      if (this.audio.state === 'suspended') this.audio.resume();
    } catch { this.audio = null; }
  }

  // Zvučni signali: good = tačno ponavljanje (akord naviše), done = kraj vežbe, warn = greška, tick = odbrojavanje
  tone(kind) {
    const a = this.audio;
    if (!a) return;
    const SOUNDS = {
      good: { type: 'sine', gain: 0.35, len: 0.22, notes: [[523, 0], [659, 0.08], [784, 0.16], [1047, 0.24]] },
      done: { type: 'sine', gain: 0.35, len: 0.35, notes: [[523, 0], [659, 0.12], [784, 0.24], [1047, 0.36], [784, 0.52], [1047, 0.64]] },
      warn: { type: 'triangle', gain: 0.3, len: 0.2, notes: [[247, 0], [196, 0.14]] },
      tick: { type: 'sine', gain: 0.25, len: 0.12, notes: [[880, 0]] },
    };
    const s = SOUNDS[kind] || SOUNDS.tick;
    for (const [f, t0] of s.notes) {
      const o = a.createOscillator(), g = a.createGain();
      o.type = s.type;
      o.frequency.value = f;
      const at = a.currentTime + t0;
      g.gain.setValueAtTime(0.0001, at);
      g.gain.exponentialRampToValueAtTime(s.gain, at + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, at + s.len);
      o.connect(g).connect(a.destination);
      o.start(at); o.stop(at + s.len + 0.02);
    }
  }

  say(text, interrupt = false) {
    if (!this.voiceOn || !text) return;
    // Android aplikacija: govor preko sistemskog sintetizatora (pouzdaniji od govora u WebView-u)
    if (window.AndroidTTS) {
      try { window.AndroidTTS.speak(text, getLang(), interrupt); this.lastSpeak = performance.now(); } catch { /* */ }
      return;
    }
    if (!('speechSynthesis' in window)) return;
    if (interrupt) speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    if (this.voice) u.voice = this.voice;
    u.lang = this.voice ? this.voice.lang : (getLang() === 'en' ? 'en-US' : 'sr-RS');
    u.rate = 1.0;
    u.volume = 1; // puna jačina, da se čuje na zvučniku sa udaljenosti
    this.lastSpeak = performance.now();
    speechSynthesis.speak(u);
  }

  // Komanda sa ekrana se izgovara naglas, ali ista poruka ne češće od jednom u `gap` ms
  // i ne preko poruke koja se upravo izgovara (upozorenja imaju prednost)
  command(text, gap = 7000) {
    if (!text) return;
    const spoken = text.replace(/[\d.,]+\s*s\b/g, '').replace(/[·…]+\s*$/, '').trim();
    const key = 'cmd:' + spoken;
    const now = performance.now();
    if (now - (this.lastSaid[key] || 0) < gap) return;
    if (this.isSpeaking()) return;
    this.lastSaid[key] = now;
    this.say(spoken);
  }

  // Privremena poruka (npr. "Odlično!"); speak = izgovori je
  flash(text, kind = 'info', ms = 1800, speak = false) {
    this.transient = { text, kind, until: performance.now() + ms };
    if (speak) this.say(text);
  }

  // Upozorenje sa pauzom između ponavljanja iste poruke
  warn(id, text) {
    const now = performance.now();
    if (now - (this.lastSaid[id] || 0) < 4500 || now - this.lastWarn < 1400) return false;
    this.lastSaid[id] = now;
    this.lastWarn = now;
    this.tone('warn');
    this.say(text, true);
    return true;
  }

  // Poziva se svakog kadra: aktivna greška ima prednost nad svim ostalim
  // mildText: odstupanje u okviru tolerancije, samo savet na ekranu (bez glasa i bez kazne)
  render(liveError, idleText, mildText = null) {
    let text = idleText, kind = 'info', speak = null, gap = 7000;
    const tr = this.transient;
    if (liveError) { text = liveError; kind = 'warn'; } // upozorenje se izgovara kroz warn()
    else if (tr && tr.until > performance.now()) { text = tr.text; kind = tr.kind; }
    else if (mildText) { text = t('tip') + ': ' + mildText.charAt(0).toLowerCase() + mildText.slice(1); kind = 'mild'; speak = mildText; gap = 9000; }
    else speak = idleText;
    if (this.banner.textContent !== text) this.banner.textContent = text || '';
    if (this.banner.dataset.kind !== kind) this.banner.dataset.kind = kind;
    if (speak) this.command(speak, gap);
  }

  isSpeaking() {
    if (window.AndroidTTS) { try { return !!window.AndroidTTS.isSpeaking(); } catch { return false; } }
    return 'speechSynthesis' in window && speechSynthesis.speaking;
  }

  stop() {
    if (window.AndroidTTS) { try { window.AndroidTTS.stop(); } catch { /* */ } return; }
    if ('speechSynthesis' in window) speechSynthesis.cancel();
  }
}
