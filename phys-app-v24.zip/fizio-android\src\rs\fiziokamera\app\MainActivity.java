package rs.fiziokamera.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * FizioKamera za Android.
 * Cela web aplikacija je spakovana u assets/www i učitava se sa https://appassets.androidplatform.net/
 * (bezbedna adresa, pa kamera radi). Aplikacija daje: dozvolu za kameru, govor preko sistemskog
 * sintetizatora (window.AndroidTTS), izbor fajla ili slikanje izveštaja i ekran koji se ne gasi tokom vežbe.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/index.html";
    private static final int REQ_CAMERA = 1;
    private static final int REQ_FILE = 2;
    private static final int REQ_CAMERA_FILE = 3;

    private WebView web;
    private PermissionRequest pendingPermission;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraOutput;
    private String[] pendingAccept;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;

    private static final Map<String, String> MIME = new HashMap<>();
    static {
        MIME.put("html", "text/html"); MIME.put("js", "text/javascript"); MIME.put("mjs", "text/javascript");
        MIME.put("css", "text/css"); MIME.put("json", "application/json"); MIME.put("svg", "image/svg+xml");
        MIME.put("png", "image/png"); MIME.put("jpg", "image/jpeg"); MIME.put("jpeg", "image/jpeg");
        MIME.put("webp", "image/webp"); MIME.put("mp4", "video/mp4"); MIME.put("webm", "video/webm");
        MIME.put("md", "text/plain"); MIME.put("txt", "text/plain"); MIME.put("wasm", "application/wasm");
        MIME.put("pdf", "application/pdf");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#0D2F5A"));

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        WebView.setWebContentsDebuggingEnabled(true);

        web.addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        web.setWebViewClient(new AppClient());
        web.setWebChromeClient(new AppChrome());

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) { ttsReady = (status == TextToSpeech.SUCCESS); }
        });

        // kamera je osnova aplikacije, pa se dozvola traži odmah
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    // ── fajlovi aplikacije iz assets/www ──
    private class AppClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (!HOST.equals(u.getHost())) return null; // ostalo (CDN, server) ide na internet
            String path = u.getPath();
            if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
            try {
                InputStream in = getAssets().open("www" + path);
                String ext = path.contains(".") ? path.substring(path.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT) : "";
                String mime = MIME.containsKey(ext) ? MIME.get(ext) : "application/octet-stream";
                WebResourceResponse r = new WebResourceResponse(mime, "UTF-8", in);
                Map<String, String> h = new HashMap<>();
                h.put("Cache-Control", "no-cache");
                h.put("Access-Control-Allow-Origin", "*");
                r.setResponseHeaders(h);
                return r;
            } catch (IOException e) {
                WebResourceResponse r = new WebResourceResponse("text/plain", "UTF-8", null);
                r.setStatusCodeAndReasonPhrase(404, "Not Found");
                return r;
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (HOST.equals(u.getHost())) return false;
            // spoljni linkovi (izvori preporuka i sl.) otvaraju se u browseru
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
            return true;
        }
    }

    // ── kamera (getUserMedia) i izbor fajla ──
    private class AppChrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(new Runnable() { @Override public void run() {
                boolean wantsCamera = false;
                for (String r : request.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera = true;
                if (!wantsCamera) { request.deny(); return; }
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    pendingPermission = request;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                }
            } });
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            boolean capture = params.isCaptureEnabled();
            String[] accept = params.getAcceptTypes();
            // kamera za slikanje/snimanje traži dozvolu: prvo je zatraži, pa tek onda otvori kameru
            if (capture && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                pendingAccept = accept;
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_FILE);
                return true;
            }
            return openChooser(capture, accept);
        }
    }

    // Otvara kameru (slika ili video, prema accept) ili izbor fajla. Bez dozvole za kameru: izbor fajla.
    private boolean openChooser(boolean capture, String[] accept) {
        cameraOutput = null;
        Intent intent;
        boolean wantsVideo = false;
        for (String m : mimeTypes(accept)) if (m.startsWith("video/")) wantsVideo = true;
        boolean camOk = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        if (capture && camOk && wantsVideo) {
            // <input accept="video/*" capture>: snimanje videa (nova vežba iz videa)
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Video.Media.DISPLAY_NAME, "vezba_" + System.currentTimeMillis() + ".mp4");
                cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FizioKamera");
                cameraOutput = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
            }
            intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            if (cameraOutput != null) {
                intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutput);
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
        } else if (capture && camOk && Build.VERSION.SDK_INT >= 29) {
            // <input capture> ("Slikaj izveštaj"): slika se čuva u Pictures/FizioKamera
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "izvestaj_" + System.currentTimeMillis() + ".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FizioKamera");
            cameraOutput = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutput);
        } else {
            intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            String[] mimes = mimeTypes(accept);
            if (mimes.length > 0) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
        }
        try {
            startActivityForResult(intent, REQ_FILE);
        } catch (ActivityNotFoundException | SecurityException e) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = null;
            return false;
        }
        return true;
    }

        // accept="image/*,application/pdf,.pdf,.docx,.txt" -> MIME tipovi za Android
    private static String[] mimeTypes(String[] accept) {
        List<String> out = new ArrayList<>();
        if (accept != null) for (String a : accept) for (String part : a.split(",")) {
            String p = part.trim().toLowerCase(Locale.ROOT);
            if (p.isEmpty()) continue;
            if (p.contains("/")) { if (!out.contains(p)) out.add(p); continue; }
            String m = null;
            if (p.equals(".pdf")) m = "application/pdf";
            else if (p.equals(".docx")) m = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            else if (p.equals(".txt") || p.equals(".md")) m = "text/plain";
            if (m != null && !out.contains(m)) out.add(m);
        }
        return out.toArray(new String[0]);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            // neke kamere za video ignorišu zadatu putanju i vraćaju svoju: tada se koristi njihov snimak
            if (cameraOutput != null && data != null && data.getData() != null && !data.getData().equals(cameraOutput)) {
                try { getContentResolver().delete(cameraOutput, null, null); } catch (Exception ignored) { }
                result = new Uri[]{data.getData()};
            }
            else if (cameraOutput != null) result = new Uri[]{cameraOutput};
            else if (data != null && data.getData() != null) result = new Uri[]{data.getData()};
            else if (data != null && data.getClipData() != null && data.getClipData().getItemCount() > 0)
                result = new Uri[]{data.getClipData().getItemAt(0).getUri()};
        } else if (cameraOutput != null) {
            try { getContentResolver().delete(cameraOutput, null, null); } catch (Exception ignored) { }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
        cameraOutput = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_CAMERA_FILE) {
            if (fileCallback != null) openChooser(true, pendingAccept);
            pendingAccept = null;
            return;
        }
        if (requestCode != REQ_CAMERA || pendingPermission == null) return;
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (ok) pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        else pendingPermission.deny();
        pendingPermission = null;
    }

    // ── govor: window.AndroidTTS ──
    private class TtsBridge {
        @JavascriptInterface
        public void speak(String text, String lang, boolean interrupt) {
            if (!ttsReady || text == null) return;
            Locale loc = (lang != null && lang.startsWith("en")) ? Locale.US : new Locale("sr", "RS");
            if (!loc.getLanguage().equals("en") && tts.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) {
                // ako nema srpskog glasa, probaj hrvatski ili bosanski (isti izgovor latinice)
                Locale hr = new Locale("hr", "HR"), bs = new Locale("bs", "BA");
                if (tts.isLanguageAvailable(hr) >= TextToSpeech.LANG_AVAILABLE) loc = hr;
                else if (tts.isLanguageAvailable(bs) >= TextToSpeech.LANG_AVAILABLE) loc = bs;
            }
            tts.setLanguage(loc);
            Bundle params = new Bundle();
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
            tts.speak(text, interrupt ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, params, "fk" + System.nanoTime());
        }

        @JavascriptInterface
        public void stop() { if (tts != null) tts.stop(); }

        @JavascriptInterface
        public boolean isSpeaking() { return tts != null && tts.isSpeaking(); }

        @JavascriptInterface
        public boolean ready() { return ttsReady; }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) { web.destroy(); }
        super.onDestroy();
    }
}
