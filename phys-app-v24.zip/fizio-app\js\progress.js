// Kvalitet izvođenja i poređenje sa ranijim sesijama.
//
// Kvalitet izvođenja (0–100) za jednu sesiju:
//   oblik pokreta 40 % : deo vremena vežbanja bez greške (blago odstupanje se računa kao 40 % greške)
//   tačnost       30 % : pravilno izvedena ponavljanja / sva ponavljanja
//   opseg         30 % : prosečan dostignuti ugao / ciljni ugao (najviše 100 %)
// Odstupanje od pravilnog izvođenja (%) = 100 − oblik pokreta.

import { getSessions, startOfDay } from './store.js';
import { byId } from './exercises.js';
import { t, exText, locale } from './i18n.js';
import { lineChart } from './report.js';

const DAY = 86400000;
const avg = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : null);
const clamp01 = (v) => Math.max(0, Math.min(1, v));
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// fs = {total, err, mild} broj kadrova tokom vežbanja; target = ciljni ugao vežbe
export function computeQuality({ reps, good, romPeaks, fs, target }) {
  if (!reps) return null;
  const total = fs && fs.total ? fs.total : 0;
  const form = total ? clamp01(1 - (fs.err + 0.4 * fs.mild) / total) : 1;
  const acc = clamp01(good / reps);
  const peak = avg(romPeaks || []);
  const rom = target && peak != null ? clamp01(peak / target) : 1;
  return {
    quality: Math.round(100 * (0.4 * form + 0.3 * acc + 0.3 * rom)),
    formScore: Math.round(100 * form),
    deviation: Math.round(100 * (1 - form)),
    romPct: Math.round(100 * rom),
    romAvg: peak == null ? null : Math.round(peak),
    accuracy: Math.round(100 * acc),
    target: target || null,
  };
}

// Sesije iste vežbe sa izmerenim kvalitetom, od najstarije
export function historyFor(exId) {
  return getSessions().filter((s) => s.exId === exId && typeof s.quality === 'number').sort((a, b) => a.date - b.date);
}

const sign = (v, unit = '') => (v > 0 ? '+' : v < 0 ? '−' : '±') + Math.abs(v) + unit;
// veće je bolje za kvalitet/opseg/tačnost, manje je bolje za odstupanje
function cls(v, lowerIsBetter = false) {
  if (Math.abs(v) < 1) return 'same';
  return (lowerIsBetter ? v < 0 : v > 0) ? 'up' : 'down';
}
function verdict(dq) {
  if (dq >= 3) return { key: 'cmpBetter', cls: 'up' };
  if (dq <= -3) return { key: 'cmpWorse', cls: 'down' };
  return { key: 'cmpSame', cls: 'same' };
}

// Detaljno poređenje za rezime jedne vežbe
export function compareBlock(rec) {
  if (!rec || typeof rec.quality !== 'number') return `<p class="muted">${t('cmpNoCam')}</p>`;
  const hist = historyFor(rec.exId);
  const prev = hist.filter((s) => s.id !== rec.id && s.date < rec.date);
  const ex = byId(rec.exId);
  let html = `<h2 class="label">${t('cmpObjective')}</h2>`;
  if (!prev.length) return html + `<p class="notice">${t('cmpFirstTime')}</p>`;

  const last = prev[prev.length - 1], first = prev[0];
  const avgQ = Math.round(avg(prev.map((s) => s.quality)));
  const dq = rec.quality - last.quality;
  const v = verdict(dq);
  const row = (label, cur, l, f, a, unit = '', lower = false) => {
    const d1 = cur - l, d2 = cur - f;
    return `<tr><td>${label}</td><td><strong>${cur}${unit}</strong></td>
      <td><span class="${cls(d1, lower)}">${sign(d1, unit)}</span></td>
      <td><span class="${cls(d2, lower)}">${sign(d2, unit)}</span></td>
      <td>${a == null ? '–' : a + unit}</td></tr>`;
  };
  const avgOf = (k) => { const x = prev.map((s) => s[k]).filter((n) => typeof n === 'number'); return x.length ? Math.round(avg(x)) : null; };
  html += `<p class="verdict v-${v.cls}">${t(v.key)} · ${t('cmpVerdict', { dq: sign(dq), n: prev.length })}</p>
  <div class="table-wrap"><table class="rp-table cmp">
    <thead><tr><th></th><th>${t('cmpNow')}</th><th>${t('cmpVsLast')}</th><th>${t('cmpVsFirst')}</th><th>${t('cmpAvg')}</th></tr></thead>
    <tbody>
      ${row(t('cmpQuality'), rec.quality, last.quality, first.quality, avgQ)}
      ${rec.deviation != null && last.deviation != null ? row(t('cmpDev'), rec.deviation, last.deviation, first.deviation ?? last.deviation, avgOf('deviation'), ' %', true) : ''}
      ${rec.romAvg != null && last.romAvg != null ? row(t('cmpRom'), rec.romAvg, last.romAvg, first.romAvg ?? last.romAvg, avgOf('romAvg'), '°') : ''}
      ${rec.accuracy != null && last.accuracy != null ? row(t('cmpAcc'), rec.accuracy, last.accuracy, first.accuracy ?? last.accuracy, avgOf('accuracy'), ' %') : ''}
    </tbody></table></div>`;

  // kvalitet kroz vreme za ovu vežbu (sve sesije, uključujući ovu)
  const all = [...prev, rec].slice(-20);
  html += `<h3 class="label">${t('cmpTrend')} · ${esc(ex ? exText(ex, 'name') : rec.exId)}</h3>` +
    lineChart({ series: [{ name: t('cmpQualityShort'), color: 'var(--c1)', values: all.map((s) => s.quality) }],
      labels: all.map((s) => new Date(s.date).toLocaleDateString(locale(), { day: 'numeric', month: 'numeric' })),
      yMin: 0, yMax: 100, yTicks: [0, 50, 100], aria: t('cmpTrend') });
  return html;
}

// Kratko poređenje (za rezime vođene terapije)
export function compareShort(rec) {
  if (!rec || typeof rec.quality !== 'number') return '';
  const prev = historyFor(rec.exId).filter((s) => s.id !== rec.id && s.date < rec.date);
  if (!prev.length) return `${t('cmpQuality')} ${rec.quality} · ${t('cmpFirstShort')}`;
  const d = rec.quality - prev[prev.length - 1].quality;
  return `${t('cmpQuality')} ${rec.quality} (<span class="${cls(d)}">${sign(d)}</span> ${t('cmpVsLastShort')})`;
}

// Ukupno kroz vreme, sve vežbe
export function overallBlock(now = Date.now()) {
  const all = getSessions().filter((s) => typeof s.quality === 'number').sort((a, b) => a.date - b.date);
  if (all.length < 2) return '';
  const today = startOfDay(now);
  const wk = all.filter((s) => s.date >= today - 6 * DAY), prevWk = all.filter((s) => s.date >= today - 13 * DAY && s.date < today - 6 * DAY);
  const a = wk.length ? Math.round(avg(wk.map((s) => s.quality))) : null, b = prevWk.length ? Math.round(avg(prevWk.map((s) => s.quality))) : null;
  const firstQ = Math.round(avg(all.slice(0, Math.min(3, all.length)).map((s) => s.quality)));
  const lastQ = Math.round(avg(all.slice(-Math.min(3, all.length)).map((s) => s.quality)));
  const days = Array.from({ length: 14 }, (_, i) => today - (13 - i) * DAY);
  const vals = days.map((d) => { const x = all.filter((s) => s.date >= d && s.date < d + DAY).map((s) => s.quality); return x.length ? Math.round(avg(x)) : null; });
  const d = lastQ - firstQ;
  return `<h2 class="label">${t('cmpOverall')}</h2>
    <p>${t('cmpSessions', { n: all.length, d: new Date(all[0].date).toLocaleDateString(locale(), { day: 'numeric', month: 'long' }) })}
      · ${t('cmpSinceStart', { a: firstQ, b: lastQ })} <span class="${cls(d)}">${sign(d)}</span></p>
    ${a != null ? `<p>${t('cmpWeek', { a, b: b == null ? '–' : b })}</p>` : ''}
    ${vals.filter((v) => v != null).length >= 2 ? lineChart({ series: [{ name: t('cmpQualityShort'), color: 'var(--c1)', values: vals }],
      labels: days.map((x) => new Date(x).toLocaleDateString(locale(), { day: 'numeric', month: 'numeric' })), yMin: 0, yMax: 100, yTicks: [0, 50, 100], aria: t('cmpOverall') }) : ''}
    <p class="muted small">${t('cmpHow')}</p>`;
}
