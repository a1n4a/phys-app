// Komunikacija sa serverom (start.ps1). Terapeut i pacijent imaju odvojene prijave,
// pa isti uređaj može da služi za oba (zgodno za probu).

import { DEFAULT_SERVER } from './app-config.js';

// U Android aplikaciji stranica se učitava iz same aplikacije (appassets.androidplatform.net),
// pa API ide na server čija je adresa podešena (klinika, AI, povezivanje sa terapeutom).
export const IN_APP = location.hostname === 'appassets.androidplatform.net';
export function serverBase() {
  if (!IN_APP) return '';
  let s = '';
  try { s = localStorage.getItem('fizio-server') || ''; } catch { /* */ }
  s = (s || DEFAULT_SERVER || '').trim();
  return s ? s.replace(/\/+$/, '') + '/' : '';
}
export function setServer(url) {
  try { localStorage.setItem('fizio-server', (url || '').trim()); } catch { /* */ }
}

const key = (role) => `fizio-auth-${role}`;
export function auth(role) {
  try { return JSON.parse(localStorage.getItem(key(role)) || 'null'); } catch { return null; }
}
function setAuth(role, a) { try { localStorage.setItem(key(role), JSON.stringify(a)); } catch { /* */ } }
export function logout(role) { try { localStorage.removeItem(key(role)); } catch { /* */ } }

async function call(path, body, role) {
  const a = role ? auth(role) : null;
  let r;
  try {
    if (IN_APP && !serverBase()) throw new Error('no_server');
    r = await fetch(serverBase() + 'api/' + path, {
      method: body ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', ...(a ? { Authorization: 'Bearer ' + a.token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw Object.assign(new Error('offline'), { code: 'offline' });
  }
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && role) logout(role);
  if (!r.ok) throw Object.assign(new Error(j.error || String(r.status)), { code: j.error || String(r.status) });
  return j;
}

export async function register(name, email, password) {
  const j = await call('register', { name, email, password });
  setAuth('therapist', j); return j;
}
export async function login(email, password) {
  const j = await call('login', { email, password });
  setAuth('therapist', j); return j;
}
export async function join(code) {
  const j = await call('join', { code });
  setAuth('patient', j); return j;
}
export const getData = (role) => call('data', null, role);
export const callApi = call;
export const put = (role, coll, doc) => call('put', { coll, doc }, role);

// Grupisanje dokumenata po vrsti
export function group(docs) {
  const g = { patient: [], plan: [], session: [], log: [], report: [], proposal: [], home: [] };
  for (const d of docs || []) {
    if (!d.date && d.createdAt) d.date = d.createdAt;
    (g[d.coll] = g[d.coll] || []).push(d);
  }
  for (const k of Object.keys(g)) g[k].sort((a, b) => (a.date || a.createdAt || 0) - (b.date || b.createdAt || 0));
  return g;
}

// Najnovija verzija plana za pacijenta
export function latestPlan(plans, patientId) {
  return plans.filter((p) => p.patientId === patientId).sort((a, b) => (b.version || 0) - (a.version || 0))[0] || null;
}
