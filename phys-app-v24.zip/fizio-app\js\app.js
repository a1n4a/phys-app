import { EXERCISES, REGIONS, byId } from './exercises.js';
import { createPlayer, refreshAllColors } from './avatar.js';
import { Coach, numberWord } from './coach.js';
import { RepEngine } from './engine.js';
import { LM, J, mid, dist, trunkLean, fromVertical, lineAngle, angleDiff, clamp, DEG } from './geometry.js';
import { t, getLang, setLang, onLangChange, exText, errText, regionText, locale, applyStatic } from './i18n.js';
import { getProfile, setProfile, profileOrDefault, getSessions, addSession, getLogs, addLog, updateLog, reportStatus, clearAll, getHome, setHome } from './store.js';
import { getLandmarker, getDetector } from './vision.js';
import { analyzeSpace, measureLight, bodyBox, feasibility, alternatives } from './space.js';
import { recognize, suggest, parsePlan } from './ocr.js';
import { collect, renderReport, reportCsv, reportText } from './report.js';
import * as api from './api.js';
import { mountClinic, routeClinic, saveBuilderDraft } from './clinic.js';
import { generate as aiGenerate, errorText as aiErrorText, renderResult as aiRender, toPlanItems, itemName, itemNote, customField,
  programFor, aiPlanNote, aiPlanNotes, aiSummaries, planSummary, planShortTitle, planNote } from './ai.js';
import { getLocalPlans, getLocalPlan, addLocalPlan, removeLocalPlan, reportStatusFrom, startOfDay } from './store.js';
import { readReport, ACCEPT } from './docs.js';
import { computeQuality, compareBlock, compareShort, overallBlock } from './progress.js';
import { PRESETS, presetById, presetResult, bodySvg, presetShort } from './presets.js';
import { extractPoses, analyze, buildExercise, loadSpecs, saveSpec, deleteSpec, putVideo, getVideo, drawPose } from './videx.js';

// vežbe napravljene iz videa: dodaju se u biblioteku pri pokretanju (snimci se učitavaju u pozadini)
for (const spec of loadSpecs()) {
  try {
    const ex = buildExercise(spec);
    EXERCISES.push(ex);
    if (spec.hasVideo) getVideo(spec.id).then((b) => { if (b) ex.videoUrl = URL.createObjectURL(b); });
  } catch { /* oštećen zapis se preskače */ }
}

const $ = (id) => document.getElementById(id);
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const VIEWS = ['home', 'preset', 'programs', 'program', 'pedit', 'library', 'detail', 'session', 'summary', 'journal', 'report', 'scan', 'clinic', 'join', 'gstep', 'gsummary', 'vimport'];
// koji tab je aktivan za koji ekran
const TAB_OF = { home: 'home', preset: 'home', scan: 'scan', journal: 'journal', report: 'journal', programs: 'programs', program: 'programs', pedit: 'programs', library: 'library', detail: 'library', summary: 'library', vimport: 'library', gstep: 'programs', gsummary: 'programs' };
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const state = {
  view: 'home',
  region: 'all',
  ex: null,
  reps: 10,
  videos: {},
  homePlayers: [],
  detailPlayer: null,
  tol: loadTol(),
  reportDays: 3,
  lastSessionId: null,
  scan: null,
  item: null,          // stavka plana terapeuta za vežbu koja je u toku (opseg, strana, tolerancija)
  clinicSub: '',
};
const pt = { data: null }; // podaci povezanog pacijenta: {me, therapistName, g, plan}
// vođena terapija: vežbe iz plana redom, sa serijama i pauzama
const guided = { on: false, id: '', items: [], i: 0, set: 1, results: [], exRecs: [], pending: null, restUntil: 0, timer: null, synced: true, prevPhase: null,
  planId: null, presetId: null, programName: '', logId: null, logPending: false };

function loadTol() {
  try { const v = Number(localStorage.getItem('fizio-tol')); return [0.05, 0.1, 0.15].includes(v) ? v : 0.1; } catch { return 0.1; }
}
const unitDays = (n) => (n === 1 ? t('day1') : t('dayN'));
function defaultReps(ex) {
  const planItem = pt.data && pt.data.plan && pt.data.plan.items.find((i) => i.exId === ex.id);
  if (planItem && planItem.reps) return planItem.reps;
  const prog = getLocalPlans().flatMap((p) => p.items || []).find((i) => i.exId === ex.id);
  if (prog && prog.reps) return prog.reps;
  return profileOrDefault().age === 'child' ? Math.max(3, Math.round(ex.defaultReps * 0.7)) : ex.defaultReps;
}

// ─────────────────────────── jezik i profil ───────────────────────────
function syncLangButtons() {
  document.querySelectorAll('#lang-seg button').forEach((b) => b.classList.toggle('on', b.dataset.lang === getLang()));
}
document.querySelectorAll('#lang-seg button').forEach((b) => b.addEventListener('click', () => setLang(b.dataset.lang)));
onLangChange(() => { applyStatic(); syncLangButtons(); profileLabel(); rerender(); });

function rerender() {
  if (state.view === 'home') renderHome();
  if (state.view === 'library') renderLibrary();
  if (state.view === 'programs') renderPrograms();
  if (state.view === 'program' && state.programId) renderProgram(state.programId);
  if (state.view === 'pedit') renderEditor();
  if (state.view === 'preset' && state.presetId) renderPreset(state.presetId);
  if (state.view === 'join') renderJoin();
  if (state.view === 'detail' && state.ex) fillDetailTexts(state.ex);
  if (state.view === 'summary') renderSummary();
  if (state.view === 'journal') renderJournal();
  if (state.view === 'report') renderReportView();
  if (state.view === 'scan' && state.scan) renderScanResults(state.scan);
  if (state.view === 'scan') showScanAi();
  if (state.view === 'clinic') {
    // u Therapy Builder-u sačuvaj nesačuvane izmene pre ponovnog iscrtavanja na drugom jeziku
    if ((state.clinicSub || '').startsWith('plan-')) saveBuilderDraft();
    routeClinic(state.clinicSub || '');
  }
  if (state.view === 'gstep') renderStep();
  if (state.view === 'vimport' && !vx.busy) { if (vx.result) renderImportResult(); else renderImportStart(); }
  if (state.view === 'gsummary') renderGSummary();
}

function profileLabel() {
  const p = getProfile();
  $('profile-label').textContent = p
    ? (p.age === 'child' ? (p.sex === 'f' ? t('pGirl') : t('pBoy')) : (p.sex === 'f' ? t('pWoman') : t('pMan')))
    : t('profile');
}
function openProfile() {
  const p = getProfile() || {};
  const f = $('profile-form');
  for (const el of f.querySelectorAll('input[type=radio]')) {
    el.checked = (el.name === 'lang' && el.value === getLang()) || (el.name === 'sex' && el.value === p.sex) || (el.name === 'age' && el.value === p.age);
  }
  // Android aplikacija: adresa servera za kliniku, AI i povezivanje sa terapeutom
  clearArmed = false; $('btn-clear').textContent = t('clearDevice');
  $('server-field').hidden = !api.IN_APP;
  if (api.IN_APP) $('server-url').value = api.serverBase().replace(/\/$/, '');
  $('dlg-profile').showModal();
}
$('btn-profile').addEventListener('click', openProfile);
$('profile-form').addEventListener('submit', () => {
  const fd = new FormData($('profile-form'));
  setProfile({ sex: fd.get('sex') || 'm', age: fd.get('age') || 'adult' });
  if (api.IN_APP) api.setServer($('server-url').value);
  if (fd.get('lang')) setLang(fd.get('lang'));
  profileLabel();
  refreshAllColors();
  if (state.view === 'detail' && state.ex) { state.reps = defaultReps(state.ex); $('reps-val').textContent = state.reps; }
});
// jezik u dijalogu se primenjuje odmah, da bi se ostatak dijaloga prikazao na izabranom jeziku
$('profile-form').addEventListener('change', (e) => { if (e.target.name === 'lang') setLang(e.target.value); });

// ─────────────────────────── snimci vežbi (opciono) ───────────────────────────
async function loadVideoManifest() {
  try {
    const r = await fetch('videos/videos.json', { cache: 'no-store' });
    if (r.ok) state.videos = await r.json();
  } catch { state.videos = {}; }
}
const videoFor = (ex) => (ex.videoUrl ? ex.videoUrl : state.videos[ex.id] ? 'videos/' + state.videos[ex.id] : null);

// ─────────────────────────── navigacija ───────────────────────────
function show(view) {
  if (state.view === 'gsummary' && view !== 'gsummary') flushProgramLog();
  state.view = view;
  for (const v of VIEWS) $('view-' + v).hidden = v !== view;
  // tokom terapije (vežba i pregled između vežbi) nema zaglavlja ni tabova, samo dugmad terapije
  const inTherapy = view === 'session' || view === 'gstep';
  $('btn-back').hidden = view === 'home' || inTherapy;
  document.querySelector('.topbar').hidden = inTherapy;
  // traka sa tabovima: sakrivena tokom vežbanja i u klinici (to je poseban deo za fizioterapeute)
  $('tabbar').hidden = inTherapy || view === 'clinic';
  document.body.classList.toggle('has-tabs', !$('tabbar').hidden);
  for (const a of $('tabbar').querySelectorAll('a')) {
    if (a.dataset.tab === TAB_OF[view]) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  }
  if (view !== 'home' && view !== 'library') destroyHomePlayers();
  window.scrollTo(0, 0);
}

// ručno označi aktivni tab (kada isti ekran pripada različitim tabovima)
function setTab(tab) {
  for (const a of $('tabbar').querySelectorAll('a')) { if (a.dataset.tab === tab) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); }
}

function route() {
  const id = location.hash.slice(1);
  // napuštanje terapije (npr. dugme Nazad na telefonu) = kraj terapije, sa unosom u dnevnik
  if (guided.on) { endGuided(); return; }
  if (session.running) stopSession(false);
  if (id === 'dnevnik') { show('journal'); renderJournal(); return; }
  if (id === 'izvestaj') { state.reportKey = null; state.reportBack = 'dnevnik'; show('report'); renderReportView(); return; }
  if (id.startsWith('izvestaj-')) { openProgramReport(decodeURIComponent(id.slice(9))); return; }
  if (id === 'skeniraj') { show('scan'); updateScanReset(); return; }
  if (id === 'povezi') { show('join'); $('join-msg').hidden = true; renderJoin(); return; }
  if (vx.busy && id !== 'nova-vezba' && vx.abort) vx.abort.abort(); // napušten ekran: prekini analizu
  if (id === 'vezbe') { openLibrary(); return; }
  if (id === 'nova-vezba') { openImport(); return; }
  if (id === 'programi') { show('programs'); renderPrograms(); return; }
  if (id.startsWith('uredi-')) { openEditor(id.slice(6)); return; }
  if (id.startsWith('moj-')) { state.programId = id.slice(4); show('program'); renderProgram(state.programId); return; }
  if (id.startsWith('program-') && presetById(id.slice(8))) { openPreset(id.slice(8)); return; }
  if (id === 'klinika' || id.startsWith('klinika-')) {
    state.clinicSub = id === 'klinika' ? '' : id.slice(8);
    show('clinic'); routeClinic(state.clinicSub); return;
  }
  const ex = id && byId(id);
  if (ex) openDetail(ex); else openHome();
}

$('btn-back').addEventListener('click', () => {
  if (state.view === 'report') location.hash = state.reportBack || 'dnevnik';
  else if (state.view === 'detail' || state.view === 'summary' || state.view === 'vimport') location.hash = 'vezbe';
  else if (state.view === 'pedit' && state.edit) location.hash = state.edit.fresh ? 'skeniraj' : 'moj-' + state.edit.srcId;
  else if (state.view === 'program' || state.view === 'gsummary') location.hash = 'programi';
  else location.hash = '';
});
$('brand').addEventListener('click', (e) => { e.preventDefault(); location.hash = ''; });
window.addEventListener('hashchange', route);

// ─────────────────────────── početna ───────────────────────────
function regionName(id) { const r = REGIONS.find((x) => x.id === id); return r ? regionText(r) : ''; }

function destroyHomePlayers() { state.homePlayers.forEach((p) => p.destroy()); state.homePlayers = []; }

function makeCard(ex, extra) {
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'card';
  b.innerHTML = `<canvas aria-hidden="true"></canvas>
    <div class="card-body"><h3></h3><p></p>
      <div class="tags"><span class="tag"></span><span class="tag cam"></span></div></div>`;
  b.querySelector('h3').textContent = exText(ex, 'name');
  b.querySelector('p').textContent = extra || exText(ex, 'summary');
  const tags = b.querySelectorAll('.tag');
  tags[0].textContent = regionName(ex.region);
  tags[1].textContent = ex.view === 'side' ? t('camSide') : t('camFront');
  if (ex.mine) b.querySelector('.tags').insertAdjacentHTML('beforeend', `<span class="tag mine">${t('vxMine')}</span>`);
  b.addEventListener('click', () => { location.hash = ex.id; });
  return b;
}
function attachPlayer(card, ex) {
  const pl = createPlayer(card.querySelector('canvas'), ex, { speed: 0.9 });
  pl.time = Math.random() * 3;
  if (reduceMotion) pl.showPeak();
  state.homePlayers.push(pl);
}

// Početna: samo gotovi programi (sve ostalo je u meniju na dnu)
function renderHome() {
  destroyHomePlayers();
  renderPresetList();
}

// Biranje vežbi: delovi tela sa strane, vežbe za izabrani deo
function openLibrary() {
  if (state.detailPlayer) { state.detailPlayer.destroy(); state.detailPlayer = null; }
  $('demo-video').pause();
  show('library');
  renderLibrary();
}

function renderLibrary() {
  destroyHomePlayers();
  renderRegions();
  renderGrid();
  renderHistory();
}

function renderRegions() {
  const box = $('regions');
  box.innerHTML = '';
  for (const r of [{ id: 'all' }, ...REGIONS]) {
    const n = r.id === 'all' ? EXERCISES.length : EXERCISES.filter((e) => e.region === r.id).length;
    if (!n) continue;
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'side-item'; b.setAttribute('role', 'tab');
    b.innerHTML = '<span></span><small></small>';
    b.firstChild.textContent = r.id === 'all' ? t('all') : regionText(r);
    b.lastChild.textContent = n;
    b.setAttribute('aria-selected', String(state.region === r.id));
    b.addEventListener('click', () => { state.region = r.id; renderRegions(); renderGrid(); });
    box.appendChild(b);
  }
}

function renderGrid() {
  // zadrži igrače iz programa, zameni samo one iz mreže
  const grid = $('exercise-grid');
  const keep = state.homePlayers.filter((p) => !grid.contains(p.canvas));
  state.homePlayers.filter((p) => !keep.includes(p)).forEach((p) => p.destroy());
  grid.innerHTML = '';
  const list = EXERCISES.filter((e) => state.region === 'all' || e.region === state.region);
  $('ex-count').textContent = list.length;
  $('lib-region-name').textContent = state.region === 'all' ? t('exercises') : regionName(state.region);
  for (const ex of list) { const c = makeCard(ex); grid.appendChild(c); attachPlayer(c, ex); }
}

function renderHistory() {
  const h = getSessions().slice(0, 5);
  $('history-wrap').hidden = !h.length;
  const ul = $('history'); ul.innerHTML = '';
  for (const it of h) {
    const li = document.createElement('li');
    const ex = byId(it.exId);
    li.innerHTML = '<span class="what"></span><span class="res"></span><span class="when"></span>';
    li.querySelector('.what').textContent = ex ? exText(ex, 'name') : it.exId;
    li.querySelector('.res').textContent = t('historyResult', { good: it.good, reps: it.reps });
    li.querySelector('.when').textContent = fmtDate(it.date);
    ul.appendChild(li);
  }
}
const fmtDate = (ts) => {
  const d = new Date(ts);
  return d.toLocaleDateString(locale(), { day: 'numeric', month: 'long' }) + ', ' + d.toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' });
};


function openHome() {
  if (state.detailPlayer) { state.detailPlayer.destroy(); state.detailPlayer = null; }
  $('demo-video').pause();
  show('home');
  renderHome();
}

// ─────────────────────────── pacijent povezan sa terapeutom ───────────────────────────
async function loadPatient() {
  if (!api.auth('patient')) { pt.data = null; return null; }
  try {
    const d = await api.getData('patient');
    const g = api.group(d.docs);
    pt.data = { me: d.me, therapistName: d.therapistName, g, plan: api.latestPlan(g.plan, d.me.id) };
  } catch { /* zadrži poslednje poznato stanje */ }
  return pt.data;
}
function syncPut(coll, doc) {
  if (!api.auth('patient')) return Promise.resolve(null);
  return api.put('patient', coll, doc).then(() => true).catch(() => false);
}
const isToday = (plan) => !plan || !plan.days || !plan.days.length || plan.days.includes(new Date().getDay() || 7);

const validItem = (i) => !!(i.custom || byId(i.exId));

function planItemsHtml(plan) {
  return `<ol class="th-items">${plan.items.filter(validItem).map((i) => {
    const dose = `${i.sets} × ${i.reps}${i.custom && i.custom.holdSec ? ` × ${i.custom.holdSec} s` : ''}`;
    const extra = `${i.side && i.side !== 'both' ? ' · ' + t('side_' + i.side) : ''}${i.romTarget ? ' · ' + t('aiRomTarget', { v: i.romTarget }) : ''}${i.romMax ? ` · max ${i.romMax}°` : ''}${i.custom ? ' · ' + t('aiNoCam') : ''}`;
    const note = i.custom ? (customField(i, 'cautions') || []).join('; ') : itemNote(i);
    const inner = `<strong>${esc(itemName(i))}</strong><span>${dose}${extra}</span>${note ? `<small>${esc(note)}</small>` : ''}`;
    // vežbe bez kamere: način rada korak po korak
    const how = i.custom ? customField(i, 'instructions') || [] : [];
    const howHtml = how.length ? `<details class="th-how"><summary>${t('aiHow')}</summary><ol>${how.map((x) => `<li>${esc(x)}</li>`).join('')}</ol></details>` : '';
    return `<li>${i.custom ? `<div class="th-row">${inner}</div>${howHtml}` : `<a href="#${i.exId}">${inner}</a>`}</li>`;
  }).join('')}</ol>`;
}

// ─────────────────────────── moji programi ───────────────────────────
// Naziv programa: gotov program, program terapeuta, AI program (dijagnoza) ili lista vežbi iz izveštaja
function planTitle(p) {
  if (p.therapist) return t('fromTherapist', { name: (pt.data && pt.data.therapistName) || '–' });
  if (p.edited && p.title) return p.title;
  if (p.presetId && presetById(p.presetId)) return presetShort(presetById(p.presetId));
  // program iz izveštaja: kratak naziv (2–4 reči), puna dijagnoza je u detalju programa
  const short = planShortTitle(p);
  if (short) return short;
  return p.title || t('myProgram');
}
const isAiPlan = (p) => !p.therapist && !p.presetId && !p.edited && !!(p.ai || p.aiSummary || p.noteI18n);
// program terapeuta (povezan pacijent) + programi sačuvani na uređaju
function allPlans() {
  const list = [];
  if (pt.data && pt.data.plan) list.push({ ...pt.data.plan, id: 'terapeut', therapist: true });
  return list.concat(getLocalPlans());
}
const planColor = (p) => (p.therapist ? 'th' : p.color || 0);

// Lista: samo naziv programa i "Ukloni program", svaki program u svojoj pastelnoj boji
async function renderPrograms() {
  const draw = () => {
    const ul = $('prog-list');
    ul.innerHTML = '';
    const list = allPlans();
    if (!list.length) {
      const li = document.createElement('li'); li.className = 'prog-empty'; li.textContent = t('progNone'); ul.appendChild(li);
      return;
    }
    for (const p of list) {
      const li = document.createElement('li');
      li.className = 'prog-item pc-' + planColor(p);
      li.innerHTML = `<a class="prog-open" href="#moj-${esc(p.id)}"><strong></strong><span class="prog-arrow" aria-hidden="true">›</span></a>
        ${p.therapist ? '' : `<button type="button" class="prog-remove">${t('progRemove')}</button>`}`;
      li.querySelector('strong').textContent = planTitle(p);
      const rm = li.querySelector('.prog-remove');
      // uklanjanje uz potvrdu drugim dodirom
      if (rm) rm.addEventListener('click', () => {
        if (!rm.classList.contains('armed')) { rm.classList.add('armed'); rm.textContent = t('progRemoveConfirm'); return; }
        removeLocalPlan(p.id); draw();
      });
      ul.appendChild(li);
    }
  };
  draw();
  if (api.auth('patient')) {
    const view = state.view;
    await loadPatient();
    if (state.view === view) draw();
  }
}

// Jedan program: tek ovde se vide vežbe, doziranje, dani i način rada
async function renderProgram(id) {
  const root = $('program-root');
  let plan;
  if (id === 'terapeut') {
    const view = state.view;
    await loadPatient();
    if (state.view !== view) return;
    plan = pt.data && pt.data.plan ? { ...pt.data.plan, id: 'terapeut', therapist: true } : null;
  } else plan = getLocalPlan(id);
  if (!plan) { location.hash = 'programi'; return; }
  const days = t('weekdays');
  const d = pt.data;
  const canStart = !(plan.therapist && plan.status === 'paused');
  const eyebrow = plan.therapist ? t('myTherapy') : isAiPlan(plan) ? `${t('aiLocalTitle')} <span class="pill">AI</span>` : plan.presetId ? t('presetsTitle') : t('myProgram');
  const dayTxt = (plan.days || []).map((x) => days[x - 1]).join(', ');
  const pending = plan.therapist && d ? d.g.proposal.filter((x) => x.status === 'pending').length : 0;
  root.innerHTML = `<div class="therapy-card prog-detail pc-${planColor(plan)}">
      <div class="th-head">
        <div><p class="eyebrow">${eyebrow}</p><h1></h1>
        ${plan.therapist || dayTxt ? `<small class="muted">${plan.therapist ? t('planVersion', { v: plan.version }) + (dayTxt ? ' · ' : '') : ''}${dayTxt}</small>` : ''}</div>
        ${canStart ? `<button class="btn primary" data-act="guided" type="button">${t('startToday')}</button>` : ''}
      </div>
      ${planSummary(plan) && planSummary(plan).condition && planSummary(plan).condition !== planTitle(plan) ? `<p class="muted">${esc(planSummary(plan).condition)}</p>` : ''}
      ${plan.therapist && plan.approval ? `<p class="approved-line">✓ ${esc(t('apByShort', { name: plan.approval.by || (d && d.therapistName) || '–' }))}</p>` : ''}
      ${plan.therapist ? `<p>${plan.status === 'paused' ? t('planPaused') : isToday(plan) ? t('todayTrain') : t('todayRest')}</p>` : `<p class="notice">${t('aiLocalNote')}</p>`}
      ${planItemsHtml(plan)}
      ${planNote(plan) ? `<p class="muted small pre">${esc(planNote(plan))}</p>` : ''}
      ${pending ? `<p class="muted small">${t('pendingProps', { n: pending })}</p>` : ''}
      <div class="start-row"><a class="btn ghost" href="#uredi-${esc(plan.id)}">✎ ${t('peEdit')}</a>
        ${getLogs().some((l) => l.planId === plan.id) ? `<a class="btn ghost" href="#izvestaj-${encodeURIComponent(plan.id)}">${t('openReport')}</a>` : ''}
        ${plan.therapist ? '' : `<button class="link-btn" data-act="remove" type="button">${t('progRemove')}</button>`}</div>
    </div>`;
  root.querySelector('h1').textContent = planTitle(plan);
  const g = root.querySelector('[data-act="guided"]');
  if (g) g.addEventListener('click', () => startGuided(plan));
  const rm = root.querySelector('[data-act="remove"]');
  if (rm) rm.addEventListener('click', () => {
    if (!rm.classList.contains('armed')) { rm.classList.add('armed'); rm.textContent = t('progRemoveConfirm'); return; }
    removeLocalPlan(plan.id); location.hash = 'programi';
  });
}

// ─────────────────────────── izmena programa → novi program ───────────────────────────
// Od postojećeg programa pravi se kopija u kojoj se vežbe menjaju, zamenjuju, dodaju, uklanjaju i premeštaju.
// Original ostaje nepromenjen. Povezan pacijent izmenu šalje terapeutu na odobrenje.
function openEditor(id) {
  // 'novi': prazan program od početka, bez ikakvih predloga
  if (id === 'novi') {
    if (!state.edit || state.edit.srcId !== 'novi') state.edit = { srcId: 'novi', fresh: true, base: { items: [], title: t('myProgram') }, title: '', items: [], days: [1, 3, 5] };
    show('pedit');
    setTab('scan');
    renderEditor();
    return;
  }
  const src = id === 'terapeut' ? (pt.data && pt.data.plan ? { ...pt.data.plan, id: 'terapeut', therapist: true } : null) : getLocalPlan(id);
  if (!src) { location.hash = 'programi'; return; }
  // isti program: zadrži nacrt (npr. posle promene jezika)
  if (!state.edit || state.edit.srcId !== id) {
    state.edit = { srcId: id, base: src, title: t('peCopyName', { name: planTitle(src) }),
      items: JSON.parse(JSON.stringify(src.items.filter(validItem))), days: [...(src.days || [])] };
  }
  show('pedit');
  renderEditor();
}

// izbor vežbe iz biblioteke, grupisano po delu tela
function exOptions(selected = '') {
  return REGIONS.map((r) => {
    const list = EXERCISES.filter((e) => e.region === r.id);
    return list.length ? `<optgroup label="${esc(regionText(r))}">${list.map((e) => `<option value="${e.id}" ${e.id === selected ? 'selected' : ''}>${esc(exText(e, 'name'))}</option>`).join('')}</optgroup>` : '';
  }).join('');
}

function renderEditor() {
  const E = state.edit;
  if (!E) return;
  const days = t('weekdays');
  const row = (it, k) => `<li class="pe-item" data-k="${k}">
      <div class="pe-top"><span class="pe-num">${k + 1}</span><strong></strong>${it.custom ? `<span class="tag">${t('aiNoCam')}</span>` : ''}</div>
      <div class="pe-fields">
        <label>${t('clSets')}<input type="number" inputmode="numeric" min="1" max="10" data-f="sets" value="${it.sets || 1}"></label>
        <label>${t('clReps')}<input type="number" inputmode="numeric" min="1" max="60" data-f="reps" value="${it.reps || (byId(it.exId) ? byId(it.exId).defaultReps : 10)}"></label>
        ${it.custom ? `<label>${t('bCustomHold')}<input type="number" inputmode="numeric" min="0" max="120" data-f="hold" value="${it.custom.holdSec || 0}"></label>` : ''}
      </div>
      <div class="pe-acts">
        <select data-f="replace" aria-label="${t('peReplace')}"><option value="">${t('peReplace')}…</option>${exOptions()}</select>
        <button type="button" class="pe-mv" data-a="up" aria-label="${t('peUp')}" ${k === 0 ? 'disabled' : ''}>↑</button>
        <button type="button" class="pe-mv" data-a="down" aria-label="${t('peDown')}" ${k === E.items.length - 1 ? 'disabled' : ''}>↓</button>
        <button type="button" class="pe-del" data-a="del">${t('peRemove')}</button>
      </div>
    </li>`;
  const root = $('pedit-root');
  root.innerHTML = `
    <p class="eyebrow">${E.fresh ? t('tabNew') : t('peEyebrow')}</p>
    <h1>${E.fresh ? t('ownTitle') : t('peTitle')}</h1>
    <label class="fl" for="pe-name">${t('peName')}</label>
    <input id="pe-name" type="text" maxlength="80">
    <h2 class="label">${t('bExercises')} · ${E.items.length}</h2>
    ${E.items.length ? '' : `<p class="prog-empty">${t('peEmpty')}</p>`}
    <ol class="pe-list">${E.items.map(row).join('')}</ol>
    <div class="pe-add">
      <label class="fl" for="pe-new">${t('peAdd')}</label>
      <div class="pe-add-row"><select id="pe-new">${exOptions()}</select><button class="btn ghost" type="button" id="pe-add-btn">+ ${t('peAddBtn')}</button></div>
      <label class="fl" for="pe-custom">${t('peAddCustom')}</label>
      <div class="pe-add-row"><input id="pe-custom" type="text" maxlength="60" placeholder="${t('peCustomPh')}"><button class="btn ghost" type="button" id="pe-add-custom">+ ${t('peAddBtn')}</button></div>
    </div>
    <fieldset class="pe-dayset"><legend class="fl">${t('clDays')}</legend>
      <div class="pe-days">${days.map((d, i) => `<label><input type="checkbox" value="${i + 1}" ${E.days.includes(i + 1) ? 'checked' : ''}><span>${d}</span></label>`).join('')}</div>
    </fieldset>
    <p class="saved" id="pe-msg" role="status"></p>
    <div class="gs-actions">
      <button class="btn primary big" type="button" id="pe-save">${api.auth('patient') ? t('peSend') : t('peSave')}</button>
      <a class="btn ghost" href="${E.fresh ? '#skeniraj' : '#moj-' + esc(E.srcId)}">${t('peCancel')}</a>
    </div>`;
  root.querySelector('#pe-name').value = E.title;
  root.querySelectorAll('.pe-item').forEach((li) => { li.querySelector('strong').textContent = itemName(E.items[Number(li.dataset.k)]); });
}

// jedan slušalac za ceo uređivač (lista se ponovo iscrtava posle svake promene)
$('pedit-root').addEventListener('input', (e) => {
  const E = state.edit; if (!E) return;
  if (e.target.id === 'pe-name') { E.title = e.target.value; return; }
  const li = e.target.closest('.pe-item'); if (!li) return;
  const it = E.items[Number(li.dataset.k)];
  const n = Math.max(0, Math.round(Number(e.target.value) || 0));
  if (e.target.dataset.f === 'sets') it.sets = Math.max(1, n);
  if (e.target.dataset.f === 'reps') it.reps = Math.max(1, n);
  if (e.target.dataset.f === 'hold' && it.custom) it.custom = { ...it.custom, holdSec: n };
});
$('pedit-root').addEventListener('change', (e) => {
  const E = state.edit; if (!E) return;
  if (e.target.closest('.pe-days')) {
    E.days = [...$('pedit-root').querySelectorAll('.pe-days input:checked')].map((x) => Number(x.value));
    return;
  }
  if (e.target.dataset.f === 'replace' && e.target.value) {
    const k = Number(e.target.closest('.pe-item').dataset.k);
    const old = E.items[k], ex = byId(e.target.value);
    // zamena: nova vežba iz biblioteke (kamera prati), isti broj serija; ograničenja stare vežbe ne važe
    E.items[k] = { exId: ex.id, sets: old.sets || 1, reps: old.custom ? ex.defaultReps : old.reps || ex.defaultReps };
    renderEditor();
  }
});
$('pedit-root').addEventListener('click', async (e) => {
  const E = state.edit; if (!E) return;
  const a = e.target.dataset.a;
  if (a) {
    const k = Number(e.target.closest('.pe-item').dataset.k);
    if (a === 'del') E.items.splice(k, 1);
    if (a === 'up' && k > 0) [E.items[k - 1], E.items[k]] = [E.items[k], E.items[k - 1]];
    if (a === 'down' && k < E.items.length - 1) [E.items[k + 1], E.items[k]] = [E.items[k], E.items[k + 1]];
    renderEditor();
    return;
  }
  if (e.target.id === 'pe-add-custom') {
    // vežba bez kamere: samo naziv, serije i ponavljanja (pacijent broji dugmetom)
    const name = $('pe-custom').value.trim();
    if (!name) { $('pe-custom').focus(); return; }
    E.items.push({ exId: 'custom-' + Date.now(), sets: 2, reps: 10, custom: { name, instructions: [], cautions: [], holdSec: 0 } });
    renderEditor();
    return;
  }
  if (e.target.id === 'pe-add-btn') {
    const ex = byId($('pe-new').value);
    if (ex) { E.items.push({ exId: ex.id, sets: 2, reps: ex.defaultReps }); renderEditor(); }
    return;
  }
  if (e.target.id === 'pe-save') {
    const msg = $('pe-msg');
    if (!E.items.length) { msg.textContent = t('bNoItems'); return; }
    const src = E.base;
    const title = (E.title || '').trim() || planTitle(src);
    const days = E.days.slice().sort((x, y) => x - y);
    if (api.auth('patient')) {
      // povezan pacijent: izmena ide terapeutu kao predlog
      e.target.disabled = true;
      const ok = await syncPut('proposal', { kind: 'edit', title, fromTitle: planTitle(src), items: E.items, days, status: 'pending', date: Date.now() });
      msg.textContent = ok ? t('aiSent') : t('syncFail');
      if (!ok) e.target.disabled = false; else state.edit = null;
      return;
    }
    const plan = addLocalPlan({ title, edited: true, fromId: E.srcId, items: E.items, days, status: 'active', version: 1,
      note: src.note || null, noteI18n: src.noteI18n || null });
    state.edit = null;
    location.hash = 'moj-' + plan.id;
  }
});

// Ključ u zaglavlju: forma za kod, a kada je pacijent povezan, stanje veze sa terapeutom
async function renderJoin() {
  const linked = !!api.auth('patient');
  $('join-form').hidden = linked;
  const box = $('join-linked');
  box.hidden = !linked;
  if (!linked) return;
  const view = state.view;
  await loadPatient();
  if (state.view !== view) return;
  const d = pt.data;
  if (!d) { box.innerHTML = `<p class="notice">${t('gLocal')}</p>`; return; }
  const plan = d.plan;
  const pending = d.g.proposal.filter((x) => x.status === 'pending').length;
  box.innerHTML = `<div class="therapy-card">
      <p class="eyebrow">${t('myTherapy')}</p>
      <h1></h1>
      <p>${!plan ? t('noPlanYet') : plan.status === 'paused' ? t('planPaused') : isToday(plan) ? t('todayTrain') : t('todayRest')}</p>
      ${pending ? `<p class="muted small">${t('pendingProps', { n: pending })}</p>` : ''}
      <div class="start-row">
        ${plan ? `<a class="btn primary" href="#moj-terapeut">${t('progOpen')}</a>` : ''}
        <button class="link-btn" data-act="disconnect" type="button">${t('disconnect')}</button>
      </div>
    </div>`;
  box.querySelector('h1').textContent = t('fromTherapist', { name: d.therapistName || '–' });
  box.querySelector('[data-act="disconnect"]').addEventListener('click', () => { api.logout('patient'); pt.data = null; codeDot(); rerender(); });
}
// zelena tačka na ključu kada je pacijent povezan sa terapeutom
function codeDot() { $('code-dot').hidden = !api.auth('patient'); }
codeDot();

$('join-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = $('join-msg');
  try {
    const j = await api.join($('join-code').value);
    if (j.me) setProfile({ sex: j.me.sex || 'm', age: j.me.age || 'adult' });
    profileLabel();
    codeDot();
    location.hash = 'programi';
  } catch (err) {
    msg.hidden = false; msg.textContent = err.code === 'offline' ? t('joinOffline') : t('joinBad');
  }
});

// ─────────────────────────── nova vežba iz videa ───────────────────────────
const vx = { file: null, url: null, result: null, edit: null, abort: null, busy: false, player: null };

function openImport() {
  show('vimport');
  if (vx.busy) return;
  if (vx.result) renderImportResult(); else renderImportStart();
}

function renderImportStart(msg = '') {
  if (vx.player) { vx.player.destroy(); vx.player = null; }
  $('vx-root').innerHTML = `
    <p class="eyebrow">${t('menuLib')}</p>
    <h1>${t('vxTitle')}</h1>
    ${msg ? `<p class="notice">${esc(msg)}</p>` : ''}
    <ul class="vx-tips">${t('vxTips').map((x) => `<li>${esc(x)}</li>`).join('')}</ul>
    <div class="start-row">
      <label class="btn primary file-btn"><input id="vx-cam" type="file" accept="video/*" capture="environment"><span>${t('vxRecord')}</span></label>
      <label class="btn ghost file-btn"><input id="vx-file" type="file" accept="video/*"><span>${t('vxChoose')}</span></label>
    </div>`;
  for (const id of ['vx-cam', 'vx-file']) $(id).addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; if (f) runImport(f); });
}

async function runImport(file) {
  if (vx.url) URL.revokeObjectURL(vx.url);
  vx.file = file; vx.url = URL.createObjectURL(file); vx.result = null; vx.busy = true;
  const ctrl = new AbortController(); vx.abort = ctrl;
  $('vx-root').innerHTML = `
    <p class="eyebrow">${t('vxTitle')}</p>
    <h1>${t('vxAnalyzing')}</h1>
    <div class="vx-stage"><video id="vx-video" muted playsinline preload="auto"></video><canvas id="vx-canvas"></canvas></div>
    <div class="vx-bar"><span id="vx-bar"></span></div>
    <p class="muted" id="vx-prog" role="status">${t('vxLoadingModel')}</p>
    <button class="btn ghost" type="button" id="vx-cancel">${t('peCancel')}</button>`;
  $('vx-cancel').addEventListener('click', () => ctrl.abort());
  const video = $('vx-video'), cv = $('vx-canvas');
  video.src = vx.url;
  try {
    const data = await extractPoses(video, { signal: ctrl.signal, onFrame: (i, n, N) => {
      if (state.view !== 'vimport') return;
      if (cv.width !== (video.videoWidth || 640)) { cv.width = video.videoWidth || 640; cv.height = video.videoHeight || 360; }
      drawPose(cv, N);
      const p = Math.round((i / n) * 100);
      $('vx-bar').style.width = p + '%';
      $('vx-prog').textContent = t('vxProgress', { p });
    } });
    const res = analyze(data);
    vx.busy = false;
    if (res.error) { renderImportStart(t('vxErr_' + res.error)); return; }
    const lg = getLang() === 'en' ? 'en' : 'sr';
    vx.result = res;
    vx.edit = { name: res.spec.i18n[lg].name, region: res.spec.region, reps: 10, target: res.spec.target, hold: res.spec.hold,
      steps: res.spec.i18n[lg].steps.join('\n'), stepsEdited: false, nameEdited: false, off: [], keepVideo: file.size <= 80 * 1024 * 1024 };
    if (state.view === 'vimport') renderImportResult();
  } catch (e) {
    vx.busy = false;
    if (state.view !== 'vimport') return;
    renderImportStart(e && e.code === 'abort' ? '' : t(e && ['long', 'short'].includes(e.code) ? 'vxErr_' + e.code : 'vxErr_video'));
  }
}

function renderImportResult() {
  const { spec, info } = vx.result;
  const E = vx.edit;
  const lg = getLang() === 'en' ? 'en' : 'sr';
  if (vx.player) { vx.player.destroy(); vx.player = null; }
  $('vx-root').innerHTML = `
    <p class="eyebrow">${t('vxTitle')}</p>
    <h1>${t('vxDoneTitle')}</h1>
    <div class="vx-result">
      <div class="vx-fig"><canvas id="vx-avatar" aria-hidden="true"></canvas></div>
      <ul class="vx-facts">
        <li><span>${t('vxMove')}</span><strong>${esc(spec.i18n[lg].name)}</strong></li>
        <li><span>${t('vxView')}</span><strong>${spec.view === 'side' ? t('camSide') : t('camFront')}</strong></li>
        <li><span>${t('vxRange')}</span><strong>${spec.rest}° → ${spec.target}°</strong></li>
        <li><span>${t('vxHold')}</span><strong>${spec.hold ? spec.hold + ' s' : '–'}</strong></li>
        <li><span>${t('vxRepsSeen')}</span><strong>${info.reps || '–'}</strong></li>
      </ul>
    </div>
    ${spec.checks.length ? `<h2 class="label">${t('vxRules')}</h2>
    <ul class="vx-rules">${spec.checks.map((c, k) => `<li><label><input type="checkbox" data-chk="${c.id}" ${E.off.includes(c.id) ? '' : 'checked'}><span>${esc(spec.i18n[lg].mistakes[k])}</span></label></li>`).join('')}</ul>` : ''}
    <div class="field"><label class="fl" for="vx-name">${t('bCustomName')}</label><input id="vx-name" type="text" maxlength="80"></div>
    <div class="row2">
      <div><label class="fl" for="vx-region">${t('bodyArea')}</label><select id="vx-region">${REGIONS.map((r) => `<option value="${r.id}" ${r.id === E.region ? 'selected' : ''}>${esc(regionText(r))}</option>`).join('')}</select></div>
      <div><label class="fl" for="vx-reps">${t('clReps')}</label><input id="vx-reps" type="number" inputmode="numeric" min="1" max="50" value="${E.reps}"></div>
    </div>
    <div class="row2">
      <div><label class="fl" for="vx-target">${t('bRomTarget')}</label><input id="vx-target" type="number" inputmode="numeric" min="${spec.start + 2}" max="185" value="${E.target}"></div>
      <div><label class="fl" for="vx-hold">${t('bCustomHold')}</label><input id="vx-hold" type="number" inputmode="numeric" min="0" max="60" value="${E.hold}"></div>
    </div>
    <div class="field"><label class="fl" for="vx-steps">${t('bCustomSteps')}</label><textarea id="vx-steps" rows="4"></textarea></div>
    <label class="vx-keep"><input type="checkbox" id="vx-keepvid" ${E.keepVideo ? 'checked' : ''}><span>${t('vxKeepVideo')}</span></label>
    <p class="saved" id="vx-msg" role="status"></p>
    <div class="gs-actions">
      <button class="btn primary big" type="button" id="vx-save">${t('vxSave')}</button>
      <button class="btn ghost" type="button" id="vx-again">${t('vxAgain')}</button>
    </div>`;
  $('vx-name').value = E.name;
  $('vx-steps').value = E.steps;
  vx.player = createPlayer($('vx-avatar'), buildExercise({ ...spec, id: 'vx-preview' }));
  const root = $('vx-root');
  root.querySelectorAll('[data-chk]').forEach((c) => c.addEventListener('change', () => {
    E.off = [...root.querySelectorAll('[data-chk]:not(:checked)')].map((x) => x.dataset.chk);
  }));
  $('vx-name').addEventListener('input', (e) => { E.name = e.target.value; E.nameEdited = true; });
  $('vx-steps').addEventListener('input', (e) => { E.steps = e.target.value; E.stepsEdited = true; });
  $('vx-region').addEventListener('change', (e) => { E.region = e.target.value; });
  $('vx-reps').addEventListener('input', (e) => { E.reps = Math.max(1, Math.round(Number(e.target.value) || 10)); });
  $('vx-target').addEventListener('input', (e) => { E.target = Math.round(Number(e.target.value) || spec.target); });
  $('vx-hold').addEventListener('input', (e) => { E.hold = Math.max(0, Math.round(Number(e.target.value) || 0)); });
  $('vx-keepvid').addEventListener('change', (e) => { E.keepVideo = e.target.checked; });
  $('vx-again').addEventListener('click', () => { vx.result = null; renderImportStart(); });
  $('vx-save').addEventListener('click', saveImported);
}

async function saveImported() {
  const { spec } = vx.result;
  const E = vx.edit;
  const lg = getLang() === 'en' ? 'en' : 'sr';
  $('vx-save').disabled = true;
  const id = 'my-' + Date.now();
  const target = clamp(E.target, spec.start + 2, 185);
  const hold = clamp(E.hold, 0, 60);
  const off = E.off;
  const i18n = {};
  for (const l of ['sr', 'en']) {
    const src = spec.i18n[l];
    const fix = (s) => s.split(spec.target + '°').join(target + '°');
    let steps = src.steps.map(fix);
    if (hold !== spec.hold) steps = steps.filter((s) => !/\d+ s\.$/.test(s)); // staro zadržavanje
    i18n[l] = {
      ...src,
      name: E.nameEdited && E.name.trim() ? E.name.trim() : src.name,
      steps: l === lg && E.stepsEdited ? E.steps.split('\n').map((x) => x.trim()).filter(Boolean) : steps,
      tooLow: fix(src.tooLow), summary: fix(src.summary),
      mistakes: spec.checks.map((c, k) => [c, src.mistakes[k]]).filter(([c]) => !off.includes(c.id)).map((x) => x[1]),
    };
  }
  const final = { ...spec, id, i18n, target, hold, max: Math.max(spec.max, target + 10), region: E.region, defaultReps: E.reps,
    checks: spec.checks.filter((c) => !off.includes(c.id)), createdAt: Date.now(), hasVideo: false };
  if (E.keepVideo && vx.file && vx.file.size <= 80 * 1024 * 1024) final.hasVideo = await putVideo(id, vx.file);
  saveSpec(final);
  const ex = buildExercise(final);
  if (final.hasVideo) { ex.videoUrl = vx.url; vx.url = null; }
  EXERCISES.push(ex);
  if (vx.player) { vx.player.destroy(); vx.player = null; }
  vx.result = null; vx.file = null;
  location.hash = id;
}

// brisanje sopstvene vežbe (u detalju vežbe, uz potvrdu drugim dodirom)
$('d-delete').addEventListener('click', () => {
  const b = $('d-delete'), ex = state.ex;
  if (!ex || !ex.mine) return;
  if (!b.classList.contains('armed')) { b.classList.add('armed'); b.textContent = t('vxDeleteConfirm'); return; }
  deleteSpec(ex.id);
  const i = EXERCISES.findIndex((e) => e.id === ex.id);
  if (i >= 0) EXERCISES.splice(i, 1);
  location.hash = 'vezbe';
});

// ─────────────────────────── detalj vežbe ───────────────────────────
function placementIcon(view) {
  const cam = '<rect x="2" y="15" width="12" height="10" rx="2" fill="currentColor"/><path d="M14 18l5-3v10l-5-3z" fill="currentColor"/>';
  const dash = '<path d="M22 20h14" stroke="currentColor" stroke-width="1.5" stroke-dasharray="2 3"/>';
  const front = '<circle cx="50" cy="8" r="4" fill="currentColor"/><path d="M50 13v13M50 26l-5 12M50 26l5 12M42 17l8-2 8 2" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" fill="none"/>';
  const side = '<circle cx="50" cy="8" r="4" fill="currentColor"/><path d="M50 13v13M50 26l-2 12M50 26l3 12M50 16l6 6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" fill="none"/><path d="M53 7l3 1" stroke="currentColor" stroke-width="2"/>';
  return cam + dash + (view === 'side' ? side : front);
}

function fillDetailTexts(ex) {
  $('d-region').textContent = regionName(ex.region);
  $('d-name').textContent = exText(ex, 'name');
  $('d-summary').textContent = exText(ex, 'summary');
  $('d-steps').innerHTML = '';
  for (const s of exText(ex, 'steps')) { const li = document.createElement('li'); li.textContent = s; $('d-steps').appendChild(li); }
  $('d-mistakes').innerHTML = '';
  for (const s of exText(ex, 'mistakes')) { const li = document.createElement('li'); li.textContent = s; $('d-mistakes').appendChild(li); }
  $('d-placement').textContent = exText(ex, 'placement');
  $('player-tag').textContent = $('demo-video').hidden ? t('animated') : t('videoTag');
  $('fig-legend').hidden = !$('demo-video').hidden;
  const vid = $('demo-video');
  const playing = !vid.hidden ? !vid.paused : !state.detailPlayer || state.detailPlayer.playing;
  $('btn-play').textContent = playing ? t('pause') : t('play');
}

function openDetail(ex) {
  state.ex = ex;
  state.reps = defaultReps(ex);
  $('d-place-ico').innerHTML = placementIcon(ex.view);
  $('d-delete').hidden = !ex.mine; $('d-delete').classList.remove('armed'); $('d-delete').textContent = t('vxDelete');
  $('reps-val').textContent = state.reps;

  if (state.detailPlayer) state.detailPlayer.destroy();
  state.detailPlayer = null;
  const vid = $('demo-video'), cv = $('demo-canvas');
  const src = videoFor(ex);
  if (src) {
    vid.src = src; vid.hidden = false; cv.hidden = true;
    vid.play().catch(() => {});
    vid.onerror = () => {
      vid.hidden = true; cv.hidden = false; $('fig-legend').hidden = false;
      $('player-tag').textContent = t('animated');
      state.detailPlayer = createPlayer(cv, ex);
    };
  } else {
    vid.hidden = true; vid.removeAttribute('src'); cv.hidden = false;
    state.detailPlayer = createPlayer(cv, ex);
  }
  document.querySelectorAll('.player-ctrl .seg button').forEach((b) => b.classList.toggle('on', b.dataset.speed === '1'));
  document.querySelectorAll('#tol-seg button').forEach((b) => b.classList.toggle('on', Number(b.dataset.tol) === state.tol));
  show('detail');
  fillDetailTexts(ex);
  $('btn-play').textContent = t('pause');
}

$('btn-play').addEventListener('click', () => {
  const vid = $('demo-video');
  const playing = !vid.hidden ? !vid.paused : state.detailPlayer && state.detailPlayer.playing;
  if (!vid.hidden) { playing ? vid.pause() : vid.play(); }
  else if (state.detailPlayer) { playing ? state.detailPlayer.pause() : state.detailPlayer.play(); }
  $('btn-play').textContent = playing ? t('play') : t('pause');
});
document.querySelectorAll('.player-ctrl .seg button').forEach((b) => b.addEventListener('click', () => {
  const sp = Number(b.dataset.speed);
  document.querySelectorAll('.player-ctrl .seg button').forEach((x) => x.classList.toggle('on', x === b));
  if (state.detailPlayer) state.detailPlayer.speed = sp;
  $('demo-video').playbackRate = sp;
}));
document.querySelectorAll('#tol-seg button').forEach((b) => b.addEventListener('click', () => {
  state.tol = Number(b.dataset.tol);
  document.querySelectorAll('#tol-seg button').forEach((x) => x.classList.toggle('on', x === b));
  try { localStorage.setItem('fizio-tol', String(state.tol)); } catch { /* */ }
}));
$('reps-minus').addEventListener('click', () => { state.reps = Math.max(1, state.reps - 1); $('reps-val').textContent = state.reps; });
$('reps-plus').addEventListener('click', () => { state.reps = Math.min(50, state.reps + 1); $('reps-val').textContent = state.reps; });

// ─────────────────────────── kamera: zajednički deo ───────────────────────────
const BONES = [[11, 12], [11, 13], [13, 15], [12, 14], [14, 16], [11, 23], [12, 24], [23, 24], [23, 25], [25, 27], [24, 26], [26, 28], [27, 29], [29, 31], [27, 31], [28, 30], [30, 32], [28, 32]];
const LEFT_IDX = new Set([7, 11, 13, 15, 23, 25, 27, 29, 31]);
const RIGHT_IDX = new Set([8, 12, 14, 16, 24, 26, 28, 30, 32]);
const PART_GROUPS = [
  { key: 'head', idx: [0, 7, 8] },
  { key: 'shoulders', idx: [11, 12] },
  { key: 'arms', idx: [13, 14, 15, 16] },
  { key: 'hips', idx: [23, 24] },
  { key: 'knees', idx: [25, 26] },
  { key: 'feet', idx: [27, 28, 29, 30, 31, 32] },
];

const coach = new Coach($('banner'));
const session = {
  running: false, mode: 'exercise', stream: null, facing: 'user', raf: 0, phase: 'idle',
  smooth: null, lastVideoTime: -1, visibleSince: 0, lostSince: 0,
  countdownStart: 0, lastCount: 0, calib: [], refs: null, side: 'l',
  engine: null, pip: null, wakeLock: null, finishing: false, lm: null, det: null, mildFrames: {},
  space: null, frameNo: 0,
};
const lightCanvas = document.createElement('canvas');

function setStatus(key, s = '') { const el = $('s-status'); el.textContent = t(key); el.dataset.s = s; }
function center(text, big = false) {
  const el = $('center-msg');
  el.hidden = !text; el.textContent = text || ''; el.classList.toggle('big', big);
}
function updateVoiceBtn() {
  $('btn-voice').textContent = coach.voiceOn ? t('voiceOn') : t('voiceOff');
  $('btn-voice').setAttribute('aria-pressed', String(coach.voiceOn));
}

async function startCamera() {
  if (session.stream) session.stream.getTracks().forEach((tr) => tr.stop());
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: false,
    video: { facingMode: session.facing, width: { ideal: 1280 }, height: { ideal: 720 } },
  });
  session.stream = stream;
  const v = $('cam');
  v.srcObject = stream;
  await v.play();
  $('stage').classList.toggle('mirror', session.facing === 'user');
}

function setModeUi(mode) {
  session.mode = mode;
  const ex = state.ex;
  $('s-counter').hidden = mode === 'space';
  $('s-gauge').hidden = mode === 'space';
  $('s-pip').hidden = mode === 'space';
  $('space-panel').hidden = true;
  $('btn-cannot').hidden = !guided.on;
  const setTxt = guided.on ? ` · ${t('gSet', { s: guided.set, n: guided.items[guided.i].sets })}` : '';
  $('s-name').textContent = mode === 'space' ? `${t('spTitle')} · ${exText(ex, 'name')}` : exText(ex, 'name') + setTxt;
}

function resetExercise(keepRefs = false) {
  const ex = state.ex;
  session.engine = new RepEngine(ex, state.tol);
  session.mildFrames = {};
  session.finishing = false;
  session.trackOk = 0;
  session.fs = { total: 0, err: 0, mild: 0 }; // kadrovi vežbanja: ukupno, sa greškom, sa blagim odstupanjem
  session.trackLost = 0;
  session.visibleSince = 0;
  session.lostSince = 0;
  if (keepRefs && session.refs) {
    session.phase = 'active';
  } else {
    session.refs = null;
    session.calib = [];
    session.phase = 'position';
  }
  $('s-reps').textContent = '0';
  $('s-target').textContent = state.reps;
  $('g-fill').style.height = '0%';
  $('g-target').style.bottom = `${(session.engine.target / (ex.target * 1.35)) * 100}%`;
  if (session.pip) session.pip.destroy();
  session.pip = createPlayer($('pip-canvas'), ex);
}

function resetSpace() {
  session.space = { start: 0, samples: [], result: null };
  session.phase = 'space-wait';
  session.visibleSince = 0;
  $('space-panel').hidden = true;
}

async function startSession(mode = 'exercise') {
  const ex = state.ex;
  coach.unlockAudio();
  if (state.detailPlayer) state.detailPlayer.pause();
  $('demo-video').pause();
  show('session');
  updateVoiceBtn();
  setModeUi(mode);
  coach.render(null, t('getReady'));
  setStatus('stStarting');

  if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
    center(t('needHttps'));
    setStatus('stError', 'paused');
    return;
  }

  session.running = true;
  session.phase = 'loading';
  session.smooth = null;
  if (mode === 'exercise') resetExercise(); else resetSpace();
  session.phase = 'loading';

  try {
    center(t('camStarting'));
    await startCamera();
  } catch (e) {
    session.running = false;
    center(e && e.name === 'NotAllowedError' ? t('camDenied') : t('camMissing'));
    setStatus('stError', 'paused');
    return;
  }
  if (!session.running) return;

  try {
    center(t('modelLoading'));
    session.lm = await getLandmarker();
    if (mode === 'space') {
      center(t('spLoadingDet'));
      try { session.det = await getDetector(); } catch { session.det = null; }
    }
  } catch {
    center(t('modelFail'));
    setStatus('stError', 'paused');
    return;
  }
  if (!session.running) return;

  try { session.wakeLock = await navigator.wakeLock?.request('screen'); } catch { session.wakeLock = null; }

  center('');
  setStatus('stSetup');
  if (mode === 'space') { resetSpace(); coach.say(t('spIntro')); }
  else if (state.ex.isCustom) enterCustom();
  else { session.phase = 'position'; coach.say(ex.view === 'side' ? t('saySide') : t('sayFront')); }
  session.lastVideoTime = -1;
  session.raf = requestAnimationFrame(loop);
}

function stopSession(toSummary = true) {
  session.running = false;
  cancelAnimationFrame(session.raf);
  if (session.stream) session.stream.getTracks().forEach((tr) => tr.stop());
  session.stream = null;
  $('cam').srcObject = null;
  coach.stop();
  try { session.wakeLock && session.wakeLock.release(); } catch { /* */ }
  session.wakeLock = null;
  if (session.pip) { session.pip.destroy(); session.pip = null; }
  center('');
  $('space-panel').hidden = true;
  if (toSummary && session.mode === 'exercise' && session.engine) showSummary();
}

$('btn-start').addEventListener('click', () => startSession('exercise'));
$('btn-space').addEventListener('click', () => startSession('space'));
$('btn-stop').addEventListener('click', () => {
  if (session.mode === 'space') { stopSession(false); show('detail'); fillDetailTexts(state.ex); if (state.detailPlayer) state.detailPlayer.play(); }
  else if (guided.on) {
    // prekid vežbe: sačuvaj urađeno i pređi na pregled ove vežbe (odatle sledeća vežba ili kraj terapije)
    if (session.phase !== 'rest' && session.phase !== 'custom' && session.engine && session.engine.reps) saveSessionRecord();
    guidedNext('stopped');
  }
  else stopSession(true);
});
$('btn-cannot').addEventListener('click', openCannot);
$('btn-voice').addEventListener('click', () => {
  coach.voiceOn = !coach.voiceOn;
  if (!coach.voiceOn) coach.stop();
  updateVoiceBtn();
});
$('btn-flip').addEventListener('click', async () => {
  session.facing = session.facing === 'user' ? 'environment' : 'user';
  try { await startCamera(); session.smooth = null; } catch { session.facing = 'user'; }
});
$('sp-start').addEventListener('click', () => {
  setModeUi('exercise');
  resetExercise();
  setStatus('stSetup');
  coach.say(state.ex.view === 'side' ? t('saySide') : t('sayFront'));
});
$('sp-again').addEventListener('click', () => { resetSpace(); setStatus('stSetup'); });
$('sp-back').addEventListener('click', () => { stopSession(false); show('detail'); fillDetailTexts(state.ex); if (state.detailPlayer) state.detailPlayer.play(); });

// ─────────────────────────── obrada kadra ───────────────────────────
function loop() {
  if (!session.running) return;
  const v = $('cam');
  const now = performance.now();
  if (v.readyState >= 2 && v.currentTime !== session.lastVideoTime) {
    session.lastVideoTime = v.currentTime;
    session.frameNo++;
    let res = null;
    try { res = session.lm.detectForVideo(v, now); } catch { res = null; }
    const lms = res && res.landmarks && res.landmarks[0];
    if (session.mode === 'space') handleSpaceFrame(lms, now);
    else handleFrame(lms, now);
  }
  session.raf = requestAnimationFrame(loop);
}

function smoothLandmarks(lms) {
  if (!session.smooth) { session.smooth = lms.map((p) => ({ x: p.x, y: p.y, v: p.visibility ?? 1 })); return session.smooth; }
  const a = 0.55;
  session.smooth = lms.map((p, i) => {
    const s = session.smooth[i];
    return { x: s.x + (p.x - s.x) * a, y: s.y + (p.y - s.y) * a, v: p.visibility ?? 1 };
  });
  return session.smooth;
}

const isIn = (p) => p && p.v > 0.5 && p.x > -0.02 && p.x < 1.02 && p.y > -0.02 && p.y < 1.02;

function pickSide(N) {
  const sum = (s) => ['Sh', 'Hip', 'Kn', 'An', 'Heel', 'Toe'].reduce((acc, n) => acc + N[J(s, n)].v, 0);
  return sum('l') >= sum('r') ? 'l' : 'r';
}

function missingText(N, req) {
  const names = t('parts');
  const miss = PART_GROUPS.filter((g) => g.idx.some((i) => req.includes(i) && !isIn(N[i]))).map((g) => names[g.key]);
  return miss.length ? t('missing', { parts: miss.join(', ') }) : '';
}

function prepCanvas() {
  const v = $('cam'), cv = $('overlay');
  const W = v.videoWidth || 1280, H = v.videoHeight || 720;
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
  const ctx = cv.getContext('2d');
  ctx.clearRect(0, 0, W, H);
  return { ctx, W, H };
}

// ── provera prostora ──
const SPACE_SECONDS = 4;
function handleSpaceFrame(lms, now) {
  const ex = state.ex;
  const { ctx, W, H } = prepCanvas();
  const sp = session.space;
  const N = lms ? smoothLandmarks(lms) : null;
  if (N && ex.view === 'side' && session.phase === 'space-wait') session.side = pickSide(N);
  const req = ex.required({ refs: {}, side: session.side });

  if (session.phase === 'space-wait') {
    const allIn = N && req.every((i) => isIn(N[i]));
    if (allIn) {
      if (!session.visibleSince) session.visibleSince = now;
      if (now - session.visibleSince > 1000) { session.phase = 'space-scan'; sp.start = now; setStatus('stCalib'); }
    } else session.visibleSince = 0;
    // posle 8 s bez celog tela ipak analiziraj, da bi korisnik dobio objašnjenje
    if (!sp.waitStart) sp.waitStart = now;
    if (now - sp.waitStart > 8000 && session.phase === 'space-wait') { session.phase = 'space-scan'; sp.start = now; }
    coach.render(null, N ? (missingText(N, req) || t('spIntro')) : t('noPerson'));
  } else if (session.phase === 'space-scan') {
    const left = Math.max(0, SPACE_SECONDS - (now - sp.start) / 1000);
    coach.render(null, t('spChecking', { s: Math.ceil(left) }));
    const box = N ? bodyBox(N) : null;
    const sample = { N, box, allIn: !!N && req.every((i) => isIn(N[i])) };
    if (session.frameNo % 3 === 0 || !sp.lastLight) sp.lastLight = measureLight($('cam'), box, lightCanvas);
    sample.light = sp.lastLight;
    if (session.det && session.frameNo % 4 === 0) {
      try {
        const r = session.det.detectForVideo($('cam'), now);
        sample.dets = (r.detections || []).map((d) => ({
          label: d.categories[0].categoryName, score: d.categories[0].score,
          box: { x: d.boundingBox.originX / W, y: d.boundingBox.originY / H, w: d.boundingBox.width / W, h: d.boundingBox.height / H },
        }));
      } catch { /* preskoči kadar */ }
    }
    sp.samples.push(sample);
    if (left <= 0) {
      sp.result = analyzeSpace(sp.samples, ex, { aspect: W / H, child: profileOrDefault().age === 'child' });
      session.phase = 'space-done';
      showSpaceResult(sp.result);
    }
  }

  if (N) drawSkeleton(ctx, N, W, H, [], req);
  if (sp.result) drawSpace(ctx, W, H, sp.result);
}

function spaceItemText(it) {
  const v = it.vars || {};
  if (it.key === 'spNoRoom') {
    const map = { right: t('wRight'), left: t('wLeft'), top: t('wTop') };
    return t('spNoRoom', { where: v.where.map((w) => map[w]).join(', ') });
  }
  if (it.key === 'spObstacle') {
    const objs = t('objects');
    return t('spObstacle', { label: objs[v.label] || v.label, side: v.side === 'right' ? t('wRight') : t('wLeft') });
  }
  return t(it.key);
}

function showSpaceResult(res) {
  const vt = { ok: t('spVerdictOk'), warn: t('spVerdictWarn'), bad: t('spVerdictBad') }[res.verdict];
  const el = $('sp-verdict'); el.textContent = vt; el.dataset.v = res.verdict;
  const ul = $('sp-items'); ul.innerHTML = '';
  const icon = { ok: '✓', warn: '!', bad: '✕', info: 'i' };
  const order = { bad: 0, warn: 1, info: 2, ok: 3 };
  for (const it of [...res.items].sort((a, b) => order[a.status] - order[b.status])) {
    const li = document.createElement('li');
    li.innerHTML = `<span class="ic ${it.status}" aria-hidden="true">${icon[it.status]}</span><span></span>`;
    li.lastChild.textContent = spaceItemText(it);
    ul.appendChild(li);
  }
  $('sp-start').hidden = res.verdict === 'bad';
  renderHomeAdapt(res);
  $('space-panel').hidden = false;
  setStatus(res.verdict === 'bad' ? 'stPaused' : 'stActive', res.verdict === 'bad' ? 'paused' : 'active');
  coach.render(null, vt);
  coach.say(vt, true);
}

// HomeAdapt: pitanja o opremi, prostoru i postavljanju kamere + izvodljivost vežbe i zamene
function renderHomeAdapt(spaceRes) {
  const box = $('home-adapt');
  const ex = state.ex;
  const home = getHome() || { equipment: { chair: true, wall: true }, space: 'ok', camera: 'both' };
  const eq = t('equip');
  const radio = (name, opts, cur) => opts.map((o) => `<label><input type="radio" name="ha-${name}" value="${o}" ${cur === o ? 'checked' : ''}><span>${t(name + '_' + o)}</span></label>`).join('');
  const f = feasibility(ex, home, spaceRes);
  const alts = f.ok ? [] : alternatives(ex, EXERCISES, home);
  box.open = !f.ok || spaceRes.verdict === 'bad';
  box.innerHTML = `<summary>${t('haTitle')}</summary>
    <fieldset class="field"><legend>${t('haEquip')}</legend><div class="choice">
      ${Object.keys(eq).map((k) => `<label><input type="checkbox" name="ha-eq" value="${k}" ${home.equipment && home.equipment[k] ? 'checked' : ''}><span>${eq[k]}</span></label>`).join('')}
    </div></fieldset>
    <fieldset class="field"><legend>${t('haSpace')}</legend><div class="choice">${radio('space', ['ok', 'limited'], home.space)}</div></fieldset>
    <fieldset class="field"><legend>${t('haCamera')}</legend><div class="choice">${radio('cam', ['both', 'front', 'side', 'close'], home.camera)}</div></fieldset>
    <button class="btn small" type="button" id="ha-save">${t('haSave')}</button>
    <div class="ha-result">
      ${f.ok ? `<p class="ok-text">✓ ${t('haOk')}</p>` : `<p><strong>${t('haNot')}</strong> ${f.blockers.map((b) => t(b)).join('; ')}</p>`}
      ${f.tips.length ? `<p class="muted small">${f.tips.map((b) => t(b)).join('; ')}</p>` : ''}
      ${alts.length ? `<p class="muted small">${t('altTitle')}: ${alts.map((a) => esc(exText(a, 'name'))).join(', ')}</p>` : ''}
      ${!f.ok ? (api.auth('patient') ? `<button class="btn small" type="button" id="ha-send">${t('haSendSub')}</button><span class="ok-text" id="ha-sent"></span>` : `<p class="muted small">${t('haAskTherapist')}</p>`) : ''}
    </div>`;
  $('ha-save').addEventListener('click', () => {
    const h = {
      equipment: Object.fromEntries(Object.keys(eq).map((k) => [k, !!box.querySelector(`input[name="ha-eq"][value="${k}"]`).checked])),
      space: box.querySelector('input[name="ha-space"]:checked').value,
      camera: box.querySelector('input[name="ha-cam"]:checked').value,
    };
    setHome(h);
    syncPut('home', { ...h, date: Date.now() });
    renderHomeAdapt(spaceRes);
  });
  const send = $('ha-send');
  if (send) send.addEventListener('click', async () => {
    await syncPut('proposal', { kind: 'substitute', fromExId: ex.id, reason: f.blockers.includes('haNoChair') ? 'equipment' : 'space', blockers: f.blockers, options: alts.map((a) => a.id), status: 'pending', date: Date.now() });
    send.disabled = true;
    $('ha-sent').textContent = ' ' + t('altSent');
  });
}

function drawSpace(ctx, W, H, res) {
  if (res.env) {
    const e = res.env;
    ctx.save();
    ctx.setLineDash([H * 0.02, H * 0.012]);
    ctx.lineWidth = Math.max(3, H * 0.005);
    ctx.strokeStyle = res.items.some((i) => i.key === 'spNoRoom') ? '#f06895' : '#3cc58d';
    ctx.strokeRect(e.x0 * W, Math.max(0, e.y0) * H, (e.x1 - e.x0) * W, (e.y1 - Math.max(0, e.y0)) * H);
    ctx.restore();
  }
  for (const o of res.obstacles) {
    ctx.strokeStyle = '#f2b632'; ctx.lineWidth = Math.max(3, H * 0.005);
    ctx.strokeRect(o.box.x * W, o.box.y * H, o.box.w * W, o.box.h * H);
  }
}

// ── vežbanje ──
function calibrate(frames, ex, side) {
  const vals = {};
  const put = (k, v) => { if (Number.isFinite(v)) (vals[k] = vals[k] || []).push(v); };
  for (const P of frames) {
    const sm = mid(P[LM.lSh], P[LM.rSh]), hm = mid(P[LM.lHip], P[LM.rHip]);
    const torso = dist(sm, hm);
    put('torso', torso);
    put('shoulderW', dist(P[LM.lSh], P[LM.rSh]));
    put('hipMidX', hm.x);
    put('lean', trunkLean(P));
    put('shLine', lineAngle(P[LM.rSh], P[LM.lSh]));
    put('hipLine', lineAngle(P[LM.rHip], P[LM.lHip]));
    put('earSh', ((P[LM.lSh].y - P[LM.lEar].y) + (P[LM.rSh].y - P[LM.rEar].y)) / 2 / torso);
    put('neck', angleDiff(lineAngle(P[LM.rEar], P[LM.lEar]), lineAngle(P[LM.rSh], P[LM.lSh])));
    const em = mid(P[LM.lEar], P[LM.rEar]);
    const ax = P[LM.lEar].x - P[LM.rEar].x, ay = P[LM.lEar].y - P[LM.rEar].y, l2 = ax * ax + ay * ay || 1e-6;
    put('noseProj', ((P[LM.nose].x - em.x) * ax + (P[LM.nose].y - em.y) * ay) / l2);
    put('legL', fromVertical(P[LM.lHip], P[LM.lAn]));
    put('legR', fromVertical(P[LM.rHip], P[LM.rAn]));
    put('thighL', dist(P[LM.lHip], P[LM.lKn]));
    put('thighR', dist(P[LM.rHip], P[LM.rKn]));
    const heel = P[J(side, 'Heel')], toe = P[J(side, 'Toe')];
    put('thighS', dist(P[J(side, 'Hip')], P[J(side, 'Kn')]));
    put('foot', dist(heel, toe));
    put('footDy', toe.y - heel.y);
  }
  const refs = {};
  for (const [k, arr] of Object.entries(vals)) {
    arr.sort((a, b) => a - b);
    refs[k] = arr[Math.floor(arr.length / 2)];          // medijana, otporna na trzaje
  }
  if (refs.foot) refs.footAngle = Math.asin(clamp((refs.footDy || 0) / refs.foot, -1, 1)) * DEG;
  if (!refs.torso) refs.torso = 0.3;
  return refs;
}

function handleFrame(lms, now) {
  const ex = state.ex;
  const { ctx, W, H } = prepCanvas();
  // pauza, prijava "ne mogu" i vežbe bez kamere: samo prikaz kostura
  if (session.phase === 'custom' || session.phase === 'rest' || session.phase === 'cannot') {
    if (lms) drawSkeleton(ctx, smoothLandmarks(lms), W, H, [], []);
    return;
  }

  if (!lms) {
    session.visibleSince = 0;
    if (session.phase === 'active') { if (!session.lostSince) session.lostSince = now; }
    if (session.phase === 'countdown') { session.phase = 'position'; center(''); }
    if (session.phase !== 'active' || now - session.lostSince > 800) {
      if (session.phase === 'active') setStatus('stPaused', 'paused'); else setStatus('stSetup');
      coach.render(null, t('noPerson'));
    }
    return;
  }

  const N = smoothLandmarks(lms);
  const aspect = W / H;
  const P = N.map((p) => ({ x: p.x * aspect, y: p.y, v: p.v }));
  if (session.phase === 'position' && ex.view === 'side') session.side = pickSide(N);
  const ctxEx = { refs: session.refs || {}, side: session.side };
  const req = ex.required(ctxEx);
  const allIn = req.every((i) => isIn(N[i]));

  let activeErrors = [];
  let mildErrors = [];

  if (session.phase === 'position') {
    if (allIn) {
      if (!session.visibleSince) session.visibleSince = now;
      coach.render(null, t('inView'));
      if (now - session.visibleSince > 1200) {
        session.phase = 'countdown'; session.countdownStart = now; session.lastCount = 0; session.calib = [];
        setStatus('stCalib');
      }
    } else {
      session.visibleSince = 0;
      coach.render(null, missingText(N, req) || t('standInView'));
    }
  } else if (session.phase === 'countdown') {
    if (!allIn) { session.phase = 'position'; session.visibleSince = 0; center(''); setStatus('stSetup'); }
    else {
      const el = (now - session.countdownStart) / 1000;
      const left = 3 - Math.floor(el);
      if (left !== session.lastCount && left > 0) { session.lastCount = left; center(String(left), true); coach.say(numberWord(left), true); coach.tone('tick'); }
      if (el > 0.8) session.calib.push(P);
      coach.render(null, t('holdStill'));
      if (el >= 3) {
        session.refs = calibrate(session.calib, ex, session.side);
        session.phase = 'active';
        center('');
        setStatus('stActive', 'active');
        coach.say(t('begin') + ' ' + exText(ex, 'cue'), true);
        coach.flash(t('beginShort'), 'good', 1200);
      }
    }
  } else if (session.phase === 'active' && !session.finishing) {
    if (allIn) session.trackOk++; else session.trackLost++;
    if (!allIn) {
      if (!session.lostSince) session.lostSince = now;
      if (now - session.lostSince > 800) {
        setStatus('stPaused', 'paused');
        coach.render(null, missingText(N, req) || t('backInFrame'));
        if (now - session.lostSince > 2500) coach.warn('frame', t('notFullyVisible'));
      }
    } else {
      session.lostSince = 0;
      setStatus('stActive', 'active');
      const m = ex.metric(P, ctxEx);
      // greške: provera sa tolerancijom; blaga odstupanja: prelaze idealnu granicu, ali su u toleranciji
      const errs = ex.checks(P, { ...ctxEx, tol: state.tol }, m);
      const strict = ex.checks(P, { ...ctxEx, tol: 0 }, m);
      // ograničenja koja je zadao terapeut
      const it = state.item;
      if (it && it.romMax && m.value > it.romMax) errs.push({ id: 'romMax', msg: t('romMaxErr'), joints: [] });
      if (it && it.side && it.side !== 'both' && m.side && m.value > ex.start && m.side !== (it.side === 'left' ? 'l' : 'r')) {
        errs.push({ id: 'side', msg: t('wrongSide', { side: t('side_' + it.side) }), joints: [] });
      }
      const errIds = new Set(errs.map((e) => e.id));
      const mildNow = strict.filter((e) => !errIds.has(e.id));
      const mf = session.mildFrames;
      for (const k of Object.keys(mf)) if (!mildNow.some((e) => e.id === k)) mf[k] = 0;
      for (const e of mildNow) mf[e.id] = (mf[e.id] || 0) + 1;
      mildErrors = mildNow.filter((e) => mf[e.id] >= 8);

      const { events, active } = session.engine.update(m.value, errs, now);
      activeErrors = active;
      for (const e of events) handleEvent(e, ex);
      updateGauge(m.value, ex);
      // merenje odstupanja od pravilnog izvođenja
      if (session.fs) { session.fs.total++; if (active.length) session.fs.err++; else if (mildErrors.length) session.fs.mild++; }
      coach.render(active[0] && errText(ex, active[0]), idleText(ex), mildErrors[0] && errText(ex, mildErrors[0]));
    }
  }

  drawSkeleton(ctx, N, W, H, activeErrors, req, mildErrors);
}

function idleText(ex) {
  const en = session.engine;
  if (en.phase === 'moving' && ex.hold && en.holdStart != null && !en.reached) {
    const left = Math.max(0, ex.hold * (1 - en.holdProgress));
    const s = getLang() === 'en' ? left.toFixed(1) : left.toFixed(1).replace('.', ',');
    return t('holdFor', { s });
  }
  if (en.phase === 'moving' && en.reached) return t('returnSlowly');
  return exText(ex, 'cue');
}

function updateGauge(value, ex) {
  const max = ex.target * 1.35;
  const pct = clamp(value / max, 0, 1) * 100;
  const f = $('g-fill');
  f.style.height = pct.toFixed(1) + '%';
  f.classList.toggle('hit', value >= session.engine.target);
}

function praiseList() {
  const p = profileOrDefault();
  if (p.age === 'child') return t(p.sex === 'f' ? 'praiseChildF' : 'praiseChildM');
  return t('praise');
}

function handleEvent(e, ex) {
  const en = session.engine;
  if (e.type === 'newError') {
    coach.warn(e.err.id, errText(ex, e.err));
  } else if (e.type === 'held') {
    coach.tone('good');
    coach.flash(t('heldOk'), 'good', 1500, true);
  } else if (e.type === 'partial') {
    const msg = e.held ? t('holdPos', { n: ex.hold, unit: ex.hold === 1 ? t('sec1') : t('secN') }) : exText(ex, 'tooLow');
    coach.flash(msg, 'warn', 2200);
    coach.warn('partial', msg);
  } else if (e.type === 'rep') {
    $('s-reps').textContent = en.reps;
    if (e.good) {
      coach.tone('good');
      const list = praiseList();
      const praise = en.good % 3 === 0 ? list[(en.good / 3) % list.length] : '';
      if (e.nearTarget) coach.flash(t('repNear', { n: en.reps }), 'good', 1800);
      else coach.flash(praise || t('repN', { n: en.reps }), 'good', 1300);
      coach.say(numberWord(en.reps) + (praise ? '. ' + praise : ''));
    } else {
      coach.flash(t('repWithError', { n: en.reps }), 'info', 1500);
      coach.say(numberWord(en.reps));
    }
    if (en.reps >= state.reps && !session.finishing) {
      session.finishing = true;
      setTimeout(() => {
        coach.tone('done');
        if (guided.on) { saveSessionRecord(); guidedNext('done'); return; }
        coach.say(t('finished'), true);
        center(t('finishedShort'));
        setTimeout(() => { if (session.running) stopSession(true); }, 1600);
      }, 500);
    }
  }
}

// Kostur preko slike kamere: leva strana plava, desna ljubičasta, greška roze, blago odstupanje žuto
function drawSkeleton(ctx, N, W, H, errors, req, mild = []) {
  const bad = new Set(errors.flatMap((e) => e.joints));
  const soft = new Set(mild.flatMap((e) => e.joints));
  const lw = Math.max(3, H * 0.007);
  const cs = { l: '#7FA7DA', r: '#2ECFC3', mid: '#E3EAF0', bad: '#FF6B81', mild: '#F5B544' };
  const sideColor = (a, b) => (LEFT_IDX.has(a) && LEFT_IDX.has(b) ? cs.l : RIGHT_IDX.has(a) && RIGHT_IDX.has(b) ? cs.r : cs.mid);
  ctx.lineCap = 'round';
  for (const [a, b] of BONES) {
    const p = N[a], q = N[b];
    if (p.v < 0.4 || q.v < 0.4) continue;
    const isBad = bad.has(a) || bad.has(b);
    ctx.strokeStyle = isBad ? cs.bad : soft.has(a) || soft.has(b) ? cs.mild : sideColor(a, b);
    ctx.globalAlpha = req.includes(a) || req.includes(b) || isBad ? 1 : 0.45;
    ctx.lineWidth = isBad ? lw * 1.6 : lw;
    ctx.beginPath(); ctx.moveTo(p.x * W, p.y * H); ctx.lineTo(q.x * W, q.y * H); ctx.stroke();
  }
  ctx.globalAlpha = 1;
  for (let i = 0; i < N.length; i++) {
    if (i > 0 && i < 7) continue;
    if (i === 9 || i === 10 || (i > 16 && i < 23)) continue;
    const p = N[i];
    if (p.v < 0.4) continue;
    const isBad = bad.has(i);
    ctx.fillStyle = isBad ? cs.bad : soft.has(i) ? cs.mild : '#ffffff';
    ctx.strokeStyle = LEFT_IDX.has(i) ? cs.l : RIGHT_IDX.has(i) ? cs.r : cs.mid;
    ctx.lineWidth = lw * 0.6;
    ctx.beginPath(); ctx.arc(p.x * W, p.y * H, isBad ? lw * 2.2 : lw * 1.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    if (isBad) {
      ctx.strokeStyle = 'rgba(240,104,149,0.45)'; ctx.lineWidth = lw;
      ctx.beginPath(); ctx.arc(p.x * W, p.y * H, lw * 4.5, 0, Math.PI * 2); ctx.stroke();
    }
  }
}

// ─────────────────────────── rezime ───────────────────────────
function renderSummary() {
  const ex = state.ex, en = session.engine;
  if (!ex || !en) return;
  $('r-name').textContent = exText(ex, 'name');
  $('r-reps').textContent = en.reps;
  $('r-good').textContent = en.good;
  $('r-partial').textContent = en.partials;
  $('r-acc').textContent = en.reps ? Math.round((en.good / en.reps) * 100) + '%' : '–';
  const rec = state.lastRec && state.lastRec.exId === ex.id ? state.lastRec : null;
  $('r-quality').textContent = rec && rec.quality != null ? rec.quality : '–';
  $('r-dev').textContent = rec && rec.deviation != null ? rec.deviation + ' %' : '–';
  $('r-compare').innerHTML = (rec ? compareBlock(rec) : '') + overallBlock();
  const ul = $('r-errors'); ul.innerHTML = '';
  const top = en.topErrors();
  if (!top.length) {
    const li = document.createElement('li'); li.className = 'none';
    li.textContent = en.reps ? t('noErrors') : t('noReps');
    ul.appendChild(li);
  }
  for (const e of top) {
    const li = document.createElement('li');
    li.innerHTML = '<span></span><span></span>';
    li.children[0].textContent = errText(ex, e);
    li.children[1].textContent = `${e.count}×`;
    ul.appendChild(li);
  }
  // dnevnik samo ako je vežba stvarno odrađena (bar jedno ponavljanje)
  $('summary-log').hidden = !en.reps;
  if (en.reps) buildLogForm($('summary-log'), { exId: ex.id, sessionId: state.lastSessionId, title: true });
  else $('summary-log').innerHTML = '';
}
// Sesija se čuva na uređaju, a kod povezanog pacijenta šalje se i terapeutu
function saveSessionRecord() {
  const ex = state.ex, en = session.engine;
  if (!en || !en.reps) return null;
  const errors = {};
  for (const e of en.topErrors()) errors[e.id] = e.count;
  const total = (session.trackOk || 0) + (session.trackLost || 0);
  const rec = {
    id: String(Date.now()), exId: ex.id, date: Date.now(), reps: en.reps, good: en.good, partials: en.partials,
    tol: state.tol, romPeaks: en.romPeaks, errors, tracking: total ? Math.round((session.trackOk / total) * 100) / 100 : null,
    guidedId: guided.on ? guided.id : null, set: guided.on ? guided.set : null,
    planVersion: pt.data && pt.data.plan ? pt.data.plan.version : null,
    // kvalitet izvođenja i odstupanje (vidi progress.js)
    ...computeQuality({ reps: en.reps, good: en.good, romPeaks: en.romPeaks, fs: session.fs, target: ex.target }),
  };
  state.lastRec = rec;
  if (guided.on) (guided.exRecs[guided.i] = guided.exRecs[guided.i] || []).push(rec);
  addSession(rec);
  syncPut('session', { ...rec, id: undefined, localId: rec.id }).then((ok) => { if (ok === false) guided.synced = false; });
  return rec;
}

function showSummary() {
  state.lastRec = null;
  const rec = saveSessionRecord();
  state.lastSessionId = rec ? rec.id : null;
  show('summary');
  renderSummary();
}

// ─────────────────────────── vođena terapija ───────────────────────────
// Vežba bez kamere (iz AI programa ili od terapeuta): kamera ne prati, pacijent broji dugmetom
function customEx(it) {
  return {
    id: it.exId, isCustom: true, name: itemName(it), view: 'front', focus: [], region: '',
    start: 1, target: 2, hold: 0, defaultReps: it.reps || 10, summary: '', steps: it.custom.instructions || [],
    mistakes: [], placement: '', cue: itemName(it), tooLow: '',
    required: () => [], metric: () => ({ value: 0 }), checks: () => [],
    demo: { view: 'front', frames: [{ p: {}, d: 1 }] },
  };
}

function applyItem() {
  const it = guided.items[guided.i];
  state.item = it;
  if (it.custom) state.ex = customEx(it);
  else {
    const base = byId(it.exId);
    // ciljni opseg iz plana (npr. iz izveštaja: bočna fleksija desno 15°) zamenjuje podrazumevani cilj vežbe
    state.ex = it.romTarget ? { ...base, target: it.romTarget, start: Math.min(base.start, Math.max(3, Math.round(it.romTarget * 0.45))) } : base;
  }
  state.reps = it.reps || state.ex.defaultReps;
  state.tol = it.tol || loadTol();
}

function enterCustom() {
  const it = state.item;
  // tekst vežbe na trenutnom jeziku (AI program ima srpsku i englesku verziju)
  const c = { name: itemName(it), instructions: customField(it, 'instructions') || [], cautions: customField(it, 'cautions') || [], holdSec: it.custom.holdSec || 0 };
  session.phase = 'custom';
  setStatus('stActive', 'active');
  let count = 0, holdTimer = null;
  const panel = $('guide-panel');
  panel.innerHTML = `<h2>${esc(c.name)} · ${t('gSet', { s: guided.set, n: it.sets || 1 })}</h2>
    <p class="muted small">${t('cxNoCam')}</p>
    ${c.instructions && c.instructions.length ? `<ol class="cx-steps">${c.instructions.map((x) => `<li>${esc(x)}</li>`).join('')}</ol>` : ''}
    ${c.cautions && c.cautions.length ? `<p class="small" style="color:#f2b632">${c.cautions.map(esc).join(' · ')}</p>` : ''}
    <p class="cx-count" id="cx-count">${t('cxCount', { c: 0, n: it.reps })}</p>
    <div class="sp-actions">
      <button class="btn primary" type="button" id="cx-main">${c.holdSec ? t('cxHold', { s: c.holdSec }) : t('cxPlus')}</button>
      <button class="btn small" type="button" id="cx-done">${t('cxDone')}</button>
    </div>`;
  panel.hidden = false;
  coach.say(c.name + '. ' + (c.instructions && c.instructions[0] ? c.instructions[0] : ''), true);
  const finish = () => {
    clearInterval(holdTimer);
    panel.hidden = true;
    saveCustomSession(count);
    guidedNext('done');
  };
  const bump = () => {
    count++;
    $('cx-count').textContent = t('cxCount', { c: count, n: it.reps });
    coach.tone('good'); coach.say(numberWord(count));
    if (count >= it.reps) setTimeout(finish, 700);
  };
  $('cx-main').addEventListener('click', () => {
    if (!c.holdSec) { bump(); return; }
    if (holdTimer) return;
    const end = performance.now() + c.holdSec * 1000;
    const btn = $('cx-main');
    holdTimer = setInterval(() => {
      const left = Math.ceil((end - performance.now()) / 1000);
      if (left > 0) { btn.textContent = t('cxHolding', { s: left }); return; }
      clearInterval(holdTimer); holdTimer = null;
      btn.textContent = t('cxHold', { s: c.holdSec });
      bump();
    }, 200);
  });
  $('cx-done').addEventListener('click', finish);
}

function saveCustomSession(count) {
  if (!count) return;
  const it = state.item;
  const rec = { id: String(Date.now()), exId: it.exId, name: itemName(it), date: Date.now(), reps: count, good: count, partials: 0, tol: null,
    romPeaks: [], errors: {}, tracking: null, guidedId: guided.id, set: guided.set, planVersion: pt.data && pt.data.plan ? pt.data.plan.version : null };
  (guided.exRecs[guided.i] = guided.exRecs[guided.i] || []).push(rec);
  addSession(rec);
  syncPut('session', { ...rec, id: undefined, localId: rec.id }).then((ok) => { if (ok === false) guided.synced = false; });
}

function startGuided(plan) {
  if (!plan || !plan.items) return;
  guided.items = plan.items.filter(validItem);
  if (!guided.items.length) return;
  guided.on = true; guided.id = 'g' + Date.now(); guided.i = 0; guided.set = 1; guided.synced = true; guided.exRecs = [];
  guided.planId = plan.id || null; guided.logId = null; guided.logPending = false;
  // naziv programa za dnevnik (gotov program, AI program iz izveštaja ili program terapeuta)
  guided.presetId = plan.presetId || null;
  guided.programName = planTitle(plan);
  guided.results = guided.items.map((it) => ({ exId: it.exId, sets: it.sets || 1, setsDone: 0, status: 'pending', reason: null }));
  applyItem();
  startSession('exercise');
}

// Kraj serije/vežbe. Sledeća serija iste vežbe ide posle kratke pauze (kamera ostaje uključena),
// a kada je vežba gotova (ili preskočena / prekinuta) prikazuje se pregled te vežbe.
function guidedNext(kind) {
  const r = guided.results[guided.i];
  const it = guided.items[guided.i];
  if (kind === 'done') { r.setsDone++; r.status = r.setsDone >= r.sets ? 'done' : 'partial'; }
  else if (kind === 'skipped') r.status = r.setsDone ? 'partial' : 'skipped';
  else if (kind === 'stopped') r.status = r.setsDone || (guided.exRecs[guided.i] || []).length ? 'partial' : 'notdone';
  if (kind === 'done' && guided.set < (it.sets || 1)) { startRest(guided.i, guided.set + 1, 30); return; }
  coach.tone('done');
  center(t('finishedShort'));
  setTimeout(showStep, kind === 'done' ? 900 : 200);
}

function startRest(nextI, nextSet, secs) {
  session.phase = 'rest';
  session.finishing = false;
  center('');
  guided.pending = { i: nextI, set: nextSet };
  guided.restUntil = performance.now() + secs * 1000;
  const next = guided.items[nextI];
  const ex = next.custom ? customEx(next) : byId(next.exId);
  if (session.pip) session.pip.destroy();
  session.pip = next.custom ? null : createPlayer($('pip-canvas'), ex);
  const panel = $('guide-panel');
  panel.innerHTML = `<h2>${t('gRest')}</h2><p class="sp-verdict" data-v="ok" id="g-rest-text"></p>
    ${next.custom ? '' : `<p class="muted">${esc(exText(ex, 'placement'))}</p>`}
    <div class="sp-actions"><button class="btn primary" type="button" id="g-skip">${t('gSkipRest')}</button></div>`;
  panel.hidden = false;
  $('g-skip').addEventListener('click', beginNext);
  const name = next.custom ? itemName(next) : exText(ex, 'name');
  const update = () => {
    const left = Math.max(0, Math.ceil((guided.restUntil - performance.now()) / 1000));
    const el = $('g-rest-text');
    if (el) el.textContent = t('gRestText', { s: left, ex: name, set: nextSet, sets: next.sets || 1 });
    coach.render(null, t('gRest') + ' · ' + left + ' s');
    if (left <= 0) beginNext();
  };
  clearInterval(guided.timer);
  guided.timer = setInterval(update, 250);
  update();
  coach.say(`${t('gRest')}. ${t('gSet', { s: nextSet, n: next.sets || 1 })}`, true);
}

function beginNext() {
  clearInterval(guided.timer);
  if (!guided.pending) return;
  guided.i = guided.pending.i; guided.set = guided.pending.set; guided.pending = null;
  $('guide-panel').hidden = true;
  applyItem();
  setModeUi('exercise');
  resetExercise(true);
  if (state.ex.isCustom) enterCustom();
  else { setStatus('stActive', 'active'); coach.say(t('begin') + ' ' + exText(state.ex, 'cue'), true); }
}

// ── pregled jedne vežbe iz programa (sve serije zajedno) ──
const avgOf = (a) => (a.length ? Math.round(a.reduce((s, v) => s + v, 0) / a.length) : null);
function stepStats(i) {
  const recs = guided.exRecs[i] || [];
  const it = guided.items[i];
  const ex = it.custom ? null : byId(it.exId);
  const sum = (k) => recs.reduce((s, r) => s + (r[k] || 0), 0);
  const errors = {};
  for (const r of recs) for (const [k, v] of Object.entries(r.errors || {})) errors[k] = (errors[k] || 0) + v;
  return {
    custom: !!it.custom, ex, recs,
    reps: sum('reps'), good: sum('good'), partials: sum('partials'),
    target: (it.reps || (ex ? ex.defaultReps : 10)) * (it.sets || 1),
    quality: avgOf(recs.map((r) => r.quality).filter((v) => typeof v === 'number')),
    deviation: avgOf(recs.map((r) => r.deviation).filter((v) => typeof v === 'number')),
    errors: Object.entries(errors).map(([id, count]) => ({ id, count })).sort((a, b) => b.count - a.count),
  };
}
// boja stavke: zeleno = dobro, žuto = može bolje, crveno = treba popraviti
const lv = (v, good, mid, lower = false) => (v == null ? 'none' : lower ? (v <= good ? 'good' : v <= mid ? 'mid' : 'bad') : (v >= good ? 'good' : v >= mid ? 'mid' : 'bad'));
const LV_ICON = { good: '✓', mid: '!', bad: '✕', none: '–' };
const statusLv = (st) => (st === 'done' ? 'good' : st === 'partial' ? 'mid' : 'bad');
const statusText = (r) => (r.status === 'done' ? t('gDone') : r.status === 'partial' ? t('gPartial') : r.status === 'skipped' ? t('gSkipped') : t('gNotDone'));
function statTile(label, value, level) {
  return `<div class="st lv-${level}"><span class="st-ic" aria-hidden="true">${LV_ICON[level]}</span><span class="st-l">${label}</span><strong>${value}</strong></div>`;
}
function stepTiles(i) {
  const s = stepStats(i), r = guided.results[i];
  const tiles = [
    statTile(t('gStSets'), `${r.setsDone}/${r.sets}`, lv(r.setsDone / r.sets, 1, 0.01)),
    statTile(t('gStReps'), `${s.reps}/${s.target}`, lv(s.reps / s.target, 1, 0.7)),
  ];
  if (!s.custom && s.reps) {
    tiles.push(statTile(t('gStGood'), `${Math.round((s.good / s.reps) * 100)} %`, lv(s.good / s.reps, 0.8, 0.6)));
    tiles.push(statTile(t('gStPartial'), s.partials, lv(s.partials, 0, 2, true)));
    if (s.quality != null) tiles.push(statTile(t('gStQuality'), s.quality, lv(s.quality, 75, 55)));
    if (s.deviation != null) tiles.push(statTile(t('gStDev'), s.deviation + ' %', lv(s.deviation, 10, 20, true)));
  }
  return { s, html: `<div class="st-grid">${tiles.join('')}</div>` };
}

function showStep() {
  clearInterval(guided.timer);
  guided.pending = null;
  $('guide-panel').hidden = true;
  stopSession(false);
  show('gstep');
  renderStep();
  const next = guided.items[guided.i + 1];
  coach.say(t('gStepSay') + (next ? ' ' + t('gStepSayNext', { name: itemName(next) }) : ' ' + t('gStepSayLast')), true);
}

function renderStep() {
  const i = guided.i, it = guided.items[i], r = guided.results[i];
  const next = guided.items[i + 1];
  const { s, html } = stepTiles(i);
  const exName = itemName(it);
  // greške: jednom = žuto, više puta = crveno
  const errHtml = s.custom || !s.reps ? '' : `<h2 class="label">${t('gStErrors')}</h2><ul class="st-errors">${s.errors.length
    ? s.errors.map((e) => `<li class="lv-${e.count > 1 ? 'bad' : 'mid'}"><span class="st-ic" aria-hidden="true">${e.count > 1 ? '✕' : '!'}</span><span>${esc(errText(s.ex, e))}</span><span>${e.count}×</span></li>`).join('')
    : `<li class="lv-good"><span class="st-ic" aria-hidden="true">✓</span><span>${t('gNoErr')}</span><span></span></li>`}</ul>`;
  const last = s.recs[s.recs.length - 1];
  // napredak kroz program: svaka vežba u boji svog statusa
  const strip = guided.items.map((x, k) => {
    const rr = guided.results[k];
    const level = k > i ? 'none' : statusLv(rr.status);
    return `<span class="gs-dot lv-${level}${k === i ? ' cur' : ''}" title="${esc(itemName(x))}">${k + 1}</span>`;
  }).join('');
  $('gstep-root').innerHTML = `
    <p class="eyebrow">${esc(guided.programName)} · ${t('gStepOf', { i: i + 1, n: guided.items.length })}</p>
    <div class="gs-strip" aria-hidden="true">${strip}</div>
    <div class="gs-head"><h1></h1><span class="gs-badge lv-${statusLv(r.status)}">${statusText(r)}</span></div>
    ${r.reason ? `<p class="muted">${esc(t('reasons')[r.reason] || r.reason)}</p>` : ''}
    ${html}
    ${errHtml}
    <p class="gs-legend"><span class="lv-good">✓ ${t('lvGood')}</span><span class="lv-mid">! ${t('lvMid')}</span><span class="lv-bad">✕ ${t('lvBad')}</span></p>
    ${last && typeof last.quality === 'number' ? `<div class="compare">${compareShort(last) ? `<p>${compareShort(last)}</p>` : ''}</div>` : ''}
    <div class="gs-actions">
      ${next ? `<button class="btn primary big" type="button" id="gs-next">${esc(t('gNextEx', { name: itemName(next) }))}</button>` : ''}
      <button class="btn ${next ? 'ghost' : 'primary big'}" type="button" id="gs-end">${t('gEndTherapy')}</button>
    </div>`;
  $('gstep-root').querySelector('h1').textContent = exName;
  const nb = $('gs-next');
  if (nb) nb.addEventListener('click', () => {
    guided.i++; guided.set = 1;
    applyItem();
    startSession('exercise');
  });
  $('gs-end').addEventListener('click', endGuided);
}

// Kraj terapije (posle poslednje vežbe ili ranije): unos u dnevnik za ovaj program
function endGuided() {
  clearInterval(guided.timer);
  for (const r of guided.results) if (r.status === 'pending') r.status = 'notdone';
  guided.on = false;
  guided.pending = null;
  state.item = null;
  state.tol = loadTol();
  $('guide-panel').hidden = true;
  if (session.running) stopSession(false);
  guided.logId = null;
  const anyDone = guided.results.some((r, k) => r.setsDone > 0 || (guided.exRecs[k] || []).length);
  if (anyDone) {
    const entry = {
      id: String(Date.now()), date: Date.now(), auto: true,
      programName: guided.programName, presetId: guided.presetId, planId: guided.planId, guidedId: guided.id,
      pain: null, mobility: null, progress: null, note: '',
      exercises: guided.items.map((it, k) => ({ name: itemName(it), exId: it.exId, status: guided.results[k].status, q: stepStats(k).quality })),
    };
    addLog(entry);
    guided.logId = entry.id;
    guided.logPending = true; // šalje se terapeutu kada se doda ocena ili kada se napusti ekran
  }
  show('gsummary');
  renderGSummary();
}
// automatski unos terapije bez subjektivne ocene: pošalji terapeutu kada se napusti rezime
function flushProgramLog() {
  if (!guided.logPending || !guided.logId) return;
  guided.logPending = false;
  const l = getLogs().find((x) => x.id === guided.logId);
  if (l) syncPut('log', { ...l, id: undefined, localId: l.id });
}

function renderGSummary() {
  $('g-prog').textContent = guided.programName || '';
  const ul = $('g-list'); ul.innerHTML = '';
  guided.results.forEach((r, idx) => {
    const li = document.createElement('li');
    const level = statusLv(r.status);
    const q = stepStats(idx).quality;
    li.className = 'lv-' + level;
    li.innerHTML = `<span class="st-ic" aria-hidden="true">${LV_ICON[level]}</span><span class="what"></span><span class="res"></span>`;
    li.querySelector('.what').textContent = guided.items[idx] ? itemName(guided.items[idx]) : r.exId;
    li.querySelector('.res').textContent = statusText(r) + (q != null ? ' · ' + t('jQuality', { q }) : '') + (r.reason ? ' · ' + (t('reasons')[r.reason] || r.reason) : '');
    ul.appendChild(li);
  });
  $('g-compare').innerHTML = overallBlock();
  $('g-sync').textContent = api.auth('patient') ? (guided.synced ? t('gSent') : t('syncFail')) : '';
  const box = $('g-log');
  if (!guided.logId) { box.hidden = false; box.innerHTML = `<p class="muted">${t('gNoJournal')}</p>`; return; }
  box.hidden = false;
  buildLogForm(box, { title: true, logId: guided.logId, programName: guided.programName, presetId: guided.presetId, guidedId: guided.id,
    intro: t('gJournalAuto'), onSaved: () => { guided.logPending = false; } });
}

// "Ne mogu da uradim": prijava terapeutu, a za prostor/opremu i predlog zamena (odobrava samo terapeut)
function openCannot() {
  if (!guided.on) return;
  guided.prevPhase = session.phase;
  session.phase = 'cannot';
  const reasons = t('reasons');
  const panel = $('guide-panel');
  panel.innerHTML = `<h2>${t('cannotTitle')}</h2><p class="muted">${t('cannotText')}</p>
    <div class="choice">${Object.keys(reasons).map((k, i) => `<label><input type="radio" name="cn-r" value="${k}" ${i === 0 ? 'checked' : ''}><span>${reasons[k]}</span></label>`).join('')}</div>
    <textarea id="cn-text" rows="2" placeholder="${t('cannotNotePh')}"></textarea>
    <div id="cn-alt"></div>
    <div class="sp-actions"><button class="btn primary" type="button" id="cn-send">${t('cannotSend')}</button>
    <button class="btn small" type="button" id="cn-cancel">${t('cannotCancel')}</button></div>`;
  panel.hidden = false;
  $('cn-cancel').addEventListener('click', () => { panel.hidden = true; session.phase = guided.prevPhase || 'position'; });
  $('cn-send').addEventListener('click', async () => {
    const reason = panel.querySelector('input[name="cn-r"]:checked').value;
    const text = $('cn-text').value.trim();
    const ex = state.ex;
    guided.results[guided.i].reason = reason;
    await syncPut('report', { exId: ex.id, name: ex.isCustom ? ex.name : undefined, reason, text, date: Date.now(), guidedId: guided.id });
    if (reason === 'space' || reason === 'equipment') {
      const home = getHome() || undefined;
      const f = feasibility(ex, home);
      const alts = alternatives(ex, EXERCISES, home);
      if (api.auth('patient')) await syncPut('proposal', { kind: 'substitute', fromExId: ex.id, reason, blockers: f.blockers, options: alts.map((a) => a.id), status: 'pending', date: Date.now() });
      $('cn-alt').innerHTML = `<p class="notice">${alts.length ? (api.auth('patient') ? t('altSent') : t('haAskTherapist')) + ' ' + alts.map((a) => exText(a, 'name')).join(', ') : t('altNone')}</p>`;
      $('cn-send').disabled = true;
      setTimeout(() => { panel.hidden = true; guidedNext('skipped'); }, 2600);
    } else {
      panel.hidden = true;
      guidedNext('skipped');
    }
  });
}
$('btn-again').addEventListener('click', () => { show('detail'); startSession('exercise'); });
$('btn-home').addEventListener('click', () => { location.hash = 'vezbe'; });

// ─────────────────────────── unos: bol, pokretljivost, napredak ───────────────────────────
let formSeq = 0;
// Unos u dnevnik postoji samo na kraju vežbe (exId, sessionId) ili programa (programName, presetId, guidedId)
// logId: automatski unos terapije koji se dopunjuje ocenom (umesto novog unosa)
function buildLogForm(container, { exId = null, sessionId = null, title = false, onSaved, programName = null, presetId = null, guidedId = null, logId = null, intro = '' } = {}) {
  const k = 'f' + ++formSeq;
  // padajući meni: 1–5 sa opisom, prazan izbor dok korisnik ne odabere
  const select = (name, labels) => `<select id="${k}-${name}" class="log-select"><option value="">${t('logChoose')}</option>${labels.map((lb, i) => `<option value="${i + 1}">${i + 1} – ${lb}</option>`).join('')}</select>`;
  container.innerHTML = `
    ${title ? `<h3>${t('logTitle')}</h3>` : ''}
    ${intro ? `<p class="muted">${esc(intro)}</p>` : ''}
    <div class="field">
      <label class="fl" for="${k}-pain">${t('logPain')}</label>
      <div class="pain-row"><input id="${k}-pain" type="range" min="0" max="10" step="1" value="0"><output class="pain-val" id="${k}-pv">0</output></div>
    </div>
    <div class="field"><label class="fl" for="${k}-mob">${t('logMobility')}</label>${select('mob', t('mobLabels'))}</div>
    <div class="field"><label class="fl" for="${k}-prog">${t('logProgress')}</label>${select('prog', t('progLabels'))}</div>
    <div class="field"><label class="fl" for="${k}-note">${t('logNote')}</label><textarea id="${k}-note" rows="2"></textarea></div>
    <div class="start-row"><button type="button" class="btn primary" id="${k}-save">${t('logSave')}</button><span class="saved" id="${k}-ok" role="status"></span></div>`;
  const pain = container.querySelector(`#${k}-pain`);
  pain.addEventListener('input', () => { container.querySelector(`#${k}-pv`).textContent = pain.value; });
  container.querySelector(`#${k}-save`).addEventListener('click', () => {
    const val = (n) => { const v = container.querySelector(`#${k}-${n}`).value; return v ? Number(v) : null; };
    const fields = { pain: Number(pain.value), mobility: val('mob'), progress: val('prog'), note: container.querySelector(`#${k}-note`).value.trim() };
    const entry = logId ? updateLog(logId, fields)
      : { id: String(Date.now()), date: Date.now(), exId, sessionId, programName, presetId, guidedId, ...fields };
    if (!logId) addLog(entry);
    if (entry) syncPut('log', { ...entry, id: undefined, localId: entry.id });
    // sačuvan unos se zaključava: ne može se menjati ni ponovo slati
    container.querySelectorAll('input, textarea, select, button').forEach((el) => { el.disabled = true; });
    container.classList.add('locked');
    container.querySelector(`#${k}-ok`).textContent = '🔒 ' + t('logLocked');
    if (onSaved) onSaved();
  });
}

// ─────────────────────────── dnevnik ───────────────────────────
let clearArmed = false;
// Dnevnik: samo unosi napravljeni na kraju odrađene vežbe ili programa (nema slobodnog unosa).
// Unosi su grupisani po programu; pojedinačne vežbe su u svojoj grupi.
function journalTitle(l) {
  if (l.presetId && presetById(l.presetId)) return { kind: 'prog', name: presetShort(presetById(l.presetId)) };
  // ako program još postoji, naziv se uzima iz njega (kratak, na trenutnom jeziku)
  const pl = l.planId && l.planId !== 'terapeut' ? getLocalPlan(l.planId) : null;
  if (pl) return { kind: 'prog', name: planTitle(pl) };
  if (l.programName) return { kind: 'prog', name: l.programName };
  if (l.exId) { const ex = byId(l.exId); return { kind: 'ex', name: ex ? exText(ex, 'name') : (l.exName || l.exId) }; }
  return { kind: 'gen', name: t('jGeneral') };
}
const journalGroup = (l) => l.planId || (l.presetId ? 'preset:' + l.presetId : l.programName ? 'name:' + l.programName : l.guidedId ? 'prog' : 'single');

function journalEntry(l, sessions, inProgram) {
  const head = journalTitle(l);
  // rezultat sesije na koju se unos odnosi
  let res = '';
  if (l.sessionId) {
    const s = sessions.find((x) => x.id === l.sessionId);
    if (s) res = t('historyResult', { good: s.good, reps: s.reps }) + (typeof s.quality === 'number' ? ' · ' + t('jQuality', { q: s.quality }) : '');
  } else if (l.guidedId) {
    const ss = sessions.filter((x) => x.guidedId === l.guidedId);
    if (ss.length) {
      const q = ss.map((x) => x.quality).filter((v) => typeof v === 'number');
      res = t('jProgDone', { n: new Set(ss.map((x) => x.exId)).size }) + (q.length ? ' · ' + t('jQuality', { q: Math.round(q.reduce((a, b) => a + b, 0) / q.length) }) : '');
    }
  }
  const vals = [];
  if (l.pain != null) vals.push(`${t('painShort')} ${l.pain}/10`);
  if (l.mobility) vals.push(`${t('mobilityShort')}: ${t('mobLabels')[l.mobility - 1]}`);
  if (l.progress) vals.push(`${t('progressShort')}: ${t('progLabels')[l.progress - 1]}`);
  const li = document.createElement('li');
  li.className = 'j-entry';
  li.title = t('logLocked');
  // vežbe iz te terapije, svaka u boji svog statusa
  const chips = (l.exercises || []).map((e) => {
    const level = e.status === 'done' ? 'good' : e.status === 'partial' ? 'mid' : 'bad';
    return `<span class="j-chip lv-${level}">${LV_ICON[level]} ${esc(e.exId && byId(e.exId) ? exText(byId(e.exId), 'name') : e.name)}${e.q != null ? ' · ' + e.q : ''}</span>`;
  }).join('');
  li.innerHTML = `<div class="j-h">${inProgram ? '' : `<span class="j-kind k-${head.kind}">${t(head.kind === 'prog' ? 'jKindProg' : head.kind === 'ex' ? 'jKindEx' : 'jKindGen')}</span><strong></strong>`}
      <time></time><span class="j-lock" aria-hidden="true">🔒</span></div>
    <div class="j-vals"></div>${res ? '<div class="j-res"></div>' : ''}${chips ? `<div class="j-chips">${chips}</div>` : ''}${l.note ? '<p class="j-note"></p>' : ''}`;
  if (!inProgram) li.querySelector('strong').textContent = head.name;
  li.querySelector('time').textContent = fmtDate(l.date);
  const v = li.querySelector('.j-vals');
  if (vals.length) v.textContent = vals.join(' · '); else { v.textContent = t('jNoSubjective'); v.classList.add('muted'); }
  if (res) li.querySelector('.j-res').textContent = res;
  if (l.note) li.querySelector('.j-note').textContent = `„${l.note}“`;
  return li;
}

function renderJournal() {
  const sessions = getSessions();
  const logs = getLogs().slice().sort((a, b) => b.date - a.date);
  const ul = $('j-list'); ul.innerHTML = '';
  if (!logs.length) { const li = document.createElement('li'); li.className = 'j-empty'; li.textContent = t('jNone'); ul.appendChild(li); return; }
  // grupe po programu, redom po poslednjem unosu
  const groups = new Map();
  for (const l of logs) {
    const key = journalGroup(l);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(l);
  }
  for (const [key, list] of groups) {
    const single = key === 'single';
    const first = list[0];
    const plan = first.planId === 'terapeut' ? { therapist: true } : first.planId ? getLocalPlan(first.planId) : null;
    const color = plan ? (plan.therapist ? 'th' : plan.color || 0) : first.presetId ? (getLocalPlans().find((p) => p.presetId === first.presetId) || {}).color : null;
    const g = document.createElement('li');
    g.className = 'j-group' + (color != null ? ' pc-' + color : '') + (single ? ' j-single' : '');
    g.innerHTML = `<details open><summary><span class="j-kind ${single ? 'k-ex' : 'k-prog'}">${single ? t('jKindEx') : t('jKindProg')}</span>
        <strong></strong><span class="j-count">${t('jEntries', { n: list.length })}</span></summary>
        <div class="j-actions"><a class="btn ghost small-btn" href="#izvestaj-${encodeURIComponent(key)}">${t('openReport')}</a></div>
        <ul class="j-sub"></ul></details>`;
    g.querySelector('strong').textContent = single ? t('jSingles') : journalTitle(first).name;
    const sub = g.querySelector('.j-sub');
    for (const l of list.slice(0, 40)) sub.appendChild(journalEntry(l, sessions, !single));
    ul.appendChild(g);
  }
}

// brisanje svih podataka sa uređaja (u Profilu, uz potvrdu drugim klikom)
$('btn-clear').addEventListener('click', () => {
  if (!clearArmed) { clearArmed = true; $('btn-clear').textContent = t('jClearConfirm'); return; }
  clearAll(); clearArmed = false; $('btn-clear').textContent = t('clearDevice');
  $('dlg-profile').close(); rerender();
});

// ─────────────────────────── izveštaj ───────────────────────────
let lastReport = null;
// Izveštaj jednog programa: isti unosi kao u kartici tog programa u Dnevniku, plus sesije tih terapija.
// Grupa 'single' su vežbe rađene van programa.
function reportScope(key) {
  if (!key) return null;
  const logs = getLogs().filter((l) => journalGroup(l) === key).sort((a, b) => b.date - a.date);
  const single = key === 'single';
  const ids = new Set(logs.map((l) => l.guidedId).filter(Boolean));
  return {
    logs: (l) => journalGroup(l) === key,
    sessions: single ? (s) => !s.guidedId : (s) => ids.has(s.guidedId),
    title: single ? t('jSingles') : logs[0] ? journalTitle(logs[0]).name : t('myProgram'),
  };
}
function scopeStart(scope) {
  const dates = [...getSessions().filter(scope.sessions), ...getLogs().filter(scope.logs)].map((x) => x.date);
  return dates.length ? Math.min(...dates) : null;
}
function openProgramReport(key) {
  state.reportBack = state.view === 'program' && state.programId ? 'moj-' + state.programId : 'dnevnik';
  state.reportKey = key;
  // period koji obuhvata ceo program (3, 7 ili najviše 14 dana)
  const first = scopeStart(reportScope(key));
  if (first) state.reportDays = [3, 7, 14].find((d) => d > Math.round((startOfDay(Date.now()) - startOfDay(first)) / 86400000)) || 14;
  show('report');
  if (state.reportBack !== 'dnevnik') setTab('programs');
  renderReportView();
}
function renderReportView() {
  const scope = reportScope(state.reportKey);
  const st = scope ? reportStatusFrom(scopeStart(scope)) : reportStatus();
  $('rp-notready').hidden = st.ready;
  if (!st.ready) $('rp-notready').textContent = t('rpNotReady', { n: st.daysLeft, unit: unitDays(st.daysLeft) });
  document.querySelectorAll('#rp-period button').forEach((b) => b.classList.toggle('on', Number(b.dataset.days) === state.reportDays));
  lastReport = collect(state.reportDays, Date.now(), scope);
  $('report-body').innerHTML = renderReport(lastReport);
  $('rp-toast').textContent = '';
}
document.querySelectorAll('#rp-period button').forEach((b) => b.addEventListener('click', () => { state.reportDays = Number(b.dataset.days); renderReportView(); }));
$('rp-print').addEventListener('click', () => window.print());
$('rp-csv').addEventListener('click', () => {
  const blob = new Blob(['﻿' + reportCsv(lastReport)], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  const slug = lastReport.title ? lastReport.title.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').toLowerCase() + '-' : '';
  a.download = `phys-izvestaj-${slug}${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});
$('rp-share').addEventListener('click', async () => {
  const text = reportText(lastReport);
  try {
    if (navigator.share) { await navigator.share({ title: t('rpTitle'), text }); return; }
  } catch { /* korisnik je odustao */ return; }
  try { await navigator.clipboard.writeText(text); $('rp-toast').textContent = t('rpCopied'); } catch { /* */ }
});

// ─────────────────────────── slika izveštaja fizioterapeuta ───────────────────────────
// "Nazad na početak": briše učitani fajl, tekst i rezultate i vraća tab Novi program na početni izgled
function scanDirty() {
  return !!($('sc-text').value.trim() || state.scan || state.aiResult || state.scanFile || $('sc-file-info').textContent || !$('sc-preview').hidden);
}
function updateScanReset() { $('sc-reset').hidden = !scanDirty(); }
function resetScan() {
  for (const id of ['sc-cam', 'sc-file']) $(id).value = '';
  $('sc-file-info').textContent = ''; $('sc-progress').textContent = ''; $('sc-ai-status').textContent = '';
  $('sc-preview').hidden = true; $('sc-preview').removeAttribute('src');
  $('sc-text').value = ''; $('sc-results').innerHTML = ''; $('sc-ai-out').innerHTML = '';
  state.scan = null; state.aiResult = null; state.scanFile = null;
  updateScanReset();
  window.scrollTo(0, 0);
}
$('sc-reset').addEventListener('click', resetScan);
$('view-scan').addEventListener('input', updateScanReset);
$('view-scan').addEventListener('change', () => setTimeout(updateScanReset, 0));
$('view-scan').addEventListener('click', () => setTimeout(updateScanReset, 0));

// AI analiza izveštaja (pacijent): povezan pacijent šalje predlog terapeutu, nepovezan dobija lokalni program
$('sc-ai-run').addEventListener('click', async () => {
  const st = $('sc-ai-status'), out = $('sc-ai-out'), btn = $('sc-ai-run');
  const text = $('sc-text').value.trim();
  const role = api.auth('patient') ? 'patient' : null;
  if (!text && !state.scanFile) { st.textContent = t('aiNeedInput'); return; }
  btn.disabled = true;
  st.textContent = t('aiRunning', { s: 0 });
  try {
    const result = await aiGenerate({ role, text, file: state.scanFile, onTick: (s) => { st.textContent = t('aiRunning', { s }); } });
    st.textContent = '';
    state.aiResult = { result, done: '' };
    showScanAi();
  } catch (e) {
    st.textContent = aiErrorText(e);
  } finally { btn.disabled = false; }
});

// Prikaz AI rezultata na ekranu za skeniranje (ponovo se iscrtava pri promeni jezika)
function showScanAi() {
  const s = state.aiResult;
  const out = $('sc-ai-out');
  updateScanReset();
  if (!s) { out.innerHTML = ''; return; }
  const linked = !!api.auth('patient');
  out.innerHTML = aiRender(s.result) + `<div class="start-row"><button class="btn primary" type="button" id="sc-ai-use" ${s.done ? 'disabled' : ''}>${linked ? t('aiSendTherapist') : t('aiUseLocal')}</button><span class="saved" id="sc-ai-ok" role="status">${s.done ? t(s.done) : ''}</span></div>`;
  $('sc-ai-use').addEventListener('click', async () => {
    const key = await addProgramResult(s.result);
    s.done = key === 'syncFail' ? '' : key;
    $('sc-ai-ok').textContent = t(key);
    $('sc-ai-use').disabled = !!s.done;
  });
}

// Dodavanje programa u "moje programe" (isto za program iz izveštaja i za gotov program):
// povezan pacijent šalje predlog terapeutu na odobrenje, nepovezan dobija lokalni program.
// Vraća ključ poruke: 'aiSent' | 'aiLocalOk' | 'syncFail'
async function addProgramResult(result) {
  const prog = programFor(result);
  const items = toPlanItems(result);
  if (api.auth('patient')) {
    const ok = await syncPut('proposal', { kind: 'ai', ai: result, items, status: 'pending', date: Date.now() });
    return ok ? 'aiSent' : 'syncFail';
  }
  addLocalPlan({ version: 1, items, days: prog.days && prog.days.length ? prog.days : [1, 3, 5], status: 'active', ai: !result.presetId,
    note: aiPlanNote(result), noteI18n: aiPlanNotes(result), aiSummary: prog.summary || null, aiSummaryI18n: aiSummaries(result), presetId: result.presetId || null });
  return 'aiLocalOk';
}

// ─────────────────────────── gotovi programi ───────────────────────────
function renderPresetList() {
  const box = $('preset-list');
  box.innerHTML = PRESETS.map((p) => `<a class="preset-card" href="#program-${p.id}">
      ${bodySvg(p, { small: true })}
      <span><strong>${esc(presetShort(p))}</strong><small>${esc(programFor(presetResult(p)).items.length + ' ' + t('presetCount'))}</small></span>
    </a>`).join('');
}

function openPreset(id) {
  state.presetId = id;
  show('preset');
  renderPreset(id);
}

function renderPreset(id) {
  const p = presetById(id);
  if (!p) return;
  const result = presetResult(p);
  const prog = programFor(result);
  const s = prog.summary;
  const days = t('weekdays');
  const added = !api.auth('patient') && getLocalPlans().some((x) => x.presetId === id);
  $('preset-root').innerHTML = `
    <div class="preset-fig">${bodySvg(p)}</div>
    <div class="preset-info">
      <p class="eyebrow">${t('presetsTitle')}</p>
      <h1>${esc(presetShort(p))}</h1>
      <p class="lead">${esc(s.condition)}</p>
      ${s.redFlags && s.redFlags.length ? `<div class="caution">${s.redFlags.map(esc).join('<br>')}</div>` : ''}
      <h2 class="label">${t('presetExercises')} · ${prog.items.length}</h2>
      <ol class="preset-items">${prog.items.map((it) => {
        const lib = it.kind === 'library' && byId(it.exId);
        const dose = it.holdSec > 0 ? `${it.sets} × ${it.reps} × ${it.holdSec} s` : `${it.sets} × ${it.reps}`;
        const rom = it.romTarget > 0 ? ' · ' + t('aiRomTarget', { v: it.romTarget }) : '';
        return `<li>
          <div class="pi-h">${lib ? `<a href="#${it.exId}"><strong>${esc(exText(lib, 'name'))}</strong></a>` : `<strong>${esc(it.name)}</strong>`}
            <span class="tag ${lib ? 'cam' : ''}">${lib ? t('aiCam') : t('aiNoCam')}</span></div>
          <div class="ai-dose">${dose}${rom}</div>
          ${it.instructions && it.instructions.length ? `<details><summary>${t('aiHow')}</summary><ol>${it.instructions.map((x) => `<li>${esc(x)}</li>`).join('')}</ol></details>` : ''}
        </li>`;
      }).join('')}</ol>
      <p><strong>${t('clDays')}:</strong> ${(prog.days || []).map((d) => days[d - 1]).join(', ')}</p>
      ${prog.avoid && prog.avoid.length ? `<p><strong>${t('aiAvoid')}:</strong> ${prog.avoid.map(esc).join('; ')}</p>` : ''}
      <div class="start-row">
        <button class="btn primary" type="button" id="preset-add" ${added ? 'disabled' : ''}>${api.auth('patient') ? t('aiSendTherapist') : t('presetAdd')}</button>
        <span class="saved" id="preset-ok" role="status">${added ? t('aiLocalOk') : ''}</span>
      </div>
    </div>`;
  $('preset-add').addEventListener('click', async () => {
    const key = await addProgramResult(presetResult(p));
    $('preset-ok').textContent = t(key);
    $('preset-add').disabled = key !== 'syncFail';
  });
}

// Izveštaj iz kamere ili iz fajla (PDF, Word, tekst, slika)
async function handleScanFile(file) {
  state.scanFile = null;
  if (!file) return;
  const info = $('sc-file-info'), img = $('sc-preview');
  $('sc-results').innerHTML = '';
  $('sc-ai-out').innerHTML = '';
  state.aiResult = null;
  info.textContent = t('fileReading', { name: file.name || '' });
  updateScanReset();
  let r;
  try { r = await readReport(file); }
  catch (e) { info.textContent = e.code === 'too_big' ? t('fileTooBig') : e.code === 'doc' ? t('fileDoc') : t('fileUnsupported'); return; }
  // AI dobija fajl samo kada nema čitljivog teksta (slika, skenirani PDF); inače dobija izvučeni tekst
  state.scanFile = r.scanned ? file : null;
  if (r.kind === 'image') {
    img.src = URL.createObjectURL(file); img.hidden = false;
    info.textContent = file.name || '';
    $('sc-progress').textContent = t('scLoadingOcr');
    try {
      const text = await recognize(file, (p) => { $('sc-progress').textContent = t('scReading', { p: Math.round(p * 100) }); });
      $('sc-text').value = text.trim();
      $('sc-progress').textContent = '';
      analyzeScan();
    } catch { $('sc-progress').textContent = t('scOcrFail'); }
    return;
  }
  img.hidden = true;
  if (r.scanned) { $('sc-text').value = ''; info.textContent = t('fileScanned', { name: file.name }); return; }
  $('sc-text').value = r.text;
  info.textContent = t('fileRead', { name: file.name });
  analyzeScan();
}
$('sc-file').accept = ACCEPT;
$('sc-file').addEventListener('change', (e) => handleScanFile(e.target.files && e.target.files[0]));
$('sc-cam').addEventListener('change', (e) => handleScanFile(e.target.files && e.target.files[0]));
$('sc-analyze').addEventListener('click', analyzeScan);

function analyzeScan() {
  const text = $('sc-text').value;
  if (!text.trim()) return;
  state.scan = { ...suggest(text), planItems: parsePlan(text) };
  renderScanResults(state.scan);
  updateScanReset();
}

function renderScanResults(res) {
  const box = $('sc-results');
  box.className = 'results';
  const linked = !!api.auth('patient');
  const areas = t('areas'), cz = t('cautions');
  let html = '';

  // 1) vežbe koje su već propisane u papirnom planu (Scan-to-Plan)
  if (res.planItems.length) {
    html += `<h2 class="label">${t('scFoundPlan')}</h2><ul class="sug-list">${res.planItems.map((i) => `<li><span>•</span><span><strong>${esc(exText(byId(i.exId), 'name'))}</strong>
      <small>${i.sets || 1} × ${i.reps || byId(i.exId).defaultReps} · „${esc(i.line)}“</small></span></li>`).join('')}</ul>`;
    html += linked
      ? `<div class="start-row"><button type="button" class="btn primary" id="sc-send">${t('scSendTherapist')}</button><span class="saved" id="sc-sent" role="status"></span></div>`
      : `<div class="start-row"><button type="button" class="btn primary" id="sc-saveplan">${t('scSave')}</button><span class="saved" id="sc-saved2" role="status"></span></div>`;
  }
  if (res.cautions.length) html += `<div class="caution"><strong>${t('czIntro')}</strong><ul>${res.cautions.map((c) => `<li>${cz[c]}</li>`).join('')}</ul></div>`;

  // 2) dijagnoza: povezani pacijent dobija samo temu za razgovor, terapiju određuje terapeut
  if (linked && res.matches.length) {
    html += `<p class="muted">${t('scDiagHint')} ${res.matches.map((m) => esc(exText(byId(m.exId), 'name'))).join(', ')}</p>`;
    box.innerHTML = html;
    bindScanPlan(res, linked);
    return;
  }
  if (!res.matches.length) {
    if (!res.planItems.length) html += `<p class="notice">${t('scNoMatch')}</p>`;
    box.innerHTML = html;
    bindScanPlan(res, linked);
    return;
  }
  html += `<p><strong>${t('scFound')}:</strong> ${res.areas.map((a) => areas[a] || a).join(', ')}</p>`;
  box.innerHTML = html;
  bindScanPlan(res, linked);
  renderDiagSuggestions(res, box);
}

function bindScanPlan(res, linked) {
  const send = $('sc-send');
  if (send) send.addEventListener('click', async () => {
    const ok = await syncPut('proposal', { kind: 'scan', items: res.planItems.map(({ exId, sets, reps }) => ({ exId, sets, reps })), status: 'pending', date: Date.now() });
    $('sc-sent').textContent = ok ? t('scSentTherapist') : t('syncFail');
    send.disabled = !!ok;
  });
  const save = $('sc-saveplan');
  if (save) save.addEventListener('click', () => {
    addLocalPlan({ title: t('scPlanTitle'), days: [], status: 'active',
      items: res.planItems.map((i) => ({ exId: i.exId, sets: i.sets || 1, reps: i.reps || byId(i.exId).defaultReps })) });
    $('sc-saved2').textContent = t('scSaved');
    save.disabled = true;
  });
}

function renderDiagSuggestions(res, box) {
  const areas = t('areas');
  let html = '';
  if (res.dosage && !res.planItems.length) html += `<p class="muted">${t('scDosage', { s: res.dosage.sets, r: res.dosage.reps })}</p>`;
  html += `<h2 class="label">${t('scSuggested')}</h2><ul class="sug-list diag">`;
  for (const m of res.matches) {
    const ex = byId(m.exId); if (!ex) continue;
    html += `<li><input type="checkbox" id="sg-${m.exId}" value="${m.exId}" ${m.careful ? '' : 'checked'}>
      <label for="sg-${m.exId}"><strong>${exText(ex, 'name')}</strong>
      <small>${t('scBecause', { w: m.words.join(', ') })}</small>
      ${m.careful ? `<small class="down">${t('scCareful')}</small>` : ''}</label></li>`;
  }
  html += `</ul><p class="muted small">${t('scDisclaimer')}</p>
    <div class="start-row"><button type="button" class="btn primary" id="sc-save">${t('scSave')}</button><span class="saved" id="sc-saved" role="status"></span></div>`;
  box.insertAdjacentHTML('beforeend', html);
  $('sc-save').addEventListener('click', () => {
    const chosen = [...box.querySelectorAll('.sug-list.diag input:checked')].map((i) => i.value);
    const areasTxt = res.areas.map((a) => areas[a] || a).join(', ');
    if (!chosen.length) return;
    // kratak naziv: najviše dva prepoznata dela tela
    const areasShort = res.areas.slice(0, 2).map((a) => areas[a] || a).join(', ');
    addLocalPlan({ title: areasShort ? areasShort.charAt(0).toUpperCase() + areasShort.slice(1) : t('scPlanTitle'), days: [], status: 'active',
      items: chosen.map((exId) => ({ exId, sets: res.dosage ? res.dosage.sets || 1 : 1, reps: res.dosage ? res.dosage.reps : byId(exId).defaultReps })) });
    $('sc-saved').textContent = t('scSaved');
    $('sc-save').disabled = true;
  });
}
$('sc-text').placeholder = t('scTextPh');
onLangChange(() => { $('sc-text').placeholder = t('scTextPh'); });

// tema se promenila -> osveži boje demonstratora
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', refreshAllColors);

// ─────────────────────────── primer podataka (?demo=1) ───────────────────────────
// Za prikaz izveštaja fizioterapeutu pre stvarnog korišćenja. Briše se dugmetom u dnevniku.
function seedDemo() {
  if (getSessions().length || getLogs().length) return;
  const DAY = 86400000, base = new Date().setHours(0, 0, 0, 0) - 3 * DAY;
  const plan = [
    { pain: 6, mob: 2, prog: 3, rom: 68 }, { pain: 5, mob: 2, prog: 4, rom: 74 },
    { pain: 4, mob: 3, prog: 4, rom: 79 }, { pain: 3, mob: 4, prog: 4, rom: 84 },
  ];
  plan.forEach((d, i) => {
    const ts = Math.min(base + i * DAY + 9 * 3600000, Date.now() - 3600000); // nikad u budućnosti
    addSession({ id: 'demo-s' + i, exId: 'lateral-raise', date: ts, reps: 10, good: 6 + i, partials: 2 - Math.min(2, i), tol: 0.1,
      romPeaks: Array.from({ length: 10 }, (_, k) => d.rom + (k % 3) - 1), errors: i < 2 ? { shrug: 3 - i, elbow: 1 } : { shrug: 1 },
      quality: 58 + i * 7, deviation: 30 - i * 6, romAvg: d.rom, accuracy: (6 + i) * 10, formScore: 70 + i * 6, romPct: Math.min(100, Math.round((d.rom / 80) * 100)), target: 80 });
    addSession({ id: 'demo-q' + i, exId: 'squat', date: ts + 600000, reps: 8, good: 5 + i, partials: 1, tol: 0.1,
      romPeaks: Array.from({ length: 8 }, () => 58 + i * 4), errors: { lean: 2 },
      quality: 62 + i * 4, deviation: 22 - i * 3, romAvg: 58 + i * 4, accuracy: Math.round(((5 + i) / 8) * 100), target: 70 });
    // naizmenično: unos posle jedne vežbe / posle cele sesije (program)
    const link = i % 2 === 0 ? { exId: 'lateral-raise', sessionId: 'demo-s' + i } : { exId: 'squat', sessionId: 'demo-q' + i };
    addLog({ id: 'demo-l' + i, date: ts + 900000, ...link, pain: d.pain, mobility: d.mob, progress: d.prog,
      note: i === 0 ? 'Bol u desnom ramenu pri podizanju ruke iznad glave.' : i === 3 ? 'Lakše oblačim jaknu.' : '' });
  });
}

// ─────────────────────────── start ───────────────────────────
if (new URLSearchParams(location.search).get('demo') === '1') seedDemo();
mountClinic($('clinic-root'));
// pozivni link terapeuta: ?join=KOD
const joinCode = new URLSearchParams(location.search).get('join');
if (joinCode) {
  $('join-code').value = joinCode.toUpperCase();
  history.replaceState(null, '', location.pathname + '#povezi');
}
applyStatic();
syncLangButtons();
profileLabel();
loadVideoManifest().then(() => {
  route();
  // profil pacijenta (pol, uzrast) se ne traži od terapeuta, niti od pacijenta koji tek dolazi preko pozivnice
  if (!getProfile() && !location.hash.startsWith('#klinika') && !joinCode) openProfile();
});

// samo za automatske testove (?debug=1): pristup toku terapije bez prave kamere
if (new URLSearchParams(location.search).get('debug') === '1') window.__fz = { guided, session, state, guidedNext, beginNext, saveSessionRecord, startGuided, getLocalPlans, vx, renderImportResult, show };
