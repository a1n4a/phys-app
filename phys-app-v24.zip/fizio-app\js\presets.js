// Gotovi programi (unapred pripremljeni, isti oblik kao AI program iz izveštaja).
// Dodaju se u "moje programe" na isti način kao program iz izveštaja.
import { t, getLang } from './i18n.js';

const KNEE_SR = {
  summary: {
    condition: 'Patelofemoralni bolni sindrom – bol ispred kolena („trkačko koleno“)',
    region: 'Koleno', side: 'both', irritability: 'moderate',
    keyFindings: ['Tup bol oko ili iza čašice kolena', 'Bol se pojačava pri čučanju, silasku niz stepenice i dugom sedenju', 'Bez otoka i bez povrede ligamenata'],
    romFindings: [],
    redFlags: ['Otok, blokada ili „propadanje“ kolena – javite se lekaru'],
    goals: ['Silazak niz stepenice bez bola', 'Povratak trčanju i sportu'],
    phase: 'Početna faza: jačanje kuka i natkolenice bez bola',
  },
  items: [
    { kind: 'library', exId: 'hip-abduction', name: 'Bočno podizanje noge', reason: 'Jačanje gluteus medius-a smanjuje opterećenje čašice.', sets: 3, reps: 12, holdSec: 0, side: 'both', romTarget: 0, romMax: 0, instructions: [], cautions: [] },
    { kind: 'library', exId: 'squat', name: 'Čučanj do stolice', reason: 'Plitak čučanj u bezbolnom opsegu jača kvadriceps.', sets: 3, reps: 10, holdSec: 0, side: 'both', romTarget: 60, romMax: 75, instructions: [], cautions: ['Samo do granice bola, kolena ne prelaze prste'] },
    { kind: 'library', exId: 'calf-raise', name: 'Podizanje na prste', reason: 'Jačanje lista i stabilnost pri hodu i trčanju.', sets: 2, reps: 15, holdSec: 0, side: 'both', romTarget: 0, romMax: 0, instructions: [], cautions: [] },
    { kind: 'custom', exId: '', name: 'Stezanje kvadricepsa', reason: 'Aktivira mišić iznad kolena bez pokreta u zglobu.', sets: 3, reps: 10, holdSec: 5, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Sedite na pod, noga ispružena, ispod kolena smotan peškir.', 'Pritisnite koleno nadole u peškir, zatežući prednji deo natkolenice.', 'Zadržite 5 sekundi, pa opustite.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Podizanje ispružene noge ležeći', reason: 'Jača kvadriceps bez opterećenja čašice.', sets: 3, reps: 10, holdSec: 2, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lezite na leđa, druga noga savijena.', 'Zategnite natkolenicu ispružene noge i podignite je do visine kolena druge noge.', 'Zadržite 2 sekunde i polako spustite.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Školjka', reason: 'Jača spoljne rotatore kuka, koji drže koleno u pravoj liniji.', sets: 3, reps: 12, holdSec: 0, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lezite na bok, kolena savijena, stopala zajedno.', 'Podignite gornje koleno, stopala ostaju spojena.', 'Polako spustite. Karlica se ne okreće unazad.'], cautions: [] },
  ],
  days: [1, 3, 5],
  frequencyNote: 'Tri puta nedeljno, uz kratku šetnju svakog dana.',
  avoid: ['Duboke čučnjeve', 'Skakanje i trčanje nizbrdo dok bol ne prođe', 'Dugo sedenje sa savijenim kolenima'],
  progression: 'Kada vežbe ne izazivaju bol, povećajte broj ponavljanja, pa dodajte elastičnu traku.',
  sources: [
    { title: 'Patellofemoral Pain – Clinical Practice Guidelines (JOSPT)', url: 'https://www.jospt.org/doi/10.2519/jospt.2019.0302' },
    { title: 'Patellofemoral Pain Syndrome – Physiopedia', url: 'https://www.physio-pedia.com/Patellofemoral_Pain_Syndrome' },
  ],
};

const KNEE_EN = {
  summary: {
    condition: 'Patellofemoral pain syndrome – pain at the front of the knee (“runner’s knee”)',
    region: 'Knee', side: 'both', irritability: 'moderate',
    keyFindings: ['Dull pain around or behind the kneecap', 'Worse with squatting, going down stairs and prolonged sitting', 'No swelling and no ligament injury'],
    romFindings: [],
    redFlags: ['Swelling, locking or the knee “giving way” – see a doctor'],
    goals: ['Going down stairs without pain', 'Return to running and sport'],
    phase: 'Early phase: pain-free hip and thigh strengthening',
  },
  items: [
    { kind: 'library', exId: 'hip-abduction', name: 'Standing side leg raise', reason: 'Strengthening gluteus medius reduces load on the kneecap.', sets: 3, reps: 12, holdSec: 0, side: 'both', romTarget: 0, romMax: 0, instructions: [], cautions: [] },
    { kind: 'library', exId: 'squat', name: 'Chair squat', reason: 'A shallow, pain-free squat strengthens the quadriceps.', sets: 3, reps: 10, holdSec: 0, side: 'both', romTarget: 60, romMax: 75, instructions: [], cautions: ['Only to the pain limit, knees stay behind the toes'] },
    { kind: 'library', exId: 'calf-raise', name: 'Calf raise', reason: 'Calf strength and stability for walking and running.', sets: 2, reps: 15, holdSec: 0, side: 'both', romTarget: 0, romMax: 0, instructions: [], cautions: [] },
    { kind: 'custom', exId: '', name: 'Quadriceps set', reason: 'Activates the muscle above the knee without moving the joint.', sets: 3, reps: 10, holdSec: 5, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Sit on the floor with your leg straight and a rolled towel under the knee.', 'Press the knee down into the towel, tightening the front of the thigh.', 'Hold for 5 seconds, then relax.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Straight leg raise', reason: 'Strengthens the quadriceps without loading the kneecap.', sets: 3, reps: 10, holdSec: 2, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lie on your back with the other knee bent.', 'Tighten the thigh of the straight leg and lift it to the height of the other knee.', 'Hold for 2 seconds and lower slowly.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Clamshell', reason: 'Strengthens the hip external rotators that keep the knee in line.', sets: 3, reps: 12, holdSec: 0, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lie on your side, knees bent, feet together.', 'Lift the top knee while keeping the feet together.', 'Lower slowly. Don’t let the pelvis roll back.'], cautions: [] },
  ],
  days: [1, 3, 5],
  frequencyNote: 'Three times a week, with a short walk every day.',
  avoid: ['Deep squats', 'Jumping and downhill running until the pain settles', 'Sitting for long periods with bent knees'],
  progression: 'When the exercises are pain-free, increase the reps, then add a resistance band.',
  sources: KNEE_SR.sources,
};

const BACK_SR = {
  summary: {
    condition: 'Nespecifični bol u donjem delu leđa (mehanički bol u krstima)',
    region: 'Donji deo leđa', side: 'both', irritability: 'moderate',
    keyFindings: ['Bol u krstima, bez širenja niz nogu', 'Pojačava se pri dugom sedenju i saginjanju', 'Olakšava ga kretanje i promena položaja'],
    romFindings: [],
    redFlags: ['Bol koji se širi niz nogu uz trnjenje ili slabost, problemi sa mokrenjem ili temperatura – hitno lekaru'],
    goals: ['Sedenje i rad bez bola', 'Povratak svakodnevnim aktivnostima'],
    phase: 'Subakutna faza: pokretljivost i jačanje trupa',
  },
  items: [
    { kind: 'library', exId: 'side-bend', name: 'Bočno savijanje trupa', reason: 'Vraća pokretljivost lumbalnog dela u bezbolnom opsegu.', sets: 2, reps: 8, holdSec: 0, side: 'both', romTarget: 15, romMax: 25, instructions: [], cautions: ['Samo do blage nelagodnosti'] },
    { kind: 'library', exId: 'knee-raise', name: 'Podizanje kolena u mestu', reason: 'Lagano kretanje smanjuje ukočenost i bol.', sets: 2, reps: 12, holdSec: 0, side: 'both', romTarget: 50, romMax: 0, instructions: [], cautions: [] },
    { kind: 'custom', exId: '', name: 'Nagib karlice ležeći', reason: 'Aktivira duboke trbušne mišiće i nežno pokreće krsta.', sets: 2, reps: 10, holdSec: 5, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lezite na leđa, kolena savijena, stopala na podu.', 'Utisnite donji deo leđa u podlogu zatežući stomak.', 'Zadržite 5 sekundi, opustite.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Mačka – kamila', reason: 'Pokretljivost cele kičme bez opterećenja.', sets: 2, reps: 10, holdSec: 0, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Oslonite se na šake i kolena.', 'Polako izvijte leđa nagore (mačka), pa ih spustite nadole (kamila).', 'Pokret je spor i bez bola.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Koleno ka grudima', reason: 'Nežno isteže mišiće donjeg dela leđa.', sets: 2, reps: 6, holdSec: 15, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lezite na leđa, kolena savijena.', 'Privucite jedno koleno rukama ka grudima.', 'Zadržite 15 sekundi, pa promenite nogu.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Ptica – pas', reason: 'Jača stabilizatore trupa i leđa.', sets: 2, reps: 8, holdSec: 3, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Oslonite se na šake i kolena, leđa prava.', 'Istovremeno ispružite suprotnu ruku i nogu.', 'Zadržite 3 sekunde, vratite se i promenite stranu.'], cautions: ['Leđa ne propadaju, karlica ostaje ravna'] },
    { kind: 'custom', exId: '', name: 'Most (podizanje karlice)', reason: 'Jača gluteuse, koji rasterećuju krsta.', sets: 2, reps: 10, holdSec: 3, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lezite na leđa, kolena savijena.', 'Podignite karlicu dok telo ne bude u liniji od ramena do kolena.', 'Zadržite 3 sekunde i polako spustite.'], cautions: [] },
  ],
  days: [1, 2, 3, 4, 5, 6, 7],
  frequencyNote: 'Svakodnevno, kratko. Ostanite aktivni i šetajte.',
  avoid: ['Dugo ležanje i mirovanje', 'Podizanje teških tereta savijenih leđa', 'Sedenje duže od 30 minuta bez pauze'],
  progression: 'Kada je bol manji, povećajte broj ponavljanja i dodajte duže šetnje.',
  sources: [
    { title: 'Low back pain and sciatica in over 16s – NICE NG59', url: 'https://www.nice.org.uk/guidance/ng59' },
    { title: 'Low Back Pain – Physiopedia', url: 'https://www.physio-pedia.com/Low_Back_Pain' },
  ],
};

const BACK_EN = {
  summary: {
    condition: 'Non-specific low back pain (mechanical lower back pain)',
    region: 'Lower back', side: 'both', irritability: 'moderate',
    keyFindings: ['Pain in the lower back, not spreading down the leg', 'Worse with prolonged sitting and bending', 'Eased by moving and changing position'],
    romFindings: [],
    redFlags: ['Pain spreading down the leg with tingling or weakness, bladder problems or fever – seek urgent care'],
    goals: ['Sitting and working without pain', 'Return to daily activities'],
    phase: 'Subacute phase: mobility and trunk strengthening',
  },
  items: [
    { kind: 'library', exId: 'side-bend', name: 'Trunk side bend', reason: 'Restores lumbar mobility within a pain-free range.', sets: 2, reps: 8, holdSec: 0, side: 'both', romTarget: 15, romMax: 25, instructions: [], cautions: ['Only to mild discomfort'] },
    { kind: 'library', exId: 'knee-raise', name: 'Standing knee raise', reason: 'Gentle movement reduces stiffness and pain.', sets: 2, reps: 12, holdSec: 0, side: 'both', romTarget: 50, romMax: 0, instructions: [], cautions: [] },
    { kind: 'custom', exId: '', name: 'Supine pelvic tilt', reason: 'Activates the deep abdominals and gently moves the lower back.', sets: 2, reps: 10, holdSec: 5, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lie on your back with knees bent and feet on the floor.', 'Press your lower back into the floor by tightening your stomach.', 'Hold for 5 seconds, relax.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Cat – camel', reason: 'Mobility of the whole spine without load.', sets: 2, reps: 10, holdSec: 0, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Get on your hands and knees.', 'Slowly round your back up (cat), then let it sink down (camel).', 'Move slowly and pain-free.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Knee to chest', reason: 'Gently stretches the lower back muscles.', sets: 2, reps: 6, holdSec: 15, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lie on your back with knees bent.', 'Pull one knee towards your chest with your hands.', 'Hold for 15 seconds, then switch legs.'], cautions: [] },
    { kind: 'custom', exId: '', name: 'Bird dog', reason: 'Strengthens the trunk and back stabilisers.', sets: 2, reps: 8, holdSec: 3, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Get on your hands and knees with a straight back.', 'Extend the opposite arm and leg at the same time.', 'Hold for 3 seconds, return and switch sides.'], cautions: ['Don’t let the back sag; keep the pelvis level'] },
    { kind: 'custom', exId: '', name: 'Glute bridge', reason: 'Strengthens the glutes, which take load off the lower back.', sets: 2, reps: 10, holdSec: 3, side: 'both', romTarget: 0, romMax: 0,
      instructions: ['Lie on your back with knees bent.', 'Lift your pelvis until your body is in line from shoulders to knees.', 'Hold for 3 seconds and lower slowly.'], cautions: [] },
  ],
  days: [1, 2, 3, 4, 5, 6, 7],
  frequencyNote: 'Daily, briefly. Stay active and keep walking.',
  avoid: ['Long periods of bed rest', 'Lifting heavy loads with a bent back', 'Sitting for more than 30 minutes without a break'],
  progression: 'As the pain eases, increase the reps and add longer walks.',
  sources: BACK_SR.sources,
};

// view: 'front' = telo spreda, 'back' = telo otpozadi; pain: tačka bola na ilustraciji (viewBox 200×400)
export const PRESETS = [
  { id: 'koleno', view: 'front', pain: { x: 82, y: 289, rx: 9, ry: 9 }, label: { sr: 'Bol ispred čašice', en: 'Pain at the kneecap' }, translations: { sr: KNEE_SR, en: KNEE_EN } },
  { id: 'ledja', view: 'back', pain: { x: 100, y: 186, rx: 24, ry: 11 }, label: { sr: 'Bol u krstima', en: 'Lower back pain' }, translations: { sr: BACK_SR, en: BACK_EN } },
];

export const presetById = (id) => PRESETS.find((p) => p.id === id);

// Isti oblik kao AI rezultat, da bi se dodavanje u programe ponašalo isto kao kod izveštaja
export function presetResult(p) {
  return { model: 'preset', presetId: p.id, searched: [], program: p.translations[getLang()] || p.translations.sr, translations: p.translations };
}

// Ilustracija tela sa tačkom bola
export function bodySvg(p, { small = false } = {}) {
  const lang = getLang();
  const { x, y, rx, ry } = p.pain;
  const right = true; // natpis je uvek desno od tela
  const lx = 166, ly = Math.max(24, y - 52);
  const spine = p.view === 'back'
    ? '<path d="M100 74 L100 196" class="b-spine"/><path d="M100 196 Q86 214 70 214 M100 196 Q114 214 130 214" class="b-spine"/>'
    : '';
  return `<svg class="body-svg ${small ? 'small' : ''}" viewBox="0 0 ${small ? 200 : 300} 400" role="img" aria-label="${p.label[lang] || p.label.sr}">
    <g class="b-fig">
      <circle cx="100" cy="38" r="22"/>
      <rect x="92" y="56" width="16" height="16" rx="4"/>
      <path d="M62 74 Q100 64 138 74 L134 150 Q131 176 136 198 L64 198 Q69 176 66 150 Z"/>
      <path d="M64 196 L136 196 L132 224 L68 224 Z"/>
      <path d="M61 82 L51 150 L46 212" class="b-limb arm"/>
      <path d="M139 82 L149 150 L154 212" class="b-limb arm"/>
      <path d="M84 216 L82 290 L80 372" class="b-limb leg"/>
      <path d="M116 216 L118 290 L120 372" class="b-limb leg"/>
      <ellipse cx="78" cy="382" rx="14" ry="7"/>
      <ellipse cx="122" cy="382" rx="14" ry="7"/>
    </g>
    ${spine}
    <ellipse class="pain-glow" cx="${x}" cy="${y}" rx="${rx * 2.4}" ry="${ry * 2.4}"/>
    <ellipse class="pain-dot" cx="${x}" cy="${y}" rx="${rx}" ry="${ry}"/>
    ${small ? '' : `<path class="pain-line" d="M${x + (right ? rx : -rx) * 0.7} ${y - ry * 0.7} L${lx - 4} ${ly + 8}"/>
    <g class="pain-label"><rect x="${lx - 6}" y="${ly - 10}" width="${(p.label[lang] || p.label.sr).length * 6.4 + 14}" height="24" rx="12"/>
    <text x="${lx + 1}" y="${ly + 6}">${p.label[lang] || p.label.sr}</text></g>`}
  </svg>`;
}

export const presetName = (p) => (p.translations[getLang()] || p.translations.sr).summary.condition;
export const presetShort = (p) => t('preset_' + p.id);
