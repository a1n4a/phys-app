// Podešavanja koja se razlikuju između web verzije i Android aplikacije.
// U web verziji server je ista adresa sa koje je stranica otvorena (prazno).
// Skripta za Android (fizio-android\build-apk.ps1) ovde upisuje podrazumevanu adresu servera.
export const DEFAULT_SERVER = '';
