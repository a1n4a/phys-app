// Podaci koji se čuvaju na uređaju: profil, treninzi, dnevnik (bol, pokretljivost, napredak), program.

const read = (k, def) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch { return def; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* skladište nije dostupno */ } };

// ── profil ──
// sex: 'm' | 'f'; age: 'child' (do 12 godina) | 'adult' (12 i više)
let profileCache;
export function getProfile() { if (profileCache === undefined) profileCache = read('fizio-profile', null); return profileCache; }
export function setProfile(p) { profileCache = p; write('fizio-profile', p); profileListeners.forEach((fn) => fn(p)); }
const profileListeners = new Set();
export const onProfileChange = (fn) => profileListeners.add(fn);
export const profileOrDefault = () => getProfile() || { sex: 'm', age: 'adult' };

// ── treninzi ──
// {id, exId, date, reps, good, partials, tol, romPeaks:[stepeni po ponavljanju], errors:{id:count}, log?}
export function getSessions() {
  const s = read('fizio-sessions', null);
  if (s) return s;
  // stari format (verzija 1) -> novi
  const old = read('fizio-history', []);
  return old.map((h) => ({ id: String(h.date), exId: h.id, date: h.date, reps: h.reps, good: h.good, partials: 0, romPeaks: [], errors: {} }));
}
export function addSession(s) {
  const all = getSessions(); all.unshift(s);
  write('fizio-sessions', all.slice(0, 300));
}
export function updateSession(id, patch) {
  const all = getSessions();
  const i = all.findIndex((s) => s.id === id);
  if (i >= 0) { all[i] = { ...all[i], ...patch }; write('fizio-sessions', all); }
}

// ── dnevnik ──
// {id, date, pain 0-10, mobility 1-5, progress 1-5, note, exId?}
export function getLogs() { return read('fizio-logs', []); }
export function addLog(l) { const all = getLogs(); all.unshift(l); write('fizio-logs', all.slice(0, 500)); }
// dopuna automatskog unosa terapije subjektivnom ocenom (samo jednom, posle toga je zaključan)
export function updateLog(id, patch) {
  const all = getLogs();
  const i = all.findIndex((l) => l.id === id);
  if (i < 0) return null;
  all[i] = { ...all[i], ...patch };
  write('fizio-logs', all);
  return all[i];
}

// ── moji programi (lokalni: gotovi, iz izveštaja, AI) ──
// [{id, color 0-5, title?, presetId?, items:[{exId|custom, sets, reps, ...}], days, note, aiSummary..., createdAt}]
export const PLAN_COLORS = 6;
export function getLocalPlans() {
  let list = read('fizio-local-plans', null);
  if (list) return list;
  // prelazak sa starih verzija: jedan AI program + lista vežbi iz izveštaja
  list = [];
  const old = read('fizio-local-plan', null);
  if (old && old.items) list.push({ ...old, id: 'p' + (old.createdAt || Date.now()), color: 0 });
  const prog = read('fizio-program', []);
  if (prog.length) {
    list.push({ id: 'p' + (Date.now() + 1), color: list.length, title: prog[0].reason || null, days: [], status: 'active', createdAt: Date.now(),
      items: prog.map((p) => ({ exId: p.exId, sets: 1, reps: p.reps || null })) });
  }
  write('fizio-local-plans', list);
  for (const k of ['fizio-local-plan', 'fizio-program']) { try { localStorage.removeItem(k); } catch { /* */ } }
  return list;
}
export function getLocalPlan(id) { return getLocalPlans().find((p) => p.id === id) || null; }
export function addLocalPlan(p) {
  const list = getLocalPlans();
  // svaki program svoja pastelna boja: prva slobodna, pa redom
  const used = list.map((x) => x.color);
  let color = 0;
  while (used.includes(color) && color < PLAN_COLORS) color++;
  if (color >= PLAN_COLORS) color = list.length % PLAN_COLORS;
  const plan = { ...p, id: 'p' + Date.now(), color, createdAt: Date.now() };
  list.push(plan);
  write('fizio-local-plans', list);
  return plan;
}
export function removeLocalPlan(id) { write('fizio-local-plans', getLocalPlans().filter((p) => p.id !== id)); }

// ── HomeAdapt: uslovi kod kuće ──
export function getHome() { return read('fizio-home', null); }
export function setHome(h) { write('fizio-home', h); }

// ── početak praćenja i spremnost izveštaja ──
export const REPORT_DAYS = 3;
const DAY = 86400000;
export function trackingStart() {
  const dates = [...getSessions().map((s) => s.date), ...getLogs().map((l) => l.date)];
  return dates.length ? Math.min(...dates) : null;
}
export function reportStatus(now = Date.now()) { return reportStatusFrom(trackingStart(), now); }
// isto, od zadatog početka (izveštaj jednog programa)
export function reportStatusFrom(start, now = Date.now()) {
  if (!start) return { ready: false, daysLeft: REPORT_DAYS, start: null };
  const days = Math.floor((startOfDay(now) - startOfDay(start)) / DAY);
  return { ready: days >= REPORT_DAYS, daysLeft: Math.max(0, REPORT_DAYS - days), start };
}
export function startOfDay(t) { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); }
export function clearAll() {
  for (const k of ['fizio-sessions', 'fizio-logs', 'fizio-program', 'fizio-history', 'fizio-local-plans', 'fizio-local-plan']) { try { localStorage.removeItem(k); } catch { /* */ } }
}
