// Izveštaj za fizioterapeuta: bol, pokretljivost, subjektivni napredak, treninzi i opseg pokreta.
import { getSessions, getLogs, getProfile, startOfDay } from './store.js';
import { byId } from './exercises.js';
import { t, exText, errText, locale } from './i18n.js';

const DAY = 86400000;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const avg = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : null);
const r1 = (v) => (v == null ? '–' : (Math.round(v * 10) / 10).toLocaleString(locale()));
const dayLabel = (ts) => new Date(ts).toLocaleDateString(locale(), { day: 'numeric', month: 'numeric' });

// naziv vežbe i za vežbe bez kamere (one nisu u biblioteci, naziv je sačuvan uz sesiju)
const exLabel = (e) => { const ex = byId(e.exId); return ex ? exText(ex, 'name') : (e.sessions[0] && e.sessions[0].name) || e.exId; };

// scope (izveštaj jednog programa): { title, logs: fn(log) -> bool, sessions: fn(sesija) -> bool }
export function collect(days, now = Date.now(), scope = null) {
  const end = startOfDay(now) + DAY;
  const start = end - days * DAY;
  const sessions = getSessions().filter((s) => s.date >= start && s.date < end && (!scope || scope.sessions(s))).sort((a, b) => a.date - b.date);
  const logs = getLogs().filter((l) => l.date >= start && l.date < end && (!scope || scope.logs(l))).sort((a, b) => a.date - b.date);
  const dayTs = Array.from({ length: days }, (_, i) => start + i * DAY);
  const inDay = (arr, d) => arr.filter((x) => x.date >= d && x.date < d + DAY);
  const daily = dayTs.map((d) => {
    const L = inDay(logs, d);
    return {
      d,
      pain: avg(L.map((l) => l.pain).filter((v) => v != null)),
      mobility: avg(L.map((l) => l.mobility).filter((v) => v != null)),
      progress: avg(L.map((l) => l.progress).filter((v) => v != null)),
      sessions: inDay(sessions, d).length,
      quality: avg(inDay(sessions, d).map((s) => s.quality).filter((v) => typeof v === 'number')),
    };
  });

  const byEx = new Map();
  for (const s of sessions) {
    const e = byEx.get(s.exId) || { exId: s.exId, sessions: [], reps: 0, good: 0, errors: {} };
    e.sessions.push(s); e.reps += s.reps || 0; e.good += s.good || 0;
    for (const [id, n] of Object.entries(s.errors || {})) e.errors[id] = (e.errors[id] || 0) + n;
    byEx.set(s.exId, e);
  }
  const exercises = [...byEx.values()].map((e) => {
    const roms = e.sessions.map((s) => avg(s.romPeaks || [])).filter((v) => v != null);
    const qs = e.sessions.map((s) => s.quality).filter((v) => typeof v === 'number');
    return { ...e, roms, romFirst: roms[0] ?? null, romLast: roms.length ? roms[roms.length - 1] : null,
      qs, qFirst: qs[0] ?? null, qLast: qs.length ? qs[qs.length - 1] : null };
  });

  const painVals = logs.map((l) => l.pain).filter((v) => v != null);
  const mobVals = logs.map((l) => l.mobility).filter((v) => v != null);
  return {
    start, end, days, daily, sessions, logs, exercises, title: scope ? scope.title : null,
    totals: {
      sessions: sessions.length,
      activeDays: daily.filter((d) => d.sessions > 0).length,
      reps: sessions.reduce((s, x) => s + (x.reps || 0), 0),
      good: sessions.reduce((s, x) => s + (x.good || 0), 0),
      painFirst: painVals[0] ?? null, painLast: painVals.length ? painVals[painVals.length - 1] : null,
      mobFirst: mobVals[0] ?? null, mobLast: mobVals.length ? mobVals[mobVals.length - 1] : null,
      progressLast: logs.length ? logs[logs.length - 1].progress : null,
    },
  };
}

// ── grafikon (SVG): jedna skala, tanke linije, tačke sa opisom pri prelasku mišem ──
export function lineChart({ series, labels, yMin, yMax, yTicks, aria }) {
  const W = 600, H = 210, L = 34, R = 92, T = 12, B = 30;
  const n = labels.length;
  const x = (i) => L + (n === 1 ? (W - L - R) / 2 : (i * (W - L - R)) / (n - 1));
  const y = (v) => T + (1 - (v - yMin) / (yMax - yMin)) * (H - T - B);
  let s = `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(aria)}">`;
  for (const v of yTicks) s += `<line class="ch-grid" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text class="ch-axis" x="${L - 8}" y="${y(v) + 4}" text-anchor="end">${v}</text>`;
  const step = Math.ceil(n / 8);
  labels.forEach((lb, i) => { if (i % step === 0 || i === n - 1) s += `<text class="ch-axis" x="${x(i)}" y="${H - 8}" text-anchor="middle">${esc(lb)}</text>`; });
  // oznake na kraju linija: razmakni ih ako se preklapaju
  const ends = [];
  for (const se of series) {
    let li = -1; se.values.forEach((v, i) => { if (v != null) li = i; });
    if (li >= 0) ends.push({ se, i: li, y: y(se.values[li]) });
  }
  ends.sort((a, b) => a.y - b.y);
  for (let k = 1; k < ends.length; k++) if (ends[k].y - ends[k - 1].y < 16) ends[k].y = ends[k - 1].y + 16;
  for (const se of series) {
    let d = '', pen = false;
    se.values.forEach((v, i) => { if (v == null) { pen = false; return; } d += `${pen ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`; pen = true; });
    if (d) s += `<path d="${d}" style="fill:none;stroke:${se.color};stroke-width:2;stroke-linejoin:round;stroke-linecap:round"/>`;
    se.values.forEach((v, i) => {
      if (v == null) return;
      s += `<circle cx="${x(i)}" cy="${y(v)}" r="4.5" style="fill:${se.color};stroke:var(--surface);stroke-width:2"><title>${esc(se.name)}, ${esc(labels[i])}: ${r1(v)}</title></circle>`;
    });
  }
  for (const e of ends) s += `<text class="ch-label" x="${x(e.i) + 10}" y="${e.y + 4}">${esc(e.se.name)} ${r1(e.se.values[e.i])}</text>`;
  return s + '</svg>';
}

function spark(values) {
  const v = values.filter((x) => x != null);
  if (v.length < 2) return '';
  const W = 90, H = 26, mn = Math.min(...v), mx = Math.max(...v), rng = mx - mn || 1;
  const pts = v.map((val, i) => `${(i * (W - 6)) / (v.length - 1) + 3},${H - 3 - ((val - mn) / rng) * (H - 6)}`).join(' ');
  const last = pts.split(' ').pop().split(',');
  return `<svg class="spark" viewBox="0 0 ${W} ${H}" aria-hidden="true"><polyline points="${pts}" style="fill:none;stroke:var(--c1);stroke-width:2;stroke-linejoin:round"/><circle cx="${last[0]}" cy="${last[1]}" r="3" style="fill:var(--c1)"/></svg>`;
}

function trendText(first, last, lowerIsBetter, unit = '') {
  if (first == null || last == null) return '';
  const d = last - first;
  if (Math.abs(d) < 0.05) return t('rpSame');
  const better = lowerIsBetter ? d < 0 : d > 0;
  return `<span class="${better ? 'up' : 'down'}">${d > 0 ? '+' : '−'}${r1(Math.abs(d))}${unit}</span>`;
}

export function renderReport(data) {
  const p = getProfile();
  const T = data.totals;
  const labels = data.daily.map((d) => dayLabel(d.d));
  const profile = p ? `${p.sex === 'f' ? t('female') : t('male')}, ${p.age === 'child' ? t('child') : t('adult')}` : '–';
  const acc = T.reps ? Math.round((T.good / T.reps) * 100) + '%' : '–';

  // kratki zaključci
  const notes = [];
  if (T.painFirst != null && T.painLast != null && data.logs.length > 1) notes.push(t('rpPainChange', { a: r1(T.painFirst), b: r1(T.painLast) }));
  for (const e of data.exercises) {
    const ex = byId(e.exId);
    if (ex && e.romFirst != null && e.romLast != null && e.roms.length > 1) {
      const d = Math.round(e.romLast - e.romFirst);
      notes.push(t(d >= 0 ? 'rpRomUp' : 'rpRomDown', { ex: exText(ex, 'name'), d: Math.abs(d) }));
    }
  }
  if (!data.sessions.length) notes.push(t('rpNoSessions'));

  let html = `
  <header class="rp-head">
    <div><p class="eyebrow">${t('rpEyebrow')}</p><h1>${t('rpTitle')}</h1>${data.title ? `<p class="rp-scope">${esc(data.title)}</p>` : ''}</div>
    <dl class="rp-meta">
      <div><dt>${t('rpPatient')}</dt><dd>${esc(profile)}</dd></div>
      <div><dt>${t('rpPeriod')}</dt><dd>${dayLabel(data.start)} – ${dayLabel(data.end - DAY)} (${data.days} ${t('rpDays')})</dd></div>
      <div><dt>${t('rpCreated')}</dt><dd>${new Date().toLocaleString(locale(), { dateStyle: 'medium', timeStyle: 'short' })}</dd></div>
    </dl>
  </header>

  <section class="rp-stats">
    <div><span>${T.sessions}</span><small>${t('rpSessions')}</small></div>
    <div><span>${T.activeDays}/${data.days}</span><small>${t('rpActiveDays')}</small></div>
    <div><span>${T.reps}</span><small>${t('rpReps')}</small></div>
    <div><span>${acc}</span><small>${t('rpAccuracy')}</small></div>
    <div><span>${r1(T.painLast)}</span><small>${t('rpPainNow')} ${trendText(T.painFirst, T.painLast, true)}</small></div>
  </section>`;

  if (notes.length) html += `<section><h2 class="label">${t('rpSummary')}</h2><ul class="rp-notes">${notes.map((n) => `<li>${n}</li>`).join('')}</ul></section>`;

  // objektivno: kvalitet izvođenja iz kamere (posebno od subjektivnih ocena ispod)
  if (data.daily.some((d) => d.quality != null)) {
    html += `<section><h2 class="label">${t('rpQualityChart')}</h2>
      ${lineChart({ series: [{ name: t('cmpQualityShort'), color: 'var(--c1)', values: data.daily.map((d) => (d.quality == null ? null : Math.round(d.quality))) }], labels, yMin: 0, yMax: 100, yTicks: [0, 50, 100], aria: t('rpQualityChart') })}
      <p class="muted small">${t('cmpHow')}</p></section>`;
  }

  html += `<section><h2 class="label">${t('rpPainChart')}</h2>
    ${data.logs.length ? lineChart({ series: [{ name: t('painShort'), color: 'var(--c-pain)', values: data.daily.map((d) => d.pain) }], labels, yMin: 0, yMax: 10, yTicks: [0, 5, 10], aria: t('rpPainChart') }) : `<p class="muted">${t('rpNoLogs')}</p>`}
  </section>
  <section><h2 class="label">${t('rpMobChart')}</h2>
    ${data.logs.length ? `<div class="legend"><span><i style="background:var(--c1)"></i>${t('mobilityShort')}</span><span><i style="background:var(--c2)"></i>${t('progressShort')}</span></div>` + lineChart({ series: [{ name: t('mobilityShort'), color: 'var(--c1)', values: data.daily.map((d) => d.mobility) }, { name: t('progressShort'), color: 'var(--c2)', values: data.daily.map((d) => d.progress) }], labels, yMin: 1, yMax: 5, yTicks: [1, 3, 5], aria: t('rpMobChart') }) + `<p class="muted small">${t('rpScaleNote')}</p>` : `<p class="muted">${t('rpNoLogs')}</p>`}
  </section>`;

  if (data.exercises.length) {
    html += `<section><h2 class="label">${t('rpExercises')}</h2><div class="table-wrap"><table class="rp-table">
      <thead><tr><th>${t('rpExercise')}</th><th>${t('rpSessions')}</th><th>${t('rpReps')}</th><th>${t('rpAccuracy')}</th><th>${t('rpRom')}</th><th>${t('rpQuality')}</th><th>${t('rpTopError')}</th></tr></thead><tbody>`;
    for (const e of data.exercises) {
      const ex = byId(e.exId);
      const topErr = ex ? Object.entries(e.errors).sort((a, b) => b[1] - a[1])[0] : null;
      html += `<tr><td>${esc(exLabel(e))}</td><td>${e.sessions.length}</td><td>${e.reps}</td>
        <td>${e.reps ? Math.round((e.good / e.reps) * 100) + '%' : '–'}</td>
        <td><div class="rom">${e.romFirst != null ? `${Math.round(e.romFirst)}° → ${Math.round(e.romLast)}° ${trendText(e.romFirst, e.romLast, false, '°')}` : '–'}${spark(e.roms)}</div></td>
        <td><div class="rom">${e.qFirst != null ? `${e.qFirst} → ${e.qLast} ${trendText(e.qFirst, e.qLast, false)}` : '–'}${spark(e.qs)}</div></td>
        <td>${topErr ? `${esc(errText(ex, { id: topErr[0], msg: topErr[0] }))} (${topErr[1]}×)` : '–'}</td></tr>`;
    }
    html += '</tbody></table></div></section>';
  }

  const withNotes = data.logs.filter((l) => l.note);
  if (withNotes.length) {
    html += `<section><h2 class="label">${t('rpPatientNotes')}</h2><ul class="rp-list">${withNotes.map((l) => `<li><time>${dayLabel(l.date)}</time> ${esc(l.note)}</li>`).join('')}</ul></section>`;
  }

  if (data.logs.length) {
    html += `<section><h2 class="label">${t('rpLogTable')}</h2><div class="table-wrap"><table class="rp-table">
      <thead><tr><th>${t('rpDate')}</th><th>${t('painShort')}</th><th>${t('mobilityShort')}</th><th>${t('progressShort')}</th></tr></thead><tbody>
      ${data.logs.map((l) => `<tr><td>${new Date(l.date).toLocaleString(locale(), { dateStyle: 'short', timeStyle: 'short' })}</td><td>${l.pain ?? '–'}</td><td>${l.mobility ?? '–'}</td><td>${l.progress ?? '–'}</td></tr>`).join('')}
      </tbody></table></div></section>`;
  }
  html += `<p class="muted small">${t('rpDisclaimer')}</p>`;
  return html;
}

export function reportCsv(data) {
  const rows = [['type', 'date', 'exercise', 'reps', 'good', 'avg_rom_deg', 'pain_0_10', 'mobility_1_5', 'progress_1_5', 'note']];
  for (const s of data.sessions) {
    const ex = byId(s.exId);
    const rom = avg(s.romPeaks || []);
    rows.push(['session', new Date(s.date).toISOString(), ex ? exText(ex, 'name') : s.name || s.exId, s.reps, s.good, rom == null ? '' : Math.round(rom), '', '', '', '']);
  }
  for (const l of data.logs) rows.push(['log', new Date(l.date).toISOString(), '', '', '', '', l.pain ?? '', l.mobility ?? '', l.progress ?? '', l.note || '']);
  return rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
}

export function reportText(data) {
  const T = data.totals;
  const lines = [
    t('rpTitle') + (data.title ? `: ${data.title}` : '') + ` (${dayLabel(data.start)} – ${dayLabel(data.end - DAY)})`,
    `${t('rpSessions')}: ${T.sessions}, ${t('rpReps')}: ${T.reps}, ${t('rpAccuracy')}: ${T.reps ? Math.round((T.good / T.reps) * 100) + '%' : '–'}`,
    `${t('painShort')}: ${r1(T.painFirst)} → ${r1(T.painLast)}`,
    `${t('mobilityShort')}: ${r1(T.mobFirst)} → ${r1(T.mobLast)}`,
  ];
  for (const e of data.exercises) {
    lines.push(`• ${exLabel(e)}: ${e.reps} ${t('rpReps')}${e.romFirst != null ? `, ${Math.round(e.romFirst)}° → ${Math.round(e.romLast)}°` : ''}`);
  }
  return lines.join('\n');
}
