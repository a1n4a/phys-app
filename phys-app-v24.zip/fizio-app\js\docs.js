// Čitanje izveštaja iz fajla: PDF, Word (.docx), tekst ili slika.
// Tekst se izvlači na uređaju; skenirani PDF i slike AI čita direktno.

// biblioteke su u folderu vendor/ (pdf.js 3.11.174, mammoth 1.6.0), da bi pdf.js worker bio sa iste adrese
const PDFJS = 'vendor/pdf.min.js';
const PDFJS_WORKER = 'vendor/pdf.worker.min.js';
const MAMMOTH = 'vendor/mammoth.browser.min.js';
export const MAX_BYTES = 10 * 1024 * 1024;

// accept za izbor fajla: slike, PDF, Word, tekst
export const ACCEPT = 'image/*,application/pdf,.pdf,.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.txt,.md,text/plain';

const loaded = {};
function loadScript(src) {
  if (!loaded[src]) loaded[src] = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.onload = res; s.onerror = () => { delete loaded[src]; rej(new Error('load')); };
    document.head.appendChild(s);
  });
  return loaded[src];
}

export function kindOf(file) {
  const n = (file.name || '').toLowerCase();
  if (file.type.startsWith('image/')) return 'image';
  if (file.type === 'application/pdf' || n.endsWith('.pdf')) return 'pdf';
  if (n.endsWith('.docx') || file.type.includes('wordprocessingml')) return 'docx';
  if (file.type.startsWith('text/') || n.endsWith('.txt') || n.endsWith('.md')) return 'text';
  if (n.endsWith('.doc')) return 'doc';
  return 'other';
}

async function pdfText(file) {
  await loadScript(PDFJS);
  const lib = window.pdfjsLib;
  lib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
  const pdf = await lib.getDocument({ data: await file.arrayBuffer() }).promise;
  const pages = [];
  for (let i = 1; i <= Math.min(pdf.numPages, 30); i++) {
    const page = await pdf.getPage(i);
    const tc = await page.getTextContent();
    // redovi: novi red kada se promeni vertikalna pozicija
    let line = '', lastY = null; const lines = [];
    for (const it of tc.items) {
      const y = Math.round(it.transform[5]);
      if (lastY !== null && Math.abs(y - lastY) > 3) { lines.push(line.trim()); line = ''; }
      line += it.str + (it.hasEOL ? '\n' : ' ');
      lastY = y;
    }
    lines.push(line.trim());
    pages.push(lines.filter(Boolean).join('\n'));
  }
  return pages.join('\n\n');
}

async function docxText(file) {
  await loadScript(MAMMOTH);
  const r = await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
  return r.value || '';
}

// Vraća {kind, text, scanned}: scanned = PDF bez teksta (slika u PDF-u) -> AI ga čita direktno
export async function readReport(file) {
  if (file.size > MAX_BYTES) throw Object.assign(new Error('too_big'), { code: 'too_big' });
  const kind = kindOf(file);
  if (kind === 'image') return { kind, text: '', scanned: true };
  if (kind === 'pdf') {
    let text = '';
    try { text = await pdfText(file); } catch { text = ''; }
    return { kind, text: text.trim(), scanned: text.trim().length < 40 };
  }
  if (kind === 'docx') return { kind, text: (await docxText(file)).trim(), scanned: false };
  if (kind === 'text') return { kind, text: (await file.text()).trim(), scanned: false };
  throw Object.assign(new Error('unsupported'), { code: kind === 'doc' ? 'doc' : 'unsupported' });
}

// Za AI: slika i PDF se šalju kao fajl (AI vidi i raspored, tabele, rukopis); Word i tekst idu kao tekst
export const sendsFile = (file) => file && ['image', 'pdf'].includes(kindOf(file));
