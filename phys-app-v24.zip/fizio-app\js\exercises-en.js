// English texts for the exercises in exercises.js (keyed by exercise id).

export const REGIONS_EN = {
  vrat: 'Neck',
  ramena: 'Shoulders',
  ruke: 'Arms and elbows',
  trup: 'Back and trunk',
  kukovi: 'Hips',
  kolena: 'Knees and thighs',
  stopala: 'Ankle and calf',
};

// Srpski tekstovi grešaka po oznaci (za izveštaje, gde se čuva samo oznaka greške)
export const ERRORS_SR = {
  'lateral-raise': { elbow: 'Ispravite laktove', high: 'Ne podižite ruke iznad visine ramena', asym: 'Podižite obe ruke ravnomerno', lean: 'Ne naginjite trup, stojte uspravno' },
  'overhead-raise': { elbow: 'Držite laktove ispružene', asym: 'Podižite obe ruke ravnomerno', lean: 'Ne naginjite trup u stranu, pokret je samo u ramenima' },
  'elbow-curl': { 'elbows-out': 'Držite laktove uz telo', swing: 'Ne zamahujte trupom', asym: 'Savijajte obe ruke istovremeno' },
  'neck-tilt': { shoulder: 'Ramena ostaju spuštena i ravna', rotate: 'Ne okrećite glavu, gledajte pravo', lean: 'Naginje se samo glava, telo miruje' },
  'side-bend': { hips: 'Kukovi ostaju u mestu, savijajte se u struku', rotate: 'Ne okrećite trup, savijajte se pravo u stranu', knees: 'Kolena ostaju ispružena', far: 'Ne savijajte se preko granice bola' },
  'hip-abduction': { lean: 'Ne naginjite trup u stranu, stojte uspravno', knee: 'Ispravite koleno noge koju podižete', high: 'Ne podižite nogu previsoko', hike: 'Karlica ostaje ravna, ne podižite kuk' },
  'knee-raise': { lean: 'Držite trup uspravno', support: 'Noga na kojoj stojite treba da bude ispružena' },
  squat: { lean: 'Podignite grudi, ne naginjite se previše napred', knee: 'Gurnite kukove unazad, kolena ne idu daleko ispred prstiju', deep: 'Ne spuštajte se preduboko', heel: 'Pete ostaju na podu' },
  'calf-raise': { knee: 'Držite kolena ispružena', lean: 'Ne naginjite se napred, telo je pravo' },
};
export const COMMON_ERRORS_SR = {
  shrug: 'Spustite ramena, ne podižite ih ka ušima',
  romMax: 'Prelazak opsega koji je dozvolio terapeut',
  side: 'Pogrešna strana tela',
  partial: 'Nepotpun pokret',
};

export const COMMON_ERRORS_EN = {
  romMax: 'Going past the range allowed by the therapist',
  side: 'Wrong side of the body',
  partial: 'Incomplete movement',
  shrug: 'Lower your shoulders, don’t lift them toward your ears',
  lean: 'Don’t lean your trunk, stand up straight',
};

export const EN = {
  'lateral-raise': {
    name: 'Lateral arm raise',
    summary: 'Shoulder abduction to shoulder height. Strengthens the deltoid and the shoulder blade stabilisers.',
    steps: [
      'Stand tall, feet hip-width apart, arms relaxed by your sides.',
      'Keeping your elbows straight, raise both arms out to the side up to shoulder height.',
      'Hold briefly, then slowly lower your arms.',
    ],
    mistakes: ['bent elbows', 'raising above shoulder height', 'uneven arms', 'leaning the trunk', 'shrugging the shoulders'],
    placement: 'Face the camera, 2 to 3 metres away, so your whole body and outstretched arms are visible.',
    cue: 'Raise your arms out to shoulder height',
    tooLow: 'Raise your arms higher, up to shoulder height',
    errors: {
      elbow: 'Straighten your elbows',
      high: 'Don’t raise your arms above shoulder height',
      asym: 'Raise both arms evenly',
      lean: 'Don’t lean your trunk, stand up straight',
    },
  },
  'overhead-raise': {
    name: 'Overhead arm raise',
    summary: 'Full shoulder abduction. Restores shoulder mobility after injury or immobilisation.',
    steps: [
      'Stand tall, arms by your sides, palms facing forward.',
      'Keeping your elbows straight, raise your arms out to the side and as high above your head as you can.',
      'Slowly lower your arms the same way.',
    ],
    mistakes: ['bent elbows', 'uneven arms', 'bending the trunk sideways instead of moving the shoulders'],
    placement: 'Face the camera, 2 to 3 metres away. The camera must also see your hands above your head.',
    cue: 'Raise your arms out to the side and overhead',
    tooLow: 'Raise your arms higher, above your head',
    errors: {
      elbow: 'Keep your elbows straight',
      asym: 'Raise both arms evenly',
      lean: 'Don’t lean sideways, move only at the shoulders',
    },
  },
  'elbow-curl': {
    name: 'Elbow curl',
    summary: 'Elbow flexion, with or without a weight. Strengthens the biceps and restores elbow range of motion.',
    steps: [
      'Stand tall, upper arms against your body, palms facing forward.',
      'Bend your elbows and bring your hands up toward your shoulders.',
      'Slowly straighten your arms. Your upper arms stay still.',
    ],
    mistakes: ['elbows moving away from the body', 'swinging the trunk', 'bending one arm before the other'],
    placement: 'Face the camera, turned slightly (30 to 45 degrees), 2 to 3 metres away.',
    cue: 'Bend your elbows, hands toward your shoulders',
    tooLow: 'Bend your elbows more, hands up to your shoulders',
    errors: {
      'elbows-out': 'Keep your elbows against your body',
      swing: 'Don’t swing your trunk',
      asym: 'Bend both arms at the same time',
    },
  },
  'neck-tilt': {
    name: 'Neck side tilt',
    summary: 'Stretches the side neck muscles (trapezius, scalenes). Reduces neck stiffness.',
    steps: [
      'Stand or sit up straight, shoulders relaxed and down.',
      'Slowly tilt your head so your ear moves toward your shoulder. Keep looking straight ahead.',
      'Hold for 2 seconds, return to the middle and repeat on the other side.',
    ],
    mistakes: ['lifting the shoulder toward the ear', 'turning the head instead of tilting it', 'leaning the whole body'],
    placement: 'Face the camera. Only your head and shoulders need to be visible; you can sit.',
    cue: 'Tilt your head, ear toward your shoulder',
    tooLow: 'Tilt your head a little further',
    errors: {
      shoulder: 'Keep your shoulders down and level',
      rotate: 'Don’t turn your head, look straight ahead',
      lean: 'Only your head tilts, your body stays still',
    },
  },
  'side-bend': {
    name: 'Trunk side bend',
    summary: 'Lateral flexion of the spine. Stretches the quadratus lumborum and the oblique abdominal muscles.',
    steps: [
      'Stand tall, feet hip-width apart, arms by your sides.',
      'Bend your trunk to the side, sliding your hand down your thigh. Your hips stay in place.',
      'Hold for 1 second, come back up, then bend to the other side.',
    ],
    mistakes: ['shifting the hips sideways', 'rotating the trunk', 'bending the knees'],
    placement: 'Face the camera, 2 to 3 metres away, whole body in the frame.',
    cue: 'Bend your trunk to the side, hips stay still',
    tooLow: 'Bend a little further to the side',
    errors: {
      hips: 'Keep your hips in place, bend at the waist',
      rotate: 'Don’t twist your trunk, bend straight to the side',
      knees: 'Keep your knees straight',
      far: 'Don’t bend past the point of pain',
    },
  },
  'hip-abduction': {
    name: 'Standing side leg raise',
    summary: 'Standing hip abduction. Strengthens the gluteus medius, which is important for stable walking.',
    steps: [
      'Stand tall. Hold on to a chair if you need to.',
      'With a straight knee, lift one leg out to the side, toes pointing forward.',
      'Slowly lower the leg and repeat with the other leg.',
    ],
    mistakes: ['leaning the trunk to the opposite side', 'bending the knee', 'lifting the leg too high', 'hitching the hip'],
    placement: 'Face the camera, 2.5 to 3 metres away; your feet must be in the frame.',
    cue: 'Lift your leg to the side, trunk upright',
    tooLow: 'Lift your leg a little higher to the side',
    errors: {
      lean: 'Don’t lean your trunk sideways, stand up straight',
      knee: 'Straighten the knee of the lifted leg',
      high: 'Don’t lift your leg too high',
      hike: 'Keep your pelvis level, don’t hitch your hip',
    },
  },
  'knee-raise': {
    name: 'Standing knee raise',
    summary: 'Alternating hip flexion. Strengthens the hip flexors and trains balance.',
    steps: [
      'Stand tall, arms by your sides or on your hips.',
      'Raise one knee toward your chest, up to hip height if you can.',
      'Lower the leg and raise the other knee. Your trunk stays upright.',
    ],
    mistakes: ['leaning the trunk', 'bending the standing leg', 'not raising the knee high enough'],
    placement: 'Face the camera, 2.5 to 3 metres away, whole body in the frame.',
    cue: 'Raise your knee to hip height',
    tooLow: 'Raise your knee higher',
    errors: {
      lean: 'Keep your trunk upright',
      support: 'Keep your standing leg straight',
    },
  },
  squat: {
    name: 'Chair squat',
    summary: 'A controlled squat. Strengthens the quadriceps and glutes, the basis for standing up and climbing stairs.',
    steps: [
      'Stand sideways to the camera, feet hip-width apart, arms in front of you.',
      'Push your hips back and bend your knees as if sitting down on a chair.',
      'Lower until your thighs are nearly parallel to the floor, then stand up.',
    ],
    mistakes: ['leaning the trunk too far forward', 'knees travelling far past the toes', 'lifting the heels'],
    placement: 'Side-on to the camera (profile), 2.5 to 3 metres away, feet in the frame.',
    cue: 'Hips back, lower yourself as if onto a chair',
    tooLow: 'Go a little deeper',
    errors: {
      lean: 'Lift your chest, don’t lean too far forward',
      knee: 'Push your hips back, knees should not go far past your toes',
      deep: 'Don’t go too deep',
      heel: 'Keep your heels on the floor',
    },
  },
  'calf-raise': {
    name: 'Calf raise',
    summary: 'Plantar flexion of the foot. Strengthens the calf muscles and the Achilles tendon, and helps balance.',
    steps: [
      'Stand sideways to the camera, feet hip-width apart. You can hold on to a chair.',
      'Rise up onto your toes as high as you can, knees straight.',
      'Hold for 1 second and slowly lower your heels to the floor.',
    ],
    mistakes: ['bending the knees', 'leaning the body forward', 'not lifting the heels high enough'],
    placement: 'Side-on to the camera, about 2 metres away. Your feet must be clearly visible.',
    cue: 'Rise up onto your toes',
    tooLow: 'Lift your heels higher',
    errors: {
      knee: 'Keep your knees straight',
      lean: 'Don’t lean forward, keep your body straight',
    },
  },
};
