﻿# FizioKamera: lokalni server (statični fajlovi + mali API sa bazom), bez Python-a i Node-a.
# Pokretanje:  powershell -ExecutionPolicy Bypass -File start.ps1
# Podaci (nalozi terapeuta, pacijenti, planovi, sesije) čuvaju se u data\db.json.
param([int]$Port = 8080, [switch]$NoBrowser)

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataDir = Join-Path $root 'data'
New-Item -ItemType Directory -Force $dataDir | Out-Null
$dbFile = Join-Path $dataDir 'db.json'

$mime = @{
  '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.mjs' = 'text/javascript; charset=utf-8'
  '.css' = 'text/css; charset=utf-8'; '.json' = 'application/json; charset=utf-8'; '.svg' = 'image/svg+xml'
  '.png' = 'image/png'; '.jpg' = 'image/jpeg'; '.webp' = 'image/webp'; '.mp4' = 'video/mp4'; '.webm' = 'video/webm'
  '.md' = 'text/plain; charset=utf-8'
}

# ── baza ──
$docs = New-Object System.Collections.ArrayList
$tokens = @{}
if (Test-Path $dbFile) {
  $db = [IO.File]::ReadAllText($dbFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
  foreach ($d in @($db.docs)) { if ($d) { [void]$docs.Add($d) } }
  if ($db.tokens) { foreach ($p in $db.tokens.PSObject.Properties) { $tokens[$p.Name] = $p.Value } }
}
function Save-Db {
  $json = ConvertTo-Json -InputObject ([pscustomobject]@{ docs = @($docs); tokens = $tokens }) -Depth 30 -Compress
  [IO.File]::WriteAllText($dbFile, $json, (New-Object Text.UTF8Encoding $false))
}
function New-Id { ([guid]::NewGuid().ToString('N')).Substring(0, 12) }
function New-Token { ([guid]::NewGuid().ToString('N')) + ([guid]::NewGuid().ToString('N')) }
function Get-Hash([string]$salt, [string]$pw) {
  $sha = [Security.Cryptography.SHA256]::Create()
  $b = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes("$salt|$pw"))
  ($b | ForEach-Object { $_.ToString('x2') }) -join ''
}
function New-Code {
  $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  do { $c = -join (1..6 | ForEach-Object { $chars[(Get-Random -Maximum $chars.Length)] }) }
  while (@($docs | Where-Object { $_.coll -eq 'patient' -and $_.inviteCode -eq $c }).Count)
  $c
}
function Set-Prop($o, [string]$name, $value) { $o | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force }
function Public-Therapist($t) { [pscustomobject]@{ id = $t.id; coll = 'therapist'; therapistId = $t.id; name = $t.name; email = $t.email; rules = $t.rules } }
function Find-Doc([string]$id) { foreach ($d in $docs) { if ($d.id -eq $id) { return $d } }; $null }

# ── AI (Claude API) ──
# Ključ: promenljiva okruženja ANTHROPIC_API_KEY ili data\config.json (unosi ga terapeut u klinici).
$configFile = Join-Path $dataDir 'config.json'
$tplPath = Join-Path $root 'ai\program-template.json'
$aiJobs = @{}
function Get-Config { if (Test-Path $configFile) { [IO.File]::ReadAllText($configFile, [Text.Encoding]::UTF8) | ConvertFrom-Json } else { [pscustomobject]@{} } }
function Get-ApiKey {
  if ($env:ANTHROPIC_API_KEY) { return $env:ANTHROPIC_API_KEY }
  $c = Get-Config
  if ($c.anthropicApiKey) { return [string]$c.anthropicApiKey }
  return $null
}

# Pozadinski posao: šalje izveštaj Claude-u (sa pretragom interneta) i vraća program kao JSON
$aiScript = {
  param([string]$key, [string]$tplPath, [string]$lang, [string]$text, [string]$image, [string]$mediaType)
  $ErrorActionPreference = 'Stop'
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $tpl = [IO.File]::ReadAllText($tplPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
  $langName = if ($lang -eq 'en') { 'English' } else { 'Serbian (Latin script)' }
  $tpl.system = $tpl.system.Replace('{LANG}', $langName)
  $content = @()
  # slika -> image blok, PDF -> document blok (AI čita i skenirane PDF-ove)
  $isPdf = $mediaType -eq 'application/pdf'
  if ($image) { $content += [pscustomobject]@{ type = $(if ($isPdf) { 'document' } else { 'image' }); source = [pscustomobject]@{ type = 'base64'; media_type = $mediaType; data = $image } } }
  $intro = if ($image -and $isPdf) { 'The physiotherapy report is in the PDF above.' } elseif ($image) { 'The physiotherapy report is in the image above.' } else { 'Physiotherapy report:' }
  if ($image -and $text.Trim()) { $intro += ' Additional notes:' }
  $content += [pscustomobject]@{ type = 'text'; text = ($intro + "`n`n" + $text).Trim() }
  $messages = New-Object System.Collections.ArrayList
  [void]$messages.Add([pscustomobject]@{ role = 'user'; content = $content })
  $headers = @{ 'x-api-key' = $key; 'anthropic-version' = '2026-10-21'; 'anthropic-beta' = 'server-side-fallback-2026-07-01' }
  $sources = @{}
  for ($turn = 0; $turn -lt 6; $turn++) {
    $tpl | Add-Member -NotePropertyName messages -NotePropertyValue @($messages) -Force
    $body = ConvertTo-Json -InputObject $tpl -Depth 60 -Compress
    try {
      $r = Invoke-WebRequest -Uri 'https://api.anthropic.com/v1/messages' -Method Post -Headers $headers -ContentType 'application/json' `
        -Body ([Text.Encoding]::UTF8.GetBytes($body)) -UseBasicParsing -TimeoutSec 600
      $txt = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
    } catch {
      $msg = $_.Exception.Message
      if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $msg = "$msg $($_.ErrorDetails.Message)" }
      throw "api_error: $msg"
    }
    $m = $txt | ConvertFrom-Json
    foreach ($b in @($m.content)) {
      if ($b.type -eq 'web_search_tool_result' -and $b.content -is [array]) {
        foreach ($s in $b.content) { if ($s.url) { $sources[[string]$s.url] = [string]$s.title } }
      }
      if ($b.type -eq 'tool_use' -and $b.name -eq 'submit_program') {
        $searched = @($sources.GetEnumerator() | ForEach-Object { [pscustomobject]@{ title = $_.Value; url = $_.Key } })
        $program = $b.input
        # prevod programa na drugi jezik, da bi promena jezika u aplikaciji prevela i AI tekst
        $other = if ($lang -eq 'en') { 'sr' } else { 'en' }
        $otherName = if ($other -eq 'en') { 'English' } else { 'Serbian (Latin script)' }
        $translations = [ordered]@{}
        $translations[$lang] = $program
        try {
          $tr = [pscustomobject]@{
            model = $tpl.model; max_tokens = 16000; fallbacks = 'default'; output_config = [pscustomobject]@{ effort = 'low' }
            system = "You translate exercise-program JSON for the FizioKamera physiotherapy app. Translate every human-readable text value into $otherName, using correct clinical terminology. Keep all keys, numbers, enum values (kind, exId, side, irritability), URLs and source titles exactly as they are, and keep the items in the same order. Return the translation by calling submit_program once."
            tools = @($tpl.tools | Where-Object { $_.name -eq 'submit_program' })
            tool_choice = [pscustomobject]@{ type = 'auto' }
            messages = @([pscustomobject]@{ role = 'user'; content = (ConvertTo-Json -InputObject $program -Depth 60 -Compress) })
          }
          $r2 = Invoke-WebRequest -Uri 'https://api.anthropic.com/v1/messages' -Method Post -Headers $headers -ContentType 'application/json' `
            -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $tr -Depth 60 -Compress))) -UseBasicParsing -TimeoutSec 300
          $m2 = [Text.Encoding]::UTF8.GetString($r2.RawContentStream.ToArray()) | ConvertFrom-Json
          foreach ($b2 in @($m2.content)) { if ($b2.type -eq 'tool_use' -and $b2.name -eq 'submit_program') { $translations[$other] = $b2.input } }
        } catch { }
        return (ConvertTo-Json -InputObject ([pscustomobject]@{ program = $program; translations = [pscustomobject]$translations; searched = $searched; model = $m.model }) -Depth 60 -Compress)
      }
    }
    if ($m.stop_reason -eq 'refusal') { throw 'refusal' }
    [void]$messages.Add([pscustomobject]@{ role = 'assistant'; content = $m.content })
    if ($m.stop_reason -ne 'pause_turn') {
      [void]$messages.Add([pscustomobject]@{ role = 'user'; content = 'Please call submit_program now with the complete program.' })
    }
  }
  throw 'no_program'
}

# Stvarna adresa korisnika (preko Cloudflare tunela svi zahtevi stižu sa localhost-a)
function Client-Ip($req) {
  $h = $req.Headers['CF-Connecting-IP']
  if (-not $h) { $h = $req.Headers['X-Forwarded-For'] }
  if ($h) { return ($h -split ',')[0].Trim() }
  return [string]$req.RemoteEndPoint.Address
}

function Send-Raw($res, [string]$json, [int]$code = 200) {
  $res.StatusCode = $code
  $res.ContentType = 'application/json; charset=utf-8'
  $res.Headers.Add('Cache-Control', 'no-store')
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $res.ContentLength64 = $bytes.Length
  try { $res.OutputStream.Write($bytes, 0, $bytes.Length) } catch {}
}

function Send-Json($res, $obj, [int]$code = 200) {
  $res.StatusCode = $code
  $res.ContentType = 'application/json; charset=utf-8'
  $res.Headers.Add('Cache-Control', 'no-store')
  $bytes = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $obj -Depth 30 -Compress))
  $res.ContentLength64 = $bytes.Length
  try { $res.OutputStream.Write($bytes, 0, $bytes.Length) } catch {}
}
function Fail($res, [string]$err, [int]$code = 400) { Send-Json $res ([pscustomobject]@{ error = $err }) $code }

function Handle-Api($ctx, [string]$route) {
  $req = $ctx.Request; $res = $ctx.Response
  $body = $null
  if ($req.HasEntityBody) {
    $reader = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $txt = $reader.ReadToEnd(); $reader.Close()
    if ($txt) { try { $body = $txt | ConvertFrom-Json } catch { return Fail $res 'bad_json' } }
  }
  $auth = $null
  $h = $req.Headers['Authorization']
  if ($h -and $h.StartsWith('Bearer ')) { $auth = $tokens[$h.Substring(7)] }

  switch ($route) {
    'register' {
      $email = ([string]$body.email).Trim().ToLower()
      if (-not $email -or -not $body.password -or ([string]$body.password).Length -lt 6 -or -not $body.name) { return Fail $res 'missing_fields' }
      if (@($docs | Where-Object { $_.coll -eq 'therapist' -and $_.email -eq $email }).Count) { return Fail $res 'email_taken' 409 }
      $salt = New-Id
      $id = New-Id
      $t = [pscustomobject]@{ id = $id; coll = 'therapist'; therapistId = $id; name = ([string]$body.name).Trim(); email = $email
        salt = $salt; hash = (Get-Hash $salt $body.password); createdAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        rules = [pscustomobject]@{ painRise = 2; missedDays = 2; lowTracking = 0.6 } }
      [void]$docs.Add($t)
      $tok = New-Token; $tokens[$tok] = [pscustomobject]@{ role = 'therapist'; id = $t.id }
      Save-Db
      return Send-Json $res ([pscustomobject]@{ token = $tok; role = 'therapist'; me = (Public-Therapist $t) })
    }
    'login' {
      $email = ([string]$body.email).Trim().ToLower()
      $t = $docs | Where-Object { $_.coll -eq 'therapist' -and $_.email -eq $email } | Select-Object -First 1
      if (-not $t -or (Get-Hash $t.salt $body.password) -ne $t.hash) { return Fail $res 'bad_login' 401 }
      $tok = New-Token; $tokens[$tok] = [pscustomobject]@{ role = 'therapist'; id = $t.id }
      Save-Db
      return Send-Json $res ([pscustomobject]@{ token = $tok; role = 'therapist'; me = (Public-Therapist $t) })
    }
    'join' {
      $code = ([string]$body.code).Trim().ToUpper()
      $p = $docs | Where-Object { $_.coll -eq 'patient' -and $_.inviteCode -eq $code } | Select-Object -First 1
      if (-not $p) { return Fail $res 'bad_code' 404 }
      Set-Prop $p 'activated' $true
      Set-Prop $p 'activatedAt' ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
      $tok = New-Token; $tokens[$tok] = [pscustomobject]@{ role = 'patient'; id = $p.id }
      Save-Db
      return Send-Json $res ([pscustomobject]@{ token = $tok; role = 'patient'; me = $p })
    }
    'data' {
      if (-not $auth) { return Fail $res 'unauthorized' 401 }
      if ($auth.role -eq 'therapist') {
        $me = Find-Doc $auth.id
        if (-not $me) { return Fail $res 'unauthorized' 401 }
        $list = @($docs | Where-Object { $_.therapistId -eq $me.id -and $_.coll -ne 'therapist' })
        return Send-Json $res ([pscustomobject]@{ role = 'therapist'; me = (Public-Therapist $me); docs = $list })
      } else {
        $me = Find-Doc $auth.id
        if (-not $me) { return Fail $res 'unauthorized' 401 }
        $list = @($docs | Where-Object { $_.patientId -eq $me.id -and $_.coll -ne 'patient' })
        $t = Find-Doc $me.therapistId
        return Send-Json $res ([pscustomobject]@{ role = 'patient'; me = $me; therapistName = $(if ($t) { $t.name } else { '' }); docs = $list })
      }
    }
    'put' {
      if (-not $auth) { return Fail $res 'unauthorized' 401 }
      $coll = [string]$body.coll
      $doc = $body.doc
      if (-not $doc) { return Fail $res 'missing_doc' }
      $now = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
      $existing = if ($doc.id) { Find-Doc ([string]$doc.id) } else { $null }

      if ($auth.role -eq 'therapist') {
        if ($coll -notin @('patient', 'plan', 'proposal', 'therapist')) { return Fail $res 'forbidden' 403 }
        if ($existing -and $existing.therapistId -ne $auth.id) { return Fail $res 'forbidden' 403 }
        if ($coll -eq 'therapist') {
          if (-not $existing -or $existing.id -ne $auth.id) { return Fail $res 'forbidden' 403 }
          if ($doc.rules) { Set-Prop $existing 'rules' $doc.rules }
          if ($doc.name) { Set-Prop $existing 'name' ([string]$doc.name) }
          Save-Db
          return Send-Json $res (Public-Therapist $existing)
        }
        if ($coll -eq 'proposal' -and -not $existing) { return Fail $res 'forbidden' 403 }
        if ($coll -eq 'plan' -or ($coll -eq 'proposal')) {
          $p = Find-Doc ([string]$doc.patientId)
          if (-not $p -or $p.therapistId -ne $auth.id) { return Fail $res 'forbidden' 403 }
        }
        Set-Prop $doc 'therapistId' $auth.id
        if ($coll -eq 'patient') {
          Set-Prop $doc 'patientId' $(if ($existing) { $existing.id } else { '' })
          if (-not $existing) { Set-Prop $doc 'inviteCode' (New-Code); Set-Prop $doc 'activated' $false }
          else { Set-Prop $doc 'inviteCode' $existing.inviteCode; Set-Prop $doc 'activated' $existing.activated }
        }
      } else {
        if ($coll -notin @('session', 'log', 'report', 'proposal', 'home')) { return Fail $res 'forbidden' 403 }
        if ($existing -and $existing.patientId -ne $auth.id) { return Fail $res 'forbidden' 403 }
        if ($coll -eq 'proposal' -and $existing) { return Fail $res 'forbidden' 403 }
        $me = Find-Doc $auth.id
        Set-Prop $doc 'patientId' $me.id
        Set-Prop $doc 'therapistId' $me.therapistId
      }

      if (-not $doc.id) { Set-Prop $doc 'id' (New-Id) }
      Set-Prop $doc 'coll' $coll
      Set-Prop $doc 'updatedAt' $now
      if (-not $doc.createdAt) { Set-Prop $doc 'createdAt' $(if ($existing -and $existing.createdAt) { $existing.createdAt } else { $now }) }
      if ($coll -eq 'patient' -and -not $existing) { Set-Prop $doc 'patientId' $doc.id }
      if ($existing) { $i = $docs.IndexOf($existing); $docs[$i] = $doc } else { [void]$docs.Add($doc) }
      Save-Db
      return Send-Json $res $doc
    }
    'ai/status' {
      $has = [bool](Get-ApiKey)
      return Send-Json $res ([pscustomobject]@{ configured = $has; demo = (-not $has) })
    }
    'ai/key' {
      if (-not $auth -or $auth.role -ne 'therapist') { return Fail $res 'forbidden' 403 }
      $k = ([string]$body.key).Trim()
      if (-not $k.StartsWith('sk-ant-')) { return Fail $res 'bad_key' }
      $c = Get-Config
      Set-Prop $c 'anthropicApiKey' $k
      [IO.File]::WriteAllText($configFile, (ConvertTo-Json -InputObject $c -Compress), (New-Object Text.UTF8Encoding $false))
      return Send-Json $res ([pscustomobject]@{ configured = $true })
    }
    'ai/plan' {
      # bez naloga: najviše 5 AI analiza na sat po korisniku (IP), da se ne troši ključ klinike
      $owner = if ($auth) { $auth.id } else { 'anon:' + (Client-Ip $req) }
      if (-not $auth) {
        $hourAgo = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() - 3600000
        $recent = @($aiJobs.Values | Where-Object { $_.owner -eq $owner -and $_.started -gt $hourAgo }).Count
        if ($recent -ge 5) { return Fail $res 'rate_limited' 429 }
      }
      $key = Get-ApiKey
      $text = [string]$body.text; $image = [string]$body.image
      if (-not $text.Trim() -and -not $image) { return Fail $res 'missing_fields' }
      $mt = if ($body.mediaType) { [string]$body.mediaType } else { 'image/jpeg' }
      $lang = if ($body.lang -eq 'en') { 'en' } else { 'sr' }
      if (-not $key) {
        # DEMO REŽIM (nema API ključa): posle ~9 s vraća unapred pripremljen AI odgovor iz ai\demo\
        $topic = if ($text -match '(?i)lumb|low back|krst|leđ|ledj|kičm|kicm|sciat|išijas|isijas|ishijas|\bL[45]\b|spine') { 'back' } else { 'shoulder' }
        $jid = New-Id
        $aiJobs[$jid] = [pscustomobject]@{ demo = (Join-Path $root "ai\demo\$topic-$lang.json"); owner = $owner; started = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
        return Send-Json $res ([pscustomobject]@{ jobId = $jid; demo = $true })
      }
      $job = Start-Job -ScriptBlock $aiScript -ArgumentList $key, $tplPath, $lang, $text, $image, $mt
      $jid = New-Id
      $aiJobs[$jid] = [pscustomobject]@{ job = $job; owner = $owner; started = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
      return Send-Json $res ([pscustomobject]@{ jobId = $jid })
    }
    'ai/job' {
      $owner = if ($auth) { $auth.id } else { 'anon:' + (Client-Ip $req) }
      $entry = $aiJobs[[string]$req.QueryString['id']]
      if (-not $entry -or $entry.owner -ne $owner) { return Fail $res 'not_found' 404 }
      $elapsed = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() - $entry.started
      if ($entry.demo) {
        if ($elapsed -lt 9000) { return Send-Json $res ([pscustomobject]@{ status = 'running'; elapsed = $elapsed }) }
        # demo odgovor na oba jezika (srpska i engleska verzija iz ai\demo\)
        $base = $entry.demo -replace '-(sr|en)\.json$', ''
        $srJ = [IO.File]::ReadAllText("$base-sr.json", [Text.Encoding]::UTF8) | ConvertFrom-Json
        $enJ = [IO.File]::ReadAllText("$base-en.json", [Text.Encoding]::UTF8) | ConvertFrom-Json
        $main = if ($entry.demo -like '*-en.json') { $enJ } else { $srJ }
        $obj = [pscustomobject]@{ model = 'demo'; searched = $main.searched; program = $main.program; translations = [pscustomobject]@{ sr = $srJ.program; en = $enJ.program } }
        return Send-Json $res ([pscustomobject]@{ status = 'done'; result = $obj })
      }
      $state = [string]$entry.job.State
      if ($state -eq 'Running' -or $state -eq 'NotStarted') { return Send-Json $res ([pscustomobject]@{ status = 'running'; elapsed = $elapsed }) }
      if ($state -eq 'Completed') {
        $out = (@(Receive-Job $entry.job -Keep) | Where-Object { $_ -is [string] } | Select-Object -Last 1)
        if ($out) { return Send-Raw $res ('{"status":"done","result":' + $out + '}') }
        return Send-Json $res ([pscustomobject]@{ status = 'error'; error = 'empty' })
      }
      $reason = $entry.job.ChildJobs[0].JobStateInfo.Reason
      $msg = if ($reason) { $reason.Message } else { $state }
      Write-Host "AI greška: $msg"
      $code = if ($msg -like '*refusal*') { 'refusal' } elseif ($msg -like '*authentication*' -or $msg -like '*invalid x-api-key*') { 'bad_key' } elseif ($msg -like '*credit*' -or $msg -like '*billing*') { 'billing' } else { 'api_error' }
      return Send-Json $res ([pscustomobject]@{ status = 'error'; error = $code; detail = $msg.Substring(0, [Math]::Min(400, $msg.Length)) })
    }
    default { return Fail $res 'not_found' 404 }
  }
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Start()
Write-Host "FizioKamera radi na http://localhost:$Port/  (Ctrl+C za kraj)"
if (-not $NoBrowser) { Start-Process "http://localhost:$Port/" }

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    $res = $ctx.Response
    # Android aplikacija učitava stranice iz same sebe, pa API zove sa druge adrese (CORS)
    $res.Headers.Add('Access-Control-Allow-Origin', '*')
    $res.Headers.Add('Access-Control-Allow-Headers', 'Content-Type, Authorization')
    $res.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
    if ($ctx.Request.HttpMethod -eq 'OPTIONS') { $res.StatusCode = 204; try { $res.Close() } catch {}; continue }
    try {
      $path = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
      if ($path.StartsWith('api/')) {
        Handle-Api $ctx $path.Substring(4)
      } else {
        if ($path -eq '') { $path = 'index.html' }
        $file = [IO.Path]::GetFullPath((Join-Path $root $path))
        $blocked = $file.StartsWith($dataDir) -or $file.EndsWith('.ps1')
        if (-not $blocked -and $file.StartsWith($root) -and (Test-Path $file -PathType Leaf)) {
          $ext = [IO.Path]::GetExtension($file).ToLower()
          $res.ContentType = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' }
          $res.Headers.Add('Cache-Control', 'no-cache')
          $bytes = [IO.File]::ReadAllBytes($file)
          $res.ContentLength64 = $bytes.Length
          try { $res.OutputStream.Write($bytes, 0, $bytes.Length) } catch {}
        } else {
          $res.StatusCode = 404
        }
      }
    } catch {
      try { Fail $res 'server_error' 500 } catch {}
      Write-Host "Greška: $_"
    }
    try { $res.Close() } catch {}
  }
} finally {
  $listener.Stop()
}
