// Smart Alerts i Recovery Detective.
// Sve se izračunava iz stvarnih zapisa (sesije, dnevnik, prijave). Svaka tvrdnja nosi izvore
// (datume zapisa) i oznaku pouzdanosti. Ne donose se dijagnoze niti se menja terapija.

const DAY = 86400000;
const sod = (t) => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
const avg = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : null);
const weekday = (t) => new Date(t).getDay() || 7; // 1 = ponedeljak ... 7 = nedelja

export const DEFAULT_RULES = { painRise: 2, missedDays: 2, lowTracking: 0.6 };

// Zakazani dani bez ijedne sesije (poslednjih 7 dana, do juče)
export function adherence(plan, sessions, now = Date.now()) {
  if (!plan || !plan.days || !plan.days.length) return { scheduled: 0, done: 0, missedDates: [], doneDates: [] };
  const from = Math.max(sod(plan.createdAt || now), sod(now) - 7 * DAY);
  const res = { scheduled: 0, done: 0, missedDates: [], doneDates: [] };
  for (let d = from; d < sod(now); d += DAY) {
    if (!plan.days.includes(weekday(d))) continue;
    res.scheduled++;
    if (sessions.some((s) => s.date >= d && s.date < d + DAY)) { res.done++; res.doneDates.push(d); }
    else res.missedDates.push(d);
  }
  return res;
}

export function trackingOf(sessions) {
  const v = sessions.map((s) => s.tracking).filter((x) => typeof x === 'number');
  return v.length ? avg(v) : null;
}

// P = {patient, plan, sessions, logs, reports, proposals}
export function alertsFor(P, rules = DEFAULT_RULES, now = Date.now()) {
  const out = [];
  const r = { ...DEFAULT_RULES, ...(rules || {}) };
  if (!P.patient.activated) return { status: 'inactive', alerts: out };

  const logs = P.logs.filter((l) => l.pain != null);
  if (logs.length >= 2) {
    const a = logs[logs.length - 2], b = logs[logs.length - 1];
    if (b.pain - a.pain >= r.painRise) out.push({ level: 'review', key: 'alPainRise', vars: { a: a.pain, b: b.pain }, sources: [a.date, b.date] });
  }
  const lastLog = P.logs[P.logs.length - 1];
  if (lastLog && lastLog.progress != null && lastLog.progress <= 2) out.push({ level: 'review', key: 'alWorse', vars: {}, sources: [lastLog.date] });

  const recentReports = P.reports.filter((x) => x.date > now - 7 * DAY);
  for (const rep of recentReports) out.push({ level: 'review', key: 'alCannot', vars: { exId: rep.exId, reason: rep.reason }, sources: [rep.date] });

  const pending = P.proposals.filter((x) => x.status === 'pending');
  if (pending.length) out.push({ level: 'review', key: 'alProposal', vars: { n: pending.length }, sources: pending.map((x) => x.date || x.createdAt) });

  if (P.plan && P.plan.status !== 'paused') {
    const ad = adherence(P.plan, P.sessions, now);
    if (ad.missedDates.length >= r.missedDays) out.push({ level: 'reminder', key: 'alMissed', vars: { n: ad.missedDates.length }, sources: ad.missedDates });
  }

  const last3 = P.sessions.slice(-3);
  const tr = trackingOf(last3);
  if (tr != null && tr < r.lowTracking) out.push({ level: 'reminder', key: 'alTracking', vars: { p: Math.round(tr * 100) }, sources: last3.map((s) => s.date) });

  let status = 'ok';
  if (P.plan && P.plan.status === 'paused') status = 'paused';
  if (out.some((a) => a.level === 'reminder')) status = 'reminder';
  if (out.some((a) => a.level === 'review')) status = 'review';
  if (!P.plan) status = 'noplan';
  return { status, alerts: out };
}

// Kratak sažetak sa izvorima i pouzdanošću
export function detective(P, now = Date.now()) {
  const items = [];
  const week = P.sessions.filter((s) => s.date > now - 7 * DAY);

  if (P.plan && P.plan.days && P.plan.days.length) {
    const ad = adherence(P.plan, P.sessions, now);
    if (ad.scheduled) items.push({ key: 'dtAdherence', vars: { done: ad.done, total: ad.scheduled }, sources: [...ad.doneDates, ...ad.missedDates].sort(), confidence: 'high' });
  } else if (week.length) {
    items.push({ key: 'dtSessions', vars: { n: week.length }, sources: week.map((s) => s.date), confidence: 'high' });
  }

  const pl = P.logs.filter((l) => l.pain != null).slice(-4);
  if (pl.length >= 2) {
    const a = pl[0].pain, b = pl[pl.length - 1].pain;
    items.push({ key: b > a ? 'dtPainUp' : b < a ? 'dtPainDown' : 'dtPainSame', vars: { a, b, n: pl.length }, sources: pl.map((l) => l.date), confidence: pl.length >= 3 ? 'high' : 'medium' });
  } else if (pl.length === 1) {
    items.push({ key: 'dtPainOne', vars: { a: pl[0].pain }, sources: [pl[0].date], confidence: 'low' });
  }

  // opseg pokreta po vežbi (kamera, 2D procena)
  const byEx = {};
  for (const s of P.sessions) if (s.romPeaks && s.romPeaks.length) (byEx[s.exId] = byEx[s.exId] || []).push(s);
  for (const [exId, list] of Object.entries(byEx)) {
    if (list.length < 2) continue;
    const first = avg(list[0].romPeaks), last = avg(list[list.length - 1].romPeaks);
    const tr = trackingOf(list.slice(-3));
    items.push({ key: 'dtRom', vars: { exId, a: Math.round(first), b: Math.round(last) }, sources: [list[0].date, list[list.length - 1].date],
      confidence: tr != null && tr < 0.6 ? 'low' : 'medium' });
  }

  // kvalitet izvođenja po vežbi (prva -> poslednja izmerena sesija)
  const qByEx = {};
  for (const s of P.sessions) if (typeof s.quality === 'number') (qByEx[s.exId] = qByEx[s.exId] || []).push(s);
  for (const [exId, list] of Object.entries(qByEx)) {
    if (list.length < 2) continue;
    items.push({ key: 'dtQuality', vars: { exId, a: list[0].quality, b: list[list.length - 1].quality }, sources: [list[0].date, list[list.length - 1].date],
      confidence: list.length >= 3 ? 'medium' : 'low' });
  }

  // pouzdanost kamere po vežbi
  const trByEx = {};
  for (const s of P.sessions.slice(-10)) if (typeof s.tracking === 'number') (trByEx[s.exId] = trByEx[s.exId] || []).push(s);
  for (const [exId, list] of Object.entries(trByEx)) {
    const v = avg(list.map((s) => s.tracking));
    if (v < 0.6) items.push({ key: 'dtLowTracking', vars: { exId, p: Math.round(v * 100) }, sources: list.map((s) => s.date), confidence: 'high' });
  }

  const reps = P.reports.slice(-3);
  for (const r of reps) items.push({ key: 'dtCannot', vars: { exId: r.exId, reason: r.reason }, sources: [r.date], confidence: 'high' });

  // najčešća greška
  const errs = {};
  const errSrc = {};
  for (const s of P.sessions.slice(-10)) for (const [id, n] of Object.entries(s.errors || {})) {
    const k = s.exId + '|' + id; errs[k] = (errs[k] || 0) + n; (errSrc[k] = errSrc[k] || []).push(s.date);
  }
  const top = Object.entries(errs).sort((a, b) => b[1] - a[1])[0];
  if (top && top[1] >= 3) {
    const [exId, id] = top[0].split('|');
    items.push({ key: 'dtError', vars: { exId, errId: id, n: top[1] }, sources: errSrc[top[0]], confidence: 'medium' });
  }

  if (!items.length) items.push({ key: 'dtNoData', vars: {}, sources: [], confidence: 'high' });
  const needsReview = items.some((i) => ['dtPainUp', 'dtLowTracking', 'dtCannot'].includes(i.key));
  return { items, needsReview };
}
