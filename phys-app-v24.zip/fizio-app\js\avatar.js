// Animirani demonstrator vežbi (crta se u kodu, radi bez interneta).
// Ako u folderu videos/ postoji snimak za vežbu, aplikacija koristi snimak umesto ovoga.
//
// Obeležavanje: leva strana tela plava, desna ljubičasta (podlaktica/potkolenica svetlija nijansa),
// trup neutralan, zglobovi kao bele tačke, deo tela koji se pomera ima žuti oreol,
// a mišić koji se radi roze "kinezio traku".

import { profileOrDefault } from './store.js';

const BODIES = {
  adult: { headR: 0.062, neck: 0.035, torso: 0.29, shHalf: 0.105, hipHalf: 0.062, ua: 0.165, fa: 0.15, thigh: 0.235, shin: 0.225, foot: 0.09, scale: 1 },
  child: { headR: 0.08, neck: 0.03, torso: 0.25, shHalf: 0.09, hipHalf: 0.058, ua: 0.14, fa: 0.125, thigh: 0.2, shin: 0.19, foot: 0.075, scale: 0.86 },
};
function bodyFor(profile) {
  const b = { ...BODIES[profile.age === 'child' ? 'child' : 'adult'] };
  if (profile.sex === 'f') { b.shHalf *= 0.9; b.hipHalf *= 1.15; }
  return b;
}

const GROUND = 0.975;
const rad = (d) => (d * Math.PI) / 180;
const rot = (v, a) => ({ x: v.x * Math.cos(a) - v.y * Math.sin(a), y: v.x * Math.sin(a) + v.y * Math.cos(a) });
const add = (a, b, k = 1) => ({ x: a.x + b.x * k, y: a.y + b.y * k });

const FRONT_DEFAULT = { lean: 0, head: 0, abdL: 8, abdR: 8, elL: 0, elR: 0, hAbdL: 0, hAbdR: 0, hFlexL: 0, hFlexR: 0, kneeL: 0, kneeR: 0 };
const SIDE_DEFAULT = { s: 0, t: 0, r: 0, a: 0, h: 0 };

// Koji parametar pokreće koji deo tela (za oreol pokreta)
const PARAM_PART = {
  abdL: 'armL', elL: 'armL', abdR: 'armR', elR: 'armR',
  hAbdL: 'legL', hFlexL: 'legL', kneeL: 'legL', hAbdR: 'legR', hFlexR: 'legR', kneeR: 'legR',
  lean: 'torso', head: 'head',
  s: 'legs', t: 'legs', r: 'torso', a: 'arms', h: 'feet',
};

function movingParts(demo) {
  const def = demo.view === 'front' ? FRONT_DEFAULT : SIDE_DEFAULT;
  const parts = new Set();
  for (const key of Object.keys(def)) {
    const vals = demo.frames.map((f) => f.p[key] ?? def[key]);
    if (Math.max(...vals) - Math.min(...vals) > 6) parts.add(PARAM_PART[key]);
  }
  return parts;
}

// Pogled spreda. L udovi su na levoj strani ekrana (kao u ogledalu korisnika).
function frontPose(p, S) {
  const leg = (sg, abd, flex, knee) => {
    const dir = { x: sg * Math.sin(rad(abd)), y: Math.cos(rad(abd)) };
    const th = S.thigh * Math.cos(rad(flex));
    const sh = S.shin * Math.cos(rad(flex - knee));
    return { dir, th, sh, ext: (th + sh) * Math.cos(rad(abd)) };
  };
  const lL = leg(-1, p.hAbdL, p.hFlexL, p.kneeL);
  const lR = leg(1, p.hAbdR, p.hFlexR, p.kneeR);
  const pelvisY = GROUND - 0.012 - Math.max(lL.ext, lR.ext);
  const pelvis = { x: 0, y: pelvisY };
  const j = {};
  j.hipL = { x: -S.hipHalf, y: pelvisY };
  j.hipR = { x: S.hipHalf, y: pelvisY };
  j.kneeL = add(j.hipL, lL.dir, lL.th);
  j.ankleL = add(j.kneeL, lL.dir, lL.sh);
  j.kneeR = add(j.hipR, lR.dir, lR.th);
  j.ankleR = add(j.kneeR, lR.dir, lR.sh);

  const lean = rad(p.lean);
  const up = { x: Math.sin(lean), y: -Math.cos(lean) };
  const right = { x: Math.cos(lean), y: Math.sin(lean) };
  j.shC = add(pelvis, up, S.torso);
  j.shL = add(j.shC, right, -S.shHalf);
  j.shR = add(j.shC, right, S.shHalf);
  const hl = lean + rad(p.head);
  const hu = { x: Math.sin(hl), y: -Math.cos(hl) };
  j.headAngle = hl;
  j.neckTop = add(j.shC, hu, S.neck);
  j.head = add(j.shC, hu, S.neck + S.headR);

  const arm = (sg, sh, abd, el) => {
    const dir = rot({ x: sg * Math.sin(rad(abd)), y: Math.cos(rad(abd)) }, lean);
    const elbow = add(sh, dir, S.ua);
    const inward = rot({ x: -sg, y: 0 }, lean);
    const wrist = add(add(elbow, dir, S.fa * Math.cos(rad(el))), inward, 0.03 * Math.sin(rad(el)));
    return { elbow, wrist };
  };
  const aL = arm(-1, j.shL, p.abdL, p.elL);
  const aR = arm(1, j.shR, p.abdR, p.elR);
  j.elbowL = aL.elbow; j.wristL = aL.wrist; j.elbowR = aR.elbow; j.wristR = aR.wrist;
  return j;
}

// Pogled sa strane (lice okrenuto ka desnoj strani ekrana; bliža kameri je leva strana tela)
function sidePose(p, S) {
  const j = {};
  const h = rad(p.h);
  j.toe = { x: 0.05, y: GROUND - 0.01 };
  j.heel = add(j.toe, { x: -Math.cos(h), y: -Math.sin(h) }, S.foot);
  j.ankle = add(j.heel, rot({ x: 0.022, y: -0.045 }, -h * 0.3));
  j.knee = add(j.ankle, { x: Math.sin(rad(p.s)), y: -Math.cos(rad(p.s)) }, S.shin);
  j.hip = add(j.knee, { x: -Math.sin(rad(p.t)), y: -Math.cos(rad(p.t)) }, S.thigh);
  j.shC = add(j.hip, { x: Math.sin(rad(p.r)), y: -Math.cos(rad(p.r)) }, S.torso);
  const ha = rad(p.r * 0.6);
  const hu = { x: Math.sin(ha), y: -Math.cos(ha) };
  j.headAngle = ha;
  j.head = add(add(j.shC, hu, S.neck + S.headR), { x: 0.012, y: 0 });
  j.neckTop = add(j.shC, hu, S.neck);
  const ad = { x: Math.sin(rad(p.a)), y: Math.cos(rad(p.a)) };
  j.elbow = add(j.shC, ad, S.ua);
  j.wrist = add(j.elbow, ad, S.fa);
  return j;
}

function colors(el) {
  const cs = getComputedStyle(el);
  const g = (n, f) => cs.getPropertyValue(n).trim() || f;
  return {
    torso: g('--fig', '#2b4753'),
    l1: g('--limb-l', '#1677c4'), l2: g('--limb-l2', '#5aa0dc'),
    r1: g('--limb-r', '#7c4dcc'), r2: g('--limb-r2', '#a888e2'),
    joint: g('--joint', '#ffffff'), jointRing: g('--fig', '#2b4753'),
    halo: g('--halo', 'rgba(242,182,50,0.5)'), hair: g('--hair', '#5b3a2a'),
    tape: g('--pink', '#d63a6f'), shadow: g('--shadow', 'rgba(0,0,0,.12)'),
  };
}

export function drawFigure(ctx, w, h, view, p, opts, col) {
  const { focus = [], moving = new Set(), profile = profileOrDefault() } = opts;
  const S = bodyFor(profile);
  const scale = h * 0.9 * S.scale;
  const X = (pt) => w / 2 + pt.x * scale;
  const Y = (pt) => (pt.y - GROUND) * scale + h * 0.95;
  const P = (pt) => [X(pt), Y(pt)];
  ctx.clearRect(0, 0, w, h);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.fillStyle = col.shadow;
  ctx.beginPath();
  ctx.ellipse(w / 2, h * 0.955, scale * 0.17, scale * 0.018, 0, 0, Math.PI * 2);
  ctx.fill();

  const line = (a, b, wd, c) => {
    ctx.strokeStyle = c; ctx.lineWidth = wd * scale;
    ctx.beginPath(); ctx.moveTo(...P(a)); ctx.lineTo(...P(b)); ctx.stroke();
  };
  const halo = (a, b, wd) => line(a, b, wd + 0.04, col.halo);
  const seg = (a, b, wd, c, part) => { if (part && moving.has(part)) halo(a, b, wd); line(a, b, wd, c); };
  const tape = (a, b, key) => {
    if (!focus.includes(key)) return;
    const ia = { x: a.x + (b.x - a.x) * 0.18, y: a.y + (b.y - a.y) * 0.18 };
    const ib = { x: a.x + (b.x - a.x) * 0.82, y: a.y + (b.y - a.y) * 0.82 };
    line(ia, ib, 0.016, col.tape);
  };
  const joint = (pt, r = 0.013) => {
    ctx.fillStyle = col.joint; ctx.strokeStyle = col.jointRing; ctx.lineWidth = 0.005 * scale;
    ctx.beginPath(); ctx.arc(X(pt), Y(pt), r * scale, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  };
  const head = (c, angle, sideView) => {
    if (moving.has('head')) { ctx.fillStyle = col.halo; ctx.beginPath(); ctx.arc(X(c), Y(c), (S.headR + 0.02) * scale, 0, Math.PI * 2); ctx.fill(); }
    if (profile.sex === 'f') {
      // punđa: iznad glave spreda, pozadi glave sa strane
      const dir = sideView ? rot({ x: -0.75, y: -0.75 }, angle) : rot({ x: 0, y: -1 }, angle);
      const bun = add(c, dir, S.headR * 1.05);
      ctx.fillStyle = col.hair; ctx.beginPath(); ctx.arc(X(bun), Y(bun), S.headR * 0.5 * scale, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(X(c), Y(c), S.headR * 1.08 * scale, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = col.torso; ctx.beginPath();
    const fc = profile.sex === 'f' ? add(c, rot({ x: 0, y: 1 }, angle), S.headR * 0.12) : c;
    ctx.arc(X(fc), Y(fc), S.headR * (profile.sex === 'f' ? 0.95 : 1) * scale, 0, Math.PI * 2); ctx.fill();
  };

  if (view === 'front') {
    const j = frontPose({ ...FRONT_DEFAULT, ...p }, S);
    // noge (L plava, D ljubičasta)
    for (const s of ['L', 'R']) {
      const c1 = s === 'L' ? col.l1 : col.r1, c2 = s === 'L' ? col.l2 : col.r2;
      seg(j['hip' + s], j['knee' + s], 0.072, c1, 'leg' + s);
      seg(j['knee' + s], j['ankle' + s], 0.058, c2, 'leg' + s);
      line(j['ankle' + s], { x: j['ankle' + s].x + (s === 'L' ? -0.025 : 0.025), y: j['ankle' + s].y + 0.008 }, 0.04, c2);
      tape(j['hip' + s], j['knee' + s], 'thighs');
      tape(j['knee' + s], j['ankle' + s], 'calves');
    }
    // trup
    if (moving.has('torso')) {
      ctx.strokeStyle = col.halo; ctx.lineWidth = 0.09 * scale;
      ctx.beginPath(); ctx.moveTo(...P(j.shL)); ctx.lineTo(...P(j.shR)); ctx.lineTo(...P(j.hipR)); ctx.lineTo(...P(j.hipL)); ctx.closePath(); ctx.stroke();
    }
    ctx.fillStyle = col.torso; ctx.strokeStyle = col.torso; ctx.lineWidth = 0.05 * scale;
    ctx.beginPath();
    ctx.moveTo(...P(j.shL)); ctx.lineTo(...P(j.shR)); ctx.lineTo(...P(j.hipR)); ctx.lineTo(...P(j.hipL)); ctx.closePath();
    ctx.fill(); ctx.stroke();
    if (focus.includes('trunk')) { tape(j.shL, j.hipL, 'trunk'); tape(j.shR, j.hipR, 'trunk'); }
    if (focus.includes('hips')) line({ x: j.hipL.x, y: j.hipL.y - 0.02 }, { x: j.hipR.x, y: j.hipR.y - 0.02 }, 0.016, col.tape);
    // vrat i glava
    line(j.shC, j.neckTop, 0.045, col.torso);
    if (focus.includes('neck')) { line(j.neckTop, j.shL, 0.014, col.tape); line(j.neckTop, j.shR, 0.014, col.tape); }
    head(j.head, j.headAngle, false);
    // ruke
    for (const s of ['L', 'R']) {
      const c1 = s === 'L' ? col.l1 : col.r1, c2 = s === 'L' ? col.l2 : col.r2;
      seg(j['sh' + s], j['elbow' + s], 0.052, c1, 'arm' + s);
      seg(j['elbow' + s], j['wrist' + s], 0.042, c2, 'arm' + s);
      ctx.fillStyle = c2; ctx.beginPath(); ctx.arc(X(j['wrist' + s]), Y(j['wrist' + s]), 0.026 * scale, 0, Math.PI * 2); ctx.fill();
      tape(j['sh' + s], j['elbow' + s], 'upperArms');
      tape(j['elbow' + s], j['wrist' + s], 'forearms');
    }
    // zglobovi
    for (const s of ['L', 'R']) for (const k of ['sh', 'elbow', 'hip', 'knee', 'ankle']) joint(j[k + s]);
  } else {
    const q = { ...SIDE_DEFAULT, ...p };
    const j = sidePose(q, S);
    const off = (pt) => ({ x: pt.x - 0.014, y: pt.y });
    // dalja (desna) strana
    seg(off(j.hip), off(j.knee), 0.07, col.r1, 'legs');
    seg(off(j.knee), off(j.ankle), 0.056, col.r2, 'legs');
    seg(off(j.heel), off(j.toe), 0.036, col.r2, 'feet');
    seg(off(j.shC), off(j.elbow), 0.05, col.r1, 'arms');
    seg(off(j.elbow), off(j.wrist), 0.04, col.r2, 'arms');
    // trup
    seg(j.hip, j.shC, 0.12, col.torso, 'torso');
    if (focus.includes('trunk')) tape(j.hip, j.shC, 'trunk');
    line(j.shC, j.neckTop, 0.045, col.torso);
    head(j.head, j.headAngle, true);
    // bliža (leva) strana
    seg(j.hip, j.knee, 0.075, col.l1, 'legs');
    seg(j.knee, j.ankle, 0.06, col.l2, 'legs');
    seg(j.heel, j.toe, 0.038, col.l2, 'feet');
    tape(j.hip, j.knee, 'thighs');
    if (focus.includes('hips')) { ctx.fillStyle = col.tape; ctx.beginPath(); ctx.arc(X(j.hip) - 0.03 * scale, Y(j.hip) - 0.01 * scale, 0.014 * scale, 0, Math.PI * 2); ctx.fill(); }
    if (focus.includes('calves')) line({ x: j.knee.x - 0.03, y: j.knee.y + 0.03 }, { x: j.heel.x + 0.005, y: j.heel.y - 0.03 }, 0.016, col.tape);
    seg(j.shC, j.elbow, 0.052, col.l1, 'arms');
    seg(j.elbow, j.wrist, 0.042, col.l2, 'arms');
    for (const k of ['shC', 'elbow', 'hip', 'knee', 'ankle']) joint(j[k]);
  }
}

// ── Plejer koji pušta ključne položaje u petlji ──
const ease = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);

function poseAt(demo, time) {
  const fr = demo.frames;
  const total = fr.reduce((s, f) => s + f.d, 0);
  let t = time % total;
  const def = demo.view === 'front' ? FRONT_DEFAULT : SIDE_DEFAULT;
  for (let i = 0; i < fr.length; i++) {
    if (t <= fr[i].d) {
      const prev = fr[(i - 1 + fr.length) % fr.length].p;
      const next = fr[i].p;
      const k = ease(t / fr[i].d);
      const out = {};
      for (const key of new Set([...Object.keys(prev), ...Object.keys(next)])) {
        const a = prev[key] ?? def[key], b = next[key] ?? def[key];
        out[key] = a + (b - a) * k;
      }
      return out;
    }
    t -= fr[i].d;
  }
  return fr[0].p;
}

const players = new Set();
let rafId = null;
let lastTs = 0;

function tick(ts) {
  const dt = lastTs ? Math.min(0.1, (ts - lastTs) / 1000) : 0;
  lastTs = ts;
  for (const pl of players) pl._frame(dt);
  rafId = players.size ? requestAnimationFrame(tick) : null;
  if (!rafId) lastTs = 0;
}

export function createPlayer(canvas, ex, { autoplay = true, speed = 1 } = {}) {
  const ctx = canvas.getContext('2d');
  let col = colors(canvas);
  const moving = movingParts(ex.demo);
  const pl = {
    canvas, time: 0, speed, playing: autoplay,
    _frame(dt) {
      if (!canvas.isConnected) { players.delete(pl); return; }
      const r = canvas.getBoundingClientRect();
      if (!r.width) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      if (pl.playing) pl.time += dt * pl.speed;
      drawFigure(ctx, w, h, ex.demo.view, poseAt(ex.demo, pl.time), { focus: ex.focus, moving }, col);
    },
    play() { pl.playing = true; },
    pause() { pl.playing = false; },
    refreshColors() { col = colors(canvas); },
    showPeak() {
      const fr = ex.demo.frames;
      let t = 0; for (let i = 0; i < 2 && i < fr.length; i++) t += fr[i].d;
      pl.time = t - 0.01; pl.playing = false;
    },
    destroy() { players.delete(pl); },
  };
  players.add(pl);
  if (!rafId) rafId = requestAnimationFrame(tick);
  return pl;
}

export function refreshAllColors() { for (const p of players) p.refreshColors(); }
