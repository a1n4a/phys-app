// Geometrija nad tačkama tela (MediaPipe Pose, 33 tačke).
// Tačke su u prostoru gde je visina slike = 1, a x je pomnožen odnosom stranica,
// tako da su uglovi tačni bez obzira na rezoluciju kamere.

export const LM = {
  nose: 0, lEar: 7, rEar: 8,
  lSh: 11, rSh: 12, lEl: 13, rEl: 14, lWr: 15, rWr: 16,
  lHip: 23, rHip: 24, lKn: 25, rKn: 26, lAn: 27, rAn: 28,
  lHeel: 29, rHeel: 30, lToe: 31, rToe: 32,
};

// Indeks tačke za stranu tela: J('l', 'Sh') -> 11
export const J = (side, name) => LM[side + name];

const DEG = 180 / Math.PI;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, v: Math.min(a.v, b.v) });
export const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

// Ugao u temenu b (stepeni, 0..180)
export function angle(a, b, c) {
  const v1x = a.x - b.x, v1y = a.y - b.y, v2x = c.x - b.x, v2y = c.y - b.y;
  const d = Math.hypot(v1x, v1y) * Math.hypot(v2x, v2y) || 1e-6;
  return Math.acos(clamp((v1x * v2x + v1y * v2y) / d, -1, 1)) * DEG;
}

// Nagib trupa u odnosu na vertikalu (stepeni, + = ka desnoj strani slike)
export function trunkLean(P) {
  const s = mid(P[LM.lSh], P[LM.rSh]);
  const h = mid(P[LM.lHip], P[LM.rHip]);
  return Math.atan2(s.x - h.x, h.y - s.y) * DEG;
}

// Ugao vektora a->b u odnosu na vertikalu, bez znaka (0 = vertikalno)
export function fromVertical(a, b) {
  return Math.atan2(Math.abs(b.x - a.x), Math.abs(b.y - a.y)) * DEG;
}

// Smer linije a->b (stepeni)
export function lineAngle(a, b) {
  return Math.atan2(b.y - a.y, b.x - a.x) * DEG;
}

export function angleDiff(a, b) {
  let d = a - b;
  while (d > 180) d -= 360;
  while (d < -180) d += 360;
  return d;
}

// Nagib linije prema horizontali, normalizovan na [-90, 90]
export function lineTilt(a, b) {
  let t = lineAngle(a, b);
  if (t > 90) t -= 180;
  if (t < -90) t += 180;
  return t;
}

export { clamp, DEG };
