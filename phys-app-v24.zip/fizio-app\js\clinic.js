// phys Clinic: nalog fizioterapeuta, pregled pacijenata, Therapy Builder, odobravanje predloga.
import { EXERCISES, REGIONS, byId } from './exercises.js';
import { t, exText, errText, regionText, locale } from './i18n.js';
import * as api from './api.js';
import { alertsFor, detective, DEFAULT_RULES } from './insights.js';
import { recognize, parsePlan } from './ocr.js';
import { lineChart } from './report.js';
import { aiStatus, saveKey, generate, errorText, renderResult, toPlanItems, itemName, itemNote, customField, programFor, aiSummaries, aiPlanNote, aiPlanNotes, planSummary, planNote } from './ai.js';
import { getLang } from './i18n.js';
import { readReport, ACCEPT } from './docs.js';

const DAY = 86400000;
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const dShort = (ts) => new Date(ts).toLocaleDateString(locale(), { day: 'numeric', month: 'numeric' });
const dLong = (ts) => new Date(ts).toLocaleString(locale(), { dateStyle: 'medium', timeStyle: 'short' });
const avg = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : null);
const exName = (id) => { const e = byId(id); return e ? exText(e, 'name') : id; };
// "Pacijent 002 JP" -> JP, "Pacijent 001 Čeđa" -> Č, "Pacijent 004" -> 04
const initials = (s) => {
  const words = String(s || '?').split(/\s+/).filter((w) => w && !/^(pacijent|patient)$/i.test(w));
  const named = words.filter((w) => /\p{L}/u.test(w));
  if (named.length === 1 && named[0].length <= 3 && named[0] === named[0].toUpperCase()) return named[0];
  if (named.length) return named.slice(0, 2).map((w) => w[0].toUpperCase()).join('');
  return (words.join('').match(/\d/g) || ['?']).slice(-2).join('');
};
const STATUS_ORDER = { review: 0, reminder: 1, noplan: 2, inactive: 3, ok: 4, paused: 5 };

let root = null;
let cache = null;

export function mountClinic(el) { root = el; }

async function load() {
  const d = await api.getData('therapist');
  cache = { me: d.me, g: api.group(d.docs) };
  return cache;
}

function perPatient(p) {
  const g = cache.g;
  const of = (arr) => arr.filter((x) => x.patientId === p.id);
  return {
    patient: p,
    plan: api.latestPlan(g.plan, p.id),
    plans: of(g.plan).sort((a, b) => (b.version || 0) - (a.version || 0)),
    sessions: of(g.session), logs: of(g.log), reports: of(g.report), proposals: of(g.proposal),
    home: of(g.home).slice(-1)[0] || null,
  };
}

export async function routeClinic(sub) {
  if (!root) return;
  if (!api.auth('therapist')) { renderLogin(); return; }
  root.innerHTML = `<p class="muted">${t('clLoading')}</p>`;
  try { await load(); } catch (e) {
    if (!api.auth('therapist')) { renderLogin(); return; }
    root.innerHTML = `<p class="notice">${e.code === 'offline' ? t('clOffline') : t('clError')}</p>`; return;
  }
  if (sub.startsWith('p-')) renderPatient(sub.slice(2));
  else if (sub.startsWith('plan-')) renderBuilder(sub.slice(5));
  else renderDashboard();
}

// ─────────────── prijava ───────────────
function renderLogin(msg = '') {
  root.innerHTML = `
  <div class="cl-login">
    <div class="cl-intro">
      <div class="cl-brand" aria-label="phys"><svg viewBox="0 0 48 28" aria-hidden="true"><path d="M4 23.5c7.5 3.2 12.6-.6 17-7.2S30.5 3.6 37.6 4.4c2.6.3 4.6 1.4 6.4 2.8" fill="none" stroke="currentColor" stroke-width="5.2" stroke-linecap="round"/></svg><div><b>phys</b><span>Beyond the Clinic.</span></div></div>
      <p class="eyebrow">phys Clinic</p>
      <h1>${t('clLoginTitle')}</h1>
      <p class="lead">${t('clLoginIntro')}</p>
      <ol class="loop">
        <li><strong>${t('loop1')}</strong><span>${t('loop1s')}</span></li>
        <li><strong>${t('loop2')}</strong><span>${t('loop2s')}</span></li>
        <li><strong>${t('loop3')}</strong><span>${t('loop3s')}</span></li>
        <li><strong>${t('loop4')}</strong><span>${t('loop4s')}</span></li>
      </ol>
    </div>
    <div class="cl-forms">
      ${msg ? `<p class="notice">${esc(msg)}</p>` : ''}
      <form class="log-card" id="cl-login">
        <h2>${t('clLogin')}</h2>
        <label class="fl" for="li-email">${t('clEmail')}</label><input id="li-email" type="email" autocomplete="email" required>
        <label class="fl" for="li-pw">${t('clPassword')}</label><input id="li-pw" type="password" autocomplete="current-password" required>
        <button class="btn primary" type="submit">${t('clLogin')}</button>
      </form>
      <form class="log-card" id="cl-register">
        <h2>${t('clRegister')}</h2>
        <label class="fl" for="rg-name">${t('clName')}</label><input id="rg-name" type="text" autocomplete="name" required>
        <label class="fl" for="rg-email">${t('clEmail')}</label><input id="rg-email" type="email" autocomplete="email" required>
        <label class="fl" for="rg-pw">${t('clPassword')}</label><input id="rg-pw" type="password" autocomplete="new-password" minlength="6" required>
        <span class="hint">${t('clPwHint')}</span>
        <button class="btn primary" type="submit">${t('clRegister')}</button>
      </form>
    </div>
  </div>`;
  const errMsg = (e) => ({ bad_login: t('clBadLogin'), email_taken: t('clEmailTaken'), missing_fields: t('clMissing'), offline: t('clOffline') }[e.code] || t('clError'));
  root.querySelector('#cl-login').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    try { await api.login(root.querySelector('#li-email').value, root.querySelector('#li-pw').value); routeClinic(''); }
    catch (e) { renderLogin(errMsg(e)); }
  });
  root.querySelector('#cl-register').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    try { await api.register(root.querySelector('#rg-name').value, root.querySelector('#rg-email').value, root.querySelector('#rg-pw').value); routeClinic(''); }
    catch (e) { renderLogin(errMsg(e)); }
  });
}

// ─────────────── tekstovi upozorenja i sažetka ───────────────
function varsText(v) {
  const o = { ...v };
  if (o.exId) o.ex = exName(o.exId);
  if (o.reason) o.reason = (t('reasons')[o.reason] || o.reason);
  if (o.errId && o.exId) { const e = byId(o.exId); o.err = e ? errText(e, { id: o.errId, msg: o.errId }) : o.errId; }
  return o;
}
const alertText = (a) => t(a.key, varsText(a.vars));
const confText = { high: () => t('confHigh'), medium: () => t('confMedium'), low: () => t('confLow') };
const statusBadge = (s) => `<span class="badge b-${s}">${t('st_' + s)}</span>`;

// ─────────────── dashboard ───────────────
function renderDashboard() {
  const { me, g } = cache;
  const rules = { ...DEFAULT_RULES, ...(me.rules || {}) };
  const rows = g.patient.map((p) => { const P = perPatient(p); const A = alertsFor(P, rules); return { p, P, A }; })
    .sort((a, b) => STATUS_ORDER[a.A.status] - STATUS_ORDER[b.A.status]);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const sessToday = g.session.filter((s) => s.date >= today.getTime()).length;
  const review = rows.filter((r) => r.A.status === 'review');
  const worse = rows.filter((r) => r.A.alerts.some((a) => a.key === 'alPainRise' || a.key === 'alWorse'));
  const reminder = rows.filter((r) => r.A.status === 'reminder');

  root.innerHTML = `
  <header class="cl-head">
    <div><p class="eyebrow">phys Clinic</p><h1>${t('clOverview')}</h1></div>
    <div class="cl-me"><span>${esc(me.name)}</span><button class="btn ghost small-btn" id="cl-refresh" type="button">${t('clRefresh')}</button><button class="link-btn" id="cl-logout" type="button">${t('clLogout')}</button></div>
  </header>
  <section class="cl-stats">
    <div><small>${t('clPatients')}</small><span>${g.patient.length}</span></div>
    <div><small>${t('clToReview')}</small><span>${review.length}</span></div>
    <div><small>${t('clSessionsToday')}</small><span>${sessToday}</span></div>
  </section>

  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('clDaySummary')}</h2><span class="pill">${t('clAuto')}</span></div>
    <p>${rows.length ? t('clDayText', { n: rows.length, r: review.length, m: reminder.length, w: worse.length }) : t('clNoPatients')}</p>
    ${review.length ? `<p class="muted small">${t('clSources')}: ${review.map((r) => esc(r.p.label)).join(', ')}</p>` : ''}
  </section>

  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('clAttention')}</h2><button class="btn primary small-btn" id="cl-add" type="button">+ ${t('clAddPatient')}</button></div>
    <form id="cl-new" class="cl-new" hidden>
      <label class="fl" for="np-label">${t('clPatientLabel')}</label>
      <input id="np-label" type="text" required placeholder="${t('clPatientLabelPh')}">
      <div class="row2">
        <div><label class="fl" for="np-sex">${t('sex')}</label><select id="np-sex"><option value="m">${t('male')}</option><option value="f">${t('female')}</option></select></div>
        <div><label class="fl" for="np-age">${t('age')}</label><select id="np-age"><option value="adult">${t('adult')}</option><option value="child">${t('child')}</option></select></div>
      </div>
      <button class="btn primary" type="submit">${t('clCreatePatient')}</button>
    </form>
    <ul class="pt-list">
      ${rows.map(({ p, A, P }) => `
        <li><a href="#klinika-p-${p.id}">
          <span class="av">${esc(initials(p.label))}</span>
          <span class="pt-main"><strong>${esc(p.label)}</strong><small>${esc(A.alerts[0] ? alertText(A.alerts[0]) : t('stx_' + A.status))}</small></span>
          ${statusBadge(A.status)}
        </a></li>`).join('') || `<li class="muted">${t('clNoPatients')}</li>`}
    </ul>
  </section>

  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('clRules')}</h2></div>
    <p class="muted small">${t('clRulesIntro')}</p>
    <form id="cl-rules" class="rules">
      <label>${t('ruPain')} <input type="number" id="ru-pain" min="1" max="6" value="${rules.painRise}"></label>
      <label>${t('ruMissed')} <input type="number" id="ru-missed" min="1" max="7" value="${rules.missedDays}"></label>
      <label>${t('ruTracking')} <input type="number" id="ru-track" min="20" max="95" step="5" value="${Math.round(rules.lowTracking * 100)}"> %</label>
      <button class="btn ghost" type="submit">${t('save')}</button><span class="saved" id="ru-ok" role="status"></span>
    </form>
  </section>`;

  root.querySelector('#cl-refresh').addEventListener('click', () => routeClinic(''));
  root.querySelector('#cl-logout').addEventListener('click', () => { api.logout('therapist'); routeClinic(''); });
  root.querySelector('#cl-add').addEventListener('click', () => { const f = root.querySelector('#cl-new'); f.hidden = !f.hidden; if (!f.hidden) root.querySelector('#np-label').focus(); });
  root.querySelector('#cl-new').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const p = await api.put('therapist', 'patient', { label: root.querySelector('#np-label').value.trim(), sex: root.querySelector('#np-sex').value, age: root.querySelector('#np-age').value });
    location.hash = 'klinika-plan-' + p.id;
  });
  root.querySelector('#cl-rules').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const r = { painRise: Number(root.querySelector('#ru-pain').value), missedDays: Number(root.querySelector('#ru-missed').value), lowTracking: Number(root.querySelector('#ru-track').value) / 100 };
    cache.me = await api.put('therapist', 'therapist', { id: me.id, rules: r });
    root.querySelector('#ru-ok').textContent = t('logSaved');
  });
}

// ─────────────── pacijent ───────────────
// u Android aplikaciji pozivnica vodi na web adresu servera (pacijent je može otvoriti i u browseru)
function inviteLink(code) { return api.serverBase() ? `${api.serverBase()}?join=${code}` : `${location.origin}${location.pathname}?join=${code}`; }

let qrPromise = null;
function loadQr() {
  if (window.QRCode) return Promise.resolve();
  if (!qrPromise) qrPromise = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
    s.onload = res; s.onerror = () => { qrPromise = null; rej(); };
    document.head.appendChild(s);
  });
  return qrPromise;
}

function renderPatient(id) {
  const p = cache.g.patient.find((x) => x.id === id);
  if (!p) { root.innerHTML = `<p class="notice">${t('clNotFound')}</p>`; return; }
  const P = perPatient(p);
  const rules = { ...DEFAULT_RULES, ...(cache.me.rules || {}) };
  const A = alertsFor(P, rules);
  const D = detective(P);
  const plan = P.plan;
  const days = t('weekdays');
  const pending = P.proposals.filter((x) => x.status === 'pending');
  const painDays = Array.from({ length: 14 }, (_, i) => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime() - (13 - i) * DAY; });
  const painVals = painDays.map((d) => { const v = P.logs.filter((l) => l.date >= d && l.date < d + DAY && l.pain != null).map((l) => l.pain); return v.length ? avg(v) : null; });
  const link = inviteLink(p.inviteCode);

  root.innerHTML = `
  <a class="link-btn" href="#klinika">← ${t('clOverview')}</a>
  <header class="cl-head">
    <div><p class="eyebrow">${p.sex === 'f' ? t('female') : t('male')} · ${p.age === 'child' ? t('child') : t('adult')}</p><h1>${esc(p.label)}</h1></div>
    <div>${statusBadge(A.status)}</div>
  </header>

  <section class="cl-card invite ${p.activated ? 'done' : ''}">
    <div class="cl-card-h"><h2>${p.activated ? t('clActivated', { d: dShort(p.activatedAt) }) : t('clInvite')}</h2></div>
    ${p.activated ? '' : `<p class="muted">${t('clInviteText')}</p>`}
    ${!p.activated && /^(localhost|127\.)/.test(location.hostname) ? `<p class="notice">${t('clLocalWarn')}</p>` : ''}
    <div class="invite-row">
      <div id="qr" class="qr" aria-label="QR"></div>
      <div class="invite-info">
        <span class="label">${t('clCode')}</span><span class="code">${esc(p.inviteCode)}</span>
        <span class="label">${t('clLink')}</span><span class="linktext">${esc(link)}</span>
        <button class="btn ghost small-btn" type="button" id="copy-link">${t('clCopy')}</button><span class="saved" id="copy-ok"></span>
      </div>
    </div>
  </section>

  <section class="cl-card">
    <div class="cl-card-h"><h2>Recovery Detective</h2><span class="pill">${t('clAuto')}</span></div>
    <ul class="dt-list">
      ${D.items.map((it) => `<li><p>${esc(t(it.key, varsText(it.vars)))}</p>
        <small><span class="conf c-${it.confidence}">${confText[it.confidence]()}</span>
        ${it.sources.length ? `${t('clSources')}: ${it.sources.map(dShort).join(', ')}` : ''}</small></li>`).join('')}
    </ul>
    <p class="muted small">${t('clDtNote')}</p>
  </section>

  ${A.alerts.length ? `<section class="cl-card"><div class="cl-card-h"><h2>Smart Alerts</h2></div><ul class="al-list">
    ${A.alerts.map((a) => `<li class="al-${a.level}"><span>${esc(alertText(a))}</span><small>${a.sources.map(dShort).join(', ')}</small></li>`).join('')}</ul></section>` : ''}

  ${pending.map((pr) => proposalCard(pr, P)).join('')}

  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('clPlan')}${plan ? ` · v${plan.version}` : ''}</h2>
      <div class="btns">
        <a class="btn primary small-btn" href="#klinika-plan-${p.id}">${plan ? t('clEditPlan') : t('clCreatePlan')}</a>
        ${plan ? `<button class="btn ghost small-btn" id="pause" type="button">${plan.status === 'paused' ? t('clResume') : t('clPause')}</button>` : ''}
      </div>
    </div>
    ${plan ? `
      <p class="muted small">${t('clDays')}: ${(plan.days || []).map((d) => days[d - 1]).join(', ') || '–'}${plan.status === 'paused' ? ` · <strong>${t('st_paused')}</strong>` : ''}</p>
      ${planSummary(plan) ? `<p><span class="pill">AI</span> ${esc(planSummary(plan).condition || '')}</p>` : ''}
      ${plan.approval ? `<p class="approved-line">✓ ${esc(t('apBy', { name: plan.approval.by || '–', date: dLong(plan.approval.at) }))}${plan.approval.ai ? ` · ${t('rvCountDone', { a: plan.approval.approved || 0, e: plan.approval.edited || 0, r: plan.approval.rejected || 0 })}` : ''}</p>` : ''}
      <div class="table-wrap"><table class="rp-table"><thead><tr><th>${t('rpExercise')}</th><th>${t('clSets')}</th><th>${t('clReps')}</th><th>${t('clSide')}</th><th>${t('bRomTarget')}</th><th>${t('clRomMax')}</th><th>${t('clNote')}</th></tr></thead><tbody>
      ${plan.items.map((it) => `<tr><td>${esc(itemName(it))}${it.custom ? ` <span class="tag">${t('aiNoCam')}</span>` : ''}</td><td>${it.sets}</td><td>${it.reps}${it.custom && it.custom.holdSec ? ` × ${it.custom.holdSec} s` : ''}</td><td>${t('side_' + (it.side || 'both'))}</td><td>${it.romTarget ? it.romTarget + '°' : '–'}</td><td>${it.romMax ? it.romMax + '°' : '–'}</td><td>${esc(it.custom ? (customField(it, 'cautions') || []).join('; ') : itemNote(it))}</td></tr>`).join('')}
      </tbody></table></div>
      ${planNote(plan) ? `<p class="pre"><strong>${t('clNote')}:</strong> ${esc(planNote(plan))}</p>` : ''}
      ${P.plans.length > 1 ? `<details><summary>${t('clHistory')}</summary><ul class="rp-list">${P.plans.map((v) => `<li><time>v${v.version}</time> ${dLong(v.createdAt)} · ${v.items.map((i) => esc(itemName(i))).join(', ')}</li>`).join('')}</ul></details>` : ''}
    ` : `<p class="muted">${t('clNoPlan')}</p>`}
  </section>

  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('rpPainChart')}</h2></div>
    ${P.logs.length ? lineChart({ series: [{ name: t('painShort'), color: 'var(--c-pain)', values: painVals }], labels: painDays.map(dShort), yMin: 0, yMax: 10, yTicks: [0, 5, 10], aria: t('rpPainChart') }) : `<p class="muted">${t('rpNoLogs')}</p>`}
  </section>

  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('clSessions')}</h2></div>
    ${P.sessions.length ? `<div class="table-wrap"><table class="rp-table"><thead><tr><th>${t('rpDate')}</th><th>${t('rpExercise')}</th><th>${t('statGood')}</th><th>${t('rpRom')}</th><th>${t('cmpQuality')}</th><th>${t('clTracking')}</th></tr></thead><tbody>
      ${P.sessions.slice(-12).reverse().map((s) => { const rom = avg(s.romPeaks || []); return `<tr><td>${dLong(s.date)}</td><td>${esc(s.name || exName(s.exId))}</td><td>${s.good}/${s.reps}</td><td>${rom == null ? '–' : Math.round(rom) + '°'}</td><td>${typeof s.quality === 'number' ? s.quality + (typeof s.deviation === 'number' ? ` <small class="muted">(${t('cmpDev').toLowerCase()} ${s.deviation} %)</small>` : '') : '–'}</td><td>${typeof s.tracking === 'number' ? Math.round(s.tracking * 100) + '%' : '–'}</td></tr>`; }).join('')}
      </tbody></table></div>` : `<p class="muted">${t('clNoSessions')}</p>`}
    ${P.reports.length ? `<h3 class="label">${t('clCannotList')}</h3><ul class="rp-list">${P.reports.slice(-6).reverse().map((r) => `<li><time>${dShort(r.date)}</time> ${esc(r.name || exName(r.exId))}: ${esc(t('reasons')[r.reason] || r.reason)}${r.text ? ` – „${esc(r.text)}“` : ''}</li>`).join('')}</ul>` : ''}
    ${P.home ? `<p class="muted small">${t('clHome')}: ${homeText(P.home)}</p>` : ''}
  </section>`;

  // QR i kopiranje
  loadQr().then(() => { const el = root.querySelector('#qr'); if (el) new window.QRCode(el, { text: link, width: 148, height: 148, colorDark: '#0D2F5A', colorLight: '#ffffff' }); }).catch(() => {});
  root.querySelector('#copy-link').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(link); root.querySelector('#copy-ok').textContent = t('clCopied'); } catch { /* */ }
  });
  const pause = root.querySelector('#pause');
  if (pause) pause.addEventListener('click', async () => {
    await api.put('therapist', 'plan', { ...plan, status: plan.status === 'paused' ? 'active' : 'paused' });
    routeClinic('p-' + p.id);
  });
  for (const pr of pending) bindProposal(pr, P);
}

function homeText(h) {
  const eq = Object.entries(h.equipment || {}).filter(([, v]) => v).map(([k]) => t('equip')[k]).join(', ') || '–';
  return `${eq}; ${t('space_' + (h.space || 'ok'))}; ${t('cam_' + (h.camera || 'both'))}`;
}

function proposalCard(pr, P) {
  if (pr.kind === 'substitute') {
    return `<section class="cl-card proposal" id="pr-${pr.id}">
      <div class="cl-card-h"><h2>${t('prSubTitle')}</h2><span class="badge b-review">${t('st_review')}</span></div>
      <p>${t('prSubText', { ex: esc(exName(pr.fromExId)), reason: esc(t('reasons')[pr.reason] || pr.reason || '') })}</p>
      ${pr.blockers && pr.blockers.length ? `<p class="muted small">${pr.blockers.map((b) => t(b)).join(' · ')}</p>` : ''}
      <fieldset class="field"><legend>${t('prChoose')}</legend><div class="choice">
        ${(pr.options || []).map((o, i) => `<label><input type="radio" name="opt-${pr.id}" value="${o}" ${i === 0 ? 'checked' : ''}><span>${esc(exName(o))}</span></label>`).join('')}
        <label><input type="radio" name="opt-${pr.id}" value="__remove"><span>${t('prRemove')}</span></label>
      </div></fieldset>
      <div class="btns"><button class="btn primary small-btn" data-act="ok" type="button">${t('prApprove')}</button><button class="btn ghost small-btn" data-act="no" type="button">${t('prReject')}</button></div>
    </section>`;
  }
  if (pr.kind === 'ai') {
    const s = pr.ai ? programFor(pr.ai).summary : null;
    return `<section class="cl-card proposal" id="pr-${pr.id}">
      <div class="cl-card-h"><h2>${pr.ai && pr.ai.model === 'preset' ? t('prPresetTitle') : t('prAiTitle')}</h2><span class="badge b-review">${t('st_review')}</span></div>
      ${s ? `<p><span class="pill">AI</span> <strong>${esc(s.condition)}</strong></p>` : ''}
      <p class="muted">${t('prAiText')}</p>
      <ul class="rp-list">${(pr.items || []).map((i) => `<li>${esc(itemName(i))} · ${i.sets || 1} × ${i.reps || 10}${i.romTarget ? ` · ${t('aiRomTarget', { v: i.romTarget })}` : ''}</li>`).join('')}</ul>
      <div class="btns"><button class="btn primary small-btn" data-act="edit" type="button">${t('prOpenBuilder')}</button><button class="btn ghost small-btn" data-act="no" type="button">${t('prReject')}</button></div>
    </section>`;
  }
  if (pr.kind === 'edit') {
    return `<section class="cl-card proposal" id="pr-${pr.id}">
      <div class="cl-card-h"><h2>${t('prEditTitle')}</h2><span class="badge b-review">${t('st_review')}</span></div>
      <p><strong>${esc(pr.title || '')}</strong></p>
      <p class="muted">${t('prEditText', { name: esc(pr.fromTitle || '') })}</p>
      <ul class="rp-list">${(pr.items || []).map((i) => `<li>${esc(itemName(i))} · ${i.sets || 1} × ${i.reps || 10}</li>`).join('')}</ul>
      <div class="btns"><button class="btn primary small-btn" data-act="edit" type="button">${t('prOpenBuilder')}</button><button class="btn ghost small-btn" data-act="no" type="button">${t('prReject')}</button></div>
    </section>`;
  }
  return `<section class="cl-card proposal" id="pr-${pr.id}">
    <div class="cl-card-h"><h2>${t('prScanTitle')}</h2><span class="badge b-review">${t('st_review')}</span></div>
    <p class="muted">${t('prScanText')}</p>
    <ul class="rp-list">${(pr.items || []).map((i) => `<li>${esc(exName(i.exId))} · ${i.sets || 1} × ${i.reps || byId(i.exId)?.defaultReps || 10}</li>`).join('')}</ul>
    <div class="btns"><button class="btn primary small-btn" data-act="edit" type="button">${t('prOpenBuilder')}</button><button class="btn ghost small-btn" data-act="no" type="button">${t('prReject')}</button></div>
  </section>`;
}

function bindProposal(pr, P) {
  const el = root.querySelector('#pr-' + pr.id);
  if (!el) return;
  const decide = async (status, extra = {}) => { await api.put('therapist', 'proposal', { ...pr, status, decidedAt: Date.now(), ...extra }); };
  el.querySelector('[data-act="no"]').addEventListener('click', async () => { await decide('rejected'); routeClinic('p-' + P.patient.id); });
  const ok = el.querySelector('[data-act="ok"]');
  if (ok) ok.addEventListener('click', async () => {
    const choice = el.querySelector(`input[name="opt-${pr.id}"]:checked`)?.value;
    const plan = P.plan;
    if (plan && choice) {
      const items = choice === '__remove'
        ? plan.items.filter((i) => i.exId !== pr.fromExId)
        : plan.items.map((i) => {
          if (i.exId !== pr.fromExId) return i;
          const { custom, noteI18n, romTarget, ...rest } = i; // zamena je vežba iz biblioteke (kamera prati)
          return { ...rest, exId: choice, romMax: null, note: t('prReplacedNote', { ex: itemName(i) }) };
        });
      await api.put('therapist', 'plan', { patientId: P.patient.id, version: (plan.version || 0) + 1, items, days: plan.days, note: plan.note, noteI18n: plan.noteI18n || null,
        aiSummary: plan.aiSummary || null, aiSummaryI18n: plan.aiSummaryI18n || null, status: 'active' });
    }
    await decide('approved', { choice });
    routeClinic('p-' + P.patient.id);
  });
  const edit = el.querySelector('[data-act="edit"]');
  if (edit) edit.addEventListener('click', () => { sessionStorage.setItem('fizio-prefill', JSON.stringify({ patientId: P.patient.id, proposalId: pr.id, items: pr.items, ai: pr.ai || null })); location.hash = 'klinika-plan-' + P.patient.id; });
}

// ─────────────── Therapy Builder ───────────────
// AI predlog ne ulazi sam u plan: fizioterapeut svaku predloženu vežbu odobrava, menja ili odbija.
// AI tekst se čuva na oba jezika (i18n). Kada terapeut ručno izmeni tekst, čuva se samo izmenjena verzija.
let builderAi = null;            // poslednji AI rezultat prikazan u builder-u
let builderPatient = null;       // id pacijenta čiji je plan otvoren
let builderLang = 'sr';          // jezik na kome je builder iscrtan (tekst u poljima je na tom jeziku)
let aiReview = [];               // odluka za svaku AI vežbu: 'pending' | 'approved' | 'edited' | 'rejected'
let scheduleReview = null;       // odluka za predloženi raspored i napomenu (isto)
const customI18n = new Map();    // id vežbe bez kamere -> {sr: {name, instructions, cautions}, en: {...}}
const libNoteI18n = new Map();   // exId -> {sr: napomena, en: napomena}
let planNoteI18n = null;         // {sr, en} napomena plana iz AI-ja
let planAiSummary = null;        // {summary, i18n} sažetak koji ostaje uz plan

const joinSteps = (a) => (a || []).join('\n');

function customRow(it) {
  if (it.custom && it.custom.i18n) customI18n.set(it.exId, it.custom.i18n);
  const name = it.custom ? customField(it, 'name') || '' : '';
  const steps = it.custom ? customField(it, 'instructions') || [] : [];
  const cautions = it.custom ? customField(it, 'cautions') || [] : [];
  const hold = it.custom ? it.custom.holdSec || 0 : 0;
  return `<li class="b-row on b-custom" data-cid="${esc(it.exId)}">
    <label class="b-pick"><input type="checkbox" checked><span><strong>${esc(name) || t('bCustomName')}</strong><small>${t('aiNoCam')}</small></span></label>
    <div class="b-params">
      <label class="wide">${t('bCustomName')}<input type="text" class="c-name" value="${esc(name)}"></label>
      <label>${t('clSets')}<input type="number" class="b-sets" min="1" max="6" value="${it.sets || 2}"></label>
      <label>${t('clReps')}<input type="number" class="b-reps" min="1" max="50" value="${it.reps || 10}"></label>
      <label>${t('bCustomHold')}<input type="number" class="c-hold" min="0" max="120" value="${hold}"></label>
      <label>${t('clSide')}<select class="b-side">${['both', 'left', 'right'].map((s) => `<option value="${s}" ${(it.side || 'both') === s ? 'selected' : ''}>${t('side_' + s)}</option>`).join('')}</select></label>
      <label class="wide">${t('bCustomSteps')}<textarea class="c-steps" rows="3">${esc(joinSteps(steps))}</textarea></label>
      <label class="wide">${t('clNote')}<input type="text" class="b-note" value="${esc(cautions.join('; ') || it.note || '')}"></label>
    </div>
  </li>`;
}

// Stanje forme -> podaci plana (koristi se za čuvanje i za privremeni nacrt pri promeni jezika)
function collectBuilder() {
  const lang = builderLang;
  const lib = [...root.querySelectorAll('#b-lib .b-row.on')].map((li) => {
    const exId = li.dataset.ex;
    const note = li.querySelector('.b-note').value.trim();
    const ni = libNoteI18n.get(exId);
    return {
      exId,
      sets: Number(li.querySelector('.b-sets').value) || 1,
      reps: Number(li.querySelector('.b-reps').value) || 10,
      side: li.querySelector('.b-side').value,
      romTarget: Number(li.querySelector('.b-romt').value) || null,
      romMax: Number(li.querySelector('.b-rom').value) || null,
      tol: Number(li.querySelector('.b-tol').value),
      note,
      noteI18n: ni && (ni[lang] || '') === note ? ni : null,
    };
  });
  const cus = [...root.querySelectorAll('#b-custom .b-row')].filter((li) => li.querySelector('input[type=checkbox]').checked && li.querySelector('.c-name').value.trim()).map((li) => {
    const cid = li.dataset.cid;
    const name = li.querySelector('.c-name').value.trim();
    const instructions = li.querySelector('.c-steps').value.split('\n').map((s) => s.trim()).filter(Boolean);
    const note = li.querySelector('.b-note').value.trim();
    const cautions = note ? note.split(/;\s*/).filter(Boolean) : [];
    const old = customI18n.get(cid);
    const cur = old && old[lang];
    const same = cur && cur.name === name && joinSteps(cur.instructions) === joinSteps(instructions) && (cur.cautions || []).join('; ') === cautions.join('; ');
    return {
      exId: cid,
      sets: Number(li.querySelector('.b-sets').value) || 1,
      reps: Number(li.querySelector('.b-reps').value) || 10,
      side: li.querySelector('.b-side').value,
      note: '',
      custom: { name, holdSec: Number(li.querySelector('.c-hold').value) || 0, instructions, cautions, i18n: same ? old : { [lang]: { name, instructions, cautions } } },
    };
  });
  const note = root.querySelector('#b-note').value.trim();
  const summary = builderAi ? programFor(builderAi).summary : planAiSummary ? planAiSummary.summary : null;
  const summaryI18n = builderAi ? aiSummaries(builderAi) : planAiSummary ? planAiSummary.i18n : null;
  return {
    items: [...lib, ...cus],
    days: [...root.querySelectorAll('#b-days input:checked')].map((i) => Number(i.value)),
    note,
    noteI18n: planNoteI18n && (planNoteI18n[lang] || '') === note ? planNoteI18n : null,
    aiSummary: summary || null,
    aiSummaryI18n: summaryI18n || null,
  };
}

// Pre promene jezika: sačuvaj nacrt da se izmene ne izgube kada se builder ponovo iscrta
export function saveBuilderDraft() {
  if (!root || !builderPatient || !root.querySelector('#b-save')) return;
  const d = collectBuilder();
  sessionStorage.setItem('fizio-builder-draft', JSON.stringify({ ...d, patientId: builderPatient, ai: builderAi, aiReview, scheduleReview, aiText: root.querySelector('#ai-text').value }));
}

function renderBuilder(id) {
  const p = cache.g.patient.find((x) => x.id === id);
  if (!p) { root.innerHTML = `<p class="notice">${t('clNotFound')}</p>`; return; }
  const P = perPatient(p);
  const plan = P.plan;
  let prefill = null, draft = null;
  try { prefill = JSON.parse(sessionStorage.getItem('fizio-prefill') || 'null'); } catch { /* */ }
  try { draft = JSON.parse(sessionStorage.getItem('fizio-builder-draft') || 'null'); } catch { /* */ }
  sessionStorage.removeItem('fizio-builder-draft');
  if (prefill && prefill.patientId !== id) prefill = null;
  if (draft && draft.patientId !== id) draft = null;

  builderPatient = id;
  builderLang = getLang();
  customI18n.clear(); libNoteI18n.clear();
  builderAi = draft ? draft.ai : prefill && prefill.ai ? prefill.ai : null;
  // AI predlog od pacijenta ide na pregled (ne direktno u plan); ostali predlozi (npr. papirni plan) se popunjavaju odmah
  const prefillAi = !!(prefill && prefill.ai && !draft);
  aiReview = draft ? draft.aiReview || [] : prefillAi ? toPlanItems(prefill.ai).map(() => 'pending') : [];
  scheduleReview = draft ? draft.scheduleReview || null : prefillAi ? 'pending' : null;
  const src = draft || (prefill && !prefillAi ? { items: prefill.items } : plan) || { items: [] };
  const sourceItems = src.items || [];
  for (const i of sourceItems) if (!i.custom && i.noteI18n) libNoteI18n.set(i.exId, i.noteI18n);
  // napomena plana i sažetak: iz nacrta ili iz postojećeg plana (AI napomena ulazi tek kada se odobri)
  planNoteI18n = draft ? draft.noteI18n : plan ? plan.noteI18n || null : null;
  const noteText = draft ? (planNoteI18n && planNoteI18n[getLang()] != null ? planNoteI18n[getLang()] : draft.note || '') : planNote(plan);
  planAiSummary = draft ? (draft.aiSummary ? { summary: draft.aiSummary, i18n: draft.aiSummaryI18n } : null)
    : plan && plan.aiSummary ? { summary: plan.aiSummary, i18n: plan.aiSummaryI18n || null } : null;

  const base = new Map(sourceItems.filter((i) => !i.custom).map((i) => [i.exId, i]));
  const customs = sourceItems.filter((i) => i.custom);
  const days = t('weekdays');
  const planDays = draft ? draft.days : plan && plan.days ? plan.days : [1, 3, 5];

  const row = (ex) => {
    const v = base.get(ex.id) || {};
    const on = base.has(ex.id);
    return `<li class="b-row ${on ? 'on' : ''}" data-ex="${ex.id}">
      <label class="b-pick"><input type="checkbox" ${on ? 'checked' : ''}><span><strong>${esc(exText(ex, 'name'))}</strong><small>${esc(regionText(REGIONS.find((r) => r.id === ex.region)))} · ${ex.view === 'side' ? t('camSide') : t('camFront')}</small></span></label>
      <div class="b-params">
        <label>${t('clSets')}<input type="number" class="b-sets" min="1" max="6" value="${v.sets || 2}"></label>
        <label>${t('clReps')}<input type="number" class="b-reps" min="1" max="50" value="${v.reps || ex.defaultReps}"></label>
        <label>${t('clSide')}<select class="b-side">${['both', 'left', 'right'].map((s) => `<option value="${s}" ${(v.side || 'both') === s ? 'selected' : ''}>${t('side_' + s)}</option>`).join('')}</select></label>
        <label>${t('bRomTarget')}<input type="number" class="b-romt" min="3" max="180" placeholder="${ex.target}" value="${v.romTarget || ''}"></label>
        <label>${t('clRomMax')}<input type="number" class="b-rom" min="5" max="180" placeholder="${t('clRomNone')}" value="${v.romMax || ''}"></label>
        <label>${t('tolerance')}<select class="b-tol">${[0.05, 0.1, 0.15].map((x) => `<option value="${x}" ${(v.tol || 0.1) === x ? 'selected' : ''}>${x * 100} %</option>`).join('')}</select></label>
        <label class="wide">${t('clNote')}<input type="text" class="b-note" value="${esc(on ? itemNote(v) : '')}" placeholder="${t('clItemNotePh')}"></label>
      </div>
    </li>`;
  };

  root.innerHTML = `
  <a class="link-btn" href="#klinika-p-${p.id}">← ${esc(p.label)}</a>
  <header class="cl-head"><div><p class="eyebrow">Therapy Builder</p><h1>${plan ? t('clEditPlan') : t('clCreatePlan')} · ${esc(p.label)}</h1></div></header>
  ${prefill && !draft && !prefillAi ? `<p class="notice">${t('bPrefill')}</p>` : ''}

  <section class="cl-card ai-card">
    <div class="cl-card-h"><h2>${t('aiTitle')}</h2><span class="pill">AI</span></div>
    <p class="muted">${t('aiIntro')}</p>
    <details id="ai-key" class="ai-key" hidden>
      <summary>${t('aiKeySetup')}</summary>
      <form id="ai-key-form" class="ai-key-form">
        <p class="notice">${t('aiNoKey')}</p>
        <label class="fl" for="ai-key-in">${t('aiKeyLabel')}</label>
        <input id="ai-key-in" type="password" autocomplete="off" placeholder="sk-ant-...">
        <span class="hint">${t('aiKeyHint')}</span>
        <button class="btn ghost small-btn" type="submit">${t('aiKeySave')}</button><span class="saved" id="ai-key-msg" role="status"></span>
      </form>
    </details>
    <label class="fl" for="ai-text">${t('aiPaste')}</label>
    <textarea id="ai-text" rows="7" placeholder="${t('aiPastePh')}">${esc(draft ? draft.aiText || '' : '')}</textarea>
    <div class="start-row">
      <label class="btn ghost file-btn"><input id="ai-cam" type="file" accept="image/*" capture="environment"><span>${t('fileTake')}</span></label>
      <label class="btn ghost file-btn"><input id="ai-file" type="file" accept="${ACCEPT}"><span>${t('fileChoose')}</span></label>
      <span class="muted small" id="ai-file-name" role="status"></span>
    </div>
    <div class="start-row"><button class="btn primary" type="button" id="ai-run">${t('aiRun')}</button><span class="muted" id="ai-status" role="status"></span></div>
    <div id="ai-out"></div>
  </section>

  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('bExercises')}</h2></div>
    <ul class="b-list" id="b-lib">${EXERCISES.map(row).join('')}</ul>
  </section>
  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('bCustom')}</h2><button class="btn ghost small-btn" id="b-custom-add" type="button">${t('bCustomAdd')}</button></div>
    <ul class="b-list" id="b-custom">${customs.map(customRow).join('')}</ul>
  </section>
  <section class="cl-card">
    <div class="cl-card-h"><h2>Scan-to-Plan</h2></div>
    <p class="muted small">${t('bScanText')}</p>
    <label class="btn ghost file-btn"><input id="b-scan" type="file" accept="${ACCEPT}"><span>${t('fileChoose')}</span></label>
    <p class="muted" id="b-scan-status" role="status"></p>
  </section>
  <section class="cl-card">
    <div class="cl-card-h"><h2>${t('clDays')}</h2></div>
    <div class="choice" id="b-days">${days.map((d, i) => `<label><input type="checkbox" value="${i + 1}" ${planDays.includes(i + 1) ? 'checked' : ''}><span>${d}</span></label>`).join('')}</div>
    <label class="fl" for="b-note">${t('clPlanNote')}</label>
    <textarea id="b-note" rows="3" placeholder="${t('clPlanNotePh')}">${esc(noteText)}</textarea>
  </section>
  <div class="start-row"><button class="btn primary" id="b-save" type="button">${t('bSend')}</button><span class="notice" id="b-err" hidden></span></div>`;

  const bindRows = () => root.querySelectorAll('.b-row input[type=checkbox]').forEach((cb) => {
    if (cb.dataset.bound) return;
    cb.dataset.bound = '1';
    cb.addEventListener('change', () => cb.closest('.b-row').classList.toggle('on', cb.checked));
  });
  bindRows();

  // ── AI predlog: pregled i odluka za svaku vežbu ──
  const reviewItems = () => (builderAi ? toPlanItems(builderAi) : []);
  const progItems = () => (builderAi ? programFor(builderAi).items || [] : []);
  const rowFor = (it) => (it.custom ? root.querySelector(`#b-custom .b-row[data-cid="${it.exId}"]`) : root.querySelector(`#b-lib .b-row[data-ex="${it.exId}"]`));

  // stavku iz AI predloga upiši u plan (vežba iz biblioteke se uključi, vežba bez kamere se doda)
  const applyItem = (it) => {
    if (it.custom) {
      let li = rowFor(it);
      if (!li) { root.querySelector('#b-custom').insertAdjacentHTML('beforeend', customRow(it)); li = rowFor(it); bindRows(); }
      li.classList.add('on'); li.querySelector('input[type=checkbox]').checked = true;
      return li;
    }
    const li = rowFor(it);
    if (!li) return null;
    if (it.noteI18n) libNoteI18n.set(it.exId, it.noteI18n); else libNoteI18n.delete(it.exId);
    li.classList.add('on'); li.querySelector('input[type=checkbox]').checked = true;
    li.querySelector('.b-sets').value = it.sets; li.querySelector('.b-reps').value = it.reps;
    li.querySelector('.b-side').value = it.side;
    li.querySelector('.b-romt').value = it.romTarget || '';
    li.querySelector('.b-rom').value = it.romMax || '';
    li.querySelector('.b-note').value = itemNote(it);
    return li;
  };
  const removeItem = (it) => {
    const li = rowFor(it);
    if (!li) return;
    if (it.custom) li.remove();
    else { li.classList.remove('on', 'ai-approved', 'ai-edited'); li.querySelector('input[type=checkbox]').checked = false; }
  };
  const applySchedule = () => {
    const prog = programFor(builderAi);
    if (prog.days && prog.days.length) root.querySelectorAll('#b-days input').forEach((cb) => { cb.checked = prog.days.includes(Number(cb.value)); });
    planNoteI18n = aiPlanNotes(builderAi);
    root.querySelector('#b-note').value = aiPlanNote(builderAi);
  };

  const statusPill = (s) => `<span class="rv-st rv-${s}">${t('rv_' + s)}</span>`;
  const renderReview = () => {
    const out = root.querySelector('#ai-out');
    if (!builderAi) { out.innerHTML = ''; return; }
    const items = reviewItems(), prog = progItems();
    const pending = aiReview.filter((s) => s === 'pending').length + (scheduleReview === 'pending' ? 1 : 0);
    const cnt = (s) => aiReview.filter((x) => x === s).length;
    const p0 = programFor(builderAi);
    out.innerHTML = renderResult(builderAi, { program: false }) + `
      <section class="review" id="ai-review">
        <div class="cl-card-h"><h3>${t('rvTitle')}</h3>
          ${pending ? `<button class="btn primary small-btn" type="button" data-rv-all>${t('rvApproveAll')}</button>` : `<span class="ok-text">✓ ${t('rvDone')}</span>`}</div>
        <p class="muted small">${t('rvIntro')}</p>
        <p class="small"><strong>${t('rvCount', { a: cnt('approved'), e: cnt('edited'), r: cnt('rejected'), p: pending })}</strong></p>
        <ol class="rv-list">
          ${items.map((it, i) => {
            const src = prog[i] || {};
            const s = aiReview[i] || 'pending';
            const dose = `${it.sets} × ${it.reps}${it.custom && it.custom.holdSec ? ` × ${it.custom.holdSec} s` : ''}`;
            const extra = `${it.side && it.side !== 'both' ? ' · ' + t('side_' + it.side) : ''}${it.romTarget ? ' · ' + t('aiRomTarget', { v: it.romTarget }) : ''}${it.romMax ? ' · ' + t('aiRomMax', { v: it.romMax }) : ''}`;
            const steps = it.custom ? customField(it, 'instructions') || [] : [];
            return `<li class="rv-item rv-${s}">
              <div class="rv-h"><strong>${esc(itemName(it))}</strong><span class="tag ${it.custom ? '' : 'cam'}">${it.custom ? t('aiNoCam') : t('aiCam')}</span>${statusPill(s)}</div>
              <div class="ai-dose">${dose}${extra}</div>
              ${src.reason ? `<p class="muted small">${esc(src.reason)}</p>` : ''}
              ${steps.length ? `<details><summary>${t('aiHow')}</summary><ol>${steps.map((x) => `<li>${esc(x)}</li>`).join('')}</ol></details>` : ''}
              <div class="rv-btns">
                <button type="button" class="btn small-btn ${s === 'approved' ? 'primary' : 'ghost'}" data-rv="approve" data-i="${i}">✓ ${t('rvApprove')}</button>
                <button type="button" class="btn small-btn ${s === 'edited' ? 'primary' : 'ghost'}" data-rv="edit" data-i="${i}">✎ ${t('rvEdit')}</button>
                <button type="button" class="btn small-btn ${s === 'rejected' ? 'danger-btn' : 'ghost'}" data-rv="reject" data-i="${i}">✕ ${t('rvReject')}</button>
              </div>
            </li>`;
          }).join('')}
          <li class="rv-item rv-${scheduleReview || 'pending'}">
            <div class="rv-h"><strong>${t('rvSchedule')}</strong>${statusPill(scheduleReview || 'pending')}</div>
            <p class="small">${(p0.days || []).map((d) => t('weekdays')[d - 1]).join(', ') || '–'}</p>
            <p class="muted small pre">${esc(aiPlanNote(builderAi))}</p>
            <div class="rv-btns">
              <button type="button" class="btn small-btn ${scheduleReview === 'approved' ? 'primary' : 'ghost'}" data-rv="approve" data-i="s">✓ ${t('rvApprove')}</button>
              <button type="button" class="btn small-btn ${scheduleReview === 'edited' ? 'primary' : 'ghost'}" data-rv="edit" data-i="s">✎ ${t('rvEdit')}</button>
              <button type="button" class="btn small-btn ${scheduleReview === 'rejected' ? 'danger-btn' : 'ghost'}" data-rv="reject" data-i="s">✕ ${t('rvReject')}</button>
            </div>
          </li>
        </ol>
      </section>`;
  };
  const decide = (i, action) => {
    const status = { approve: 'approved', edit: 'edited', reject: 'rejected' }[action];
    if (i === 's') {
      scheduleReview = status;
      if (action === 'reject') { /* zadrži postojeći raspored i napomenu */ } else applySchedule();
      if (action === 'edit') { const n = root.querySelector('#b-note'); n.scrollIntoView({ behavior: 'smooth', block: 'center' }); n.focus(); }
      renderReview();
      return;
    }
    const it = reviewItems()[i];
    aiReview[i] = status;
    if (action === 'reject') removeItem(it);
    else {
      const li = applyItem(it);
      if (li) {
        li.classList.toggle('ai-approved', action === 'approve');
        li.classList.toggle('ai-edited', action === 'edit');
        if (action === 'edit') {
          li.scrollIntoView({ behavior: 'smooth', block: 'center' });
          const f = li.querySelector(it.custom ? '.c-name' : '.b-sets'); if (f) f.focus();
        }
      }
    }
    renderReview();
  };
  root.querySelector('#ai-out').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.hasAttribute('data-rv-all')) {
      reviewItems().forEach((it, i) => { if (aiReview[i] === 'pending') { aiReview[i] = 'approved'; const li = applyItem(it); if (li) li.classList.add('ai-approved'); } });
      if (scheduleReview === 'pending') { scheduleReview = 'approved'; applySchedule(); }
      renderReview();
      return;
    }
    if (b.dataset.rv) decide(b.dataset.i === 's' ? 's' : Number(b.dataset.i), b.dataset.rv);
  });
  renderReview();

  // ── AI ──
  aiStatus('therapist').then((ok) => { root.querySelector('#ai-key').hidden = ok; });
  root.querySelector('#ai-key-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = root.querySelector('#ai-key-msg');
    try { await saveKey(root.querySelector('#ai-key-in').value); root.querySelector('#ai-key').hidden = true; }
    catch { msg.textContent = t('aiKeyBad'); }
  });
  // izveštaj iz fajla: tekst (PDF/Word/txt) ide u polje, a slika ili skenirani PDF ide AI-ju kao fajl
  let aiFile = null;
  const onAiFile = async (file) => {
    aiFile = null;
    const info = root.querySelector('#ai-file-name');
    if (!file) { info.textContent = ''; return; }
    info.textContent = t('fileReading', { name: file.name || '' });
    try {
      const r = await readReport(file);
      if (r.scanned) { aiFile = file; info.textContent = r.kind === 'image' ? (file.name || '') : t('fileScanned', { name: file.name }); }
      else { root.querySelector('#ai-text').value = r.text; info.textContent = t('fileRead', { name: file.name }); }
    } catch (e) { info.textContent = e.code === 'too_big' ? t('fileTooBig') : e.code === 'doc' ? t('fileDoc') : t('fileUnsupported'); }
  };
  root.querySelector('#ai-file').addEventListener('change', (e) => onAiFile(e.target.files && e.target.files[0]));
  root.querySelector('#ai-cam').addEventListener('change', (e) => onAiFile(e.target.files && e.target.files[0]));
  root.querySelector('#ai-run').addEventListener('click', async () => {
    const text = root.querySelector('#ai-text').value.trim();
    const st = root.querySelector('#ai-status');
    const btn = root.querySelector('#ai-run');
    if (!text && !aiFile) { st.textContent = t('aiNeedInput'); return; }
    btn.disabled = true;
    st.textContent = t('aiRunning', { s: 0 });
    try {
      const result = await generate({ role: 'therapist', text, file: aiFile, onTick: (s) => { st.textContent = t('aiRunning', { s }); } });
      // ukloni neodlučene stavke prethodnog AI predloga, pa prikaži novi predlog na pregled
      if (builderAi) reviewItems().forEach((it, i) => { if (aiReview[i] === 'pending') removeItem(it); });
      builderAi = result;
      aiReview = toPlanItems(result).map(() => 'pending');
      scheduleReview = 'pending';
      renderReview();
      st.textContent = t('rvReady');
      root.querySelector('#ai-review').scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) {
      st.textContent = errorText(e);
      if (e.code === 'no_key' || e.code === 'bad_key') root.querySelector('#ai-key').hidden = false;
    } finally { btn.disabled = false; }
  });

  // ── vežbe bez kamere ──
  root.querySelector('#b-custom-add').addEventListener('click', () => {
    root.querySelector('#b-custom').insertAdjacentHTML('beforeend', customRow({ exId: 'custom-' + Date.now().toString(36), sets: 2, reps: 10, custom: { name: '', instructions: [], holdSec: 0 } }));
    bindRows();
  });

  // ── Scan-to-Plan (prepoznavanje naziva vežbi sa papira, bez AI) ──
  root.querySelector('#b-scan').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const st = root.querySelector('#b-scan-status');
    st.textContent = t('scLoadingOcr');
    try {
      const r = await readReport(file);
      const text = r.scanned
        ? await recognize(file, (pr) => { st.textContent = t('scReading', { p: Math.round(pr * 100) }); })
        : r.text;
      const items = parsePlan(text);
      for (const it of items) {
        const li = root.querySelector(`#b-lib .b-row[data-ex="${it.exId}"]`);
        if (!li) continue;
        li.classList.add('on', 'scanned'); li.querySelector('input[type=checkbox]').checked = true;
        if (it.sets) li.querySelector('.b-sets').value = it.sets;
        if (it.reps) li.querySelector('.b-reps').value = it.reps;
      }
      st.textContent = items.length ? t('bScanFound', { n: items.length }) : t('bScanNone');
    } catch { st.textContent = t('scOcrFail'); }
  });

  // ── čuvanje: tek kada je svaki AI predlog odobren, izmenjen ili odbijen ──
  root.querySelector('#b-save').addEventListener('click', async () => {
    const err = root.querySelector('#b-err');
    const pending = aiReview.filter((s) => s === 'pending').length + (scheduleReview === 'pending' ? 1 : 0);
    if (builderAi && pending) {
      err.hidden = false; err.textContent = t('rvPendingErr', { n: pending });
      root.querySelector('#ai-review').scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }
    const d = collectBuilder();
    if (!d.items.length) { err.hidden = false; err.textContent = t('bNoItems'); return; }
    const cnt = (s) => aiReview.filter((x) => x === s).length;
    const approval = {
      by: cache.me.name, at: Date.now(), ai: !!builderAi,
      approved: cnt('approved'), edited: cnt('edited'), rejected: cnt('rejected'),
    };
    await api.put('therapist', 'plan', { patientId: p.id, version: (plan ? plan.version || 0 : 0) + 1, status: 'active', ...d, approval });
    if (prefill && prefill.proposalId) {
      const pr = cache.g.proposal.find((x) => x.id === prefill.proposalId);
      if (pr) await api.put('therapist', 'proposal', { ...pr, status: 'approved', decidedAt: Date.now() });
    }
    sessionStorage.removeItem('fizio-prefill');
    builderAi = null; builderPatient = null; aiReview = []; scheduleReview = null;
    location.hash = 'klinika-p-' + p.id;
  });
}
