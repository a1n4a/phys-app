// Brojanje ponavljanja i praćenje grešaka za jednu vežbu.

const ERROR_FRAMES = 6;       // greška mora da traje bar ~0,2 s pre upozorenja (filtrira šum)
const REP_ERROR_FRAMES = 10;  // a bar ~0,35 s da bi ponavljanje bilo označeno kao nepravilno
const MIN_REP_MS = 600;

export class RepEngine {
  // tol: dozvoljeno odstupanje (0.1 = 10 %). Cilj pokreta se prihvata i ako je dostignut
  // (1 - tol) deo ciljnog ugla.
  constructor(ex, tol = 0) {
    this.ex = ex;
    this.tol = tol;
    this.target = Math.max(ex.start + 2, ex.target * (1 - tol));
    this.phase = 'rest';         // rest | moving
    this.reps = 0;
    this.good = 0;
    this.partials = 0;
    this.peak = 0;
    this.reached = false;
    this.holdStart = null;
    this.holdProgress = 0;
    this.repErrors = new Set();
    this.errFrames = {};
    this.errTotals = {};         // id -> {msg, count}
    this.lastRepAt = 0;
    this.romPeaks = [];          // najveći ugao u svakom ponavljanju (za izveštaj o pokretljivosti)
  }

  // Vraća događaje: {type:'rep', good, n, errors} | {type:'partial'} | {type:'held'} | {type:'newError', err}
  update(value, errors, now) {
    const ex = this.ex;
    const events = [];

    // greške: računaju se tek kad traju nekoliko uzastopnih kadrova
    const present = new Set(errors.map((e) => e.id));
    const active = [];
    for (const e of errors) {
      const n = (this.errFrames[e.id] || 0) + 1;
      this.errFrames[e.id] = n;
      if (n >= ERROR_FRAMES) {
        active.push(e);
        if (n === ERROR_FRAMES) events.push({ type: 'newError', err: e });
        if (n >= REP_ERROR_FRAMES && this.phase === 'moving' && !this.repErrors.has(e.id)) {
          this.repErrors.add(e.id);
          this.errTotals[e.id] = this.errTotals[e.id] || { msg: e.msg, count: 0 };
        }
      }
    }
    for (const id of Object.keys(this.errFrames)) if (!present.has(id)) this.errFrames[id] = 0;

    // faze ponavljanja
    if (this.phase === 'rest') {
      if (value > ex.start && now - this.lastRepAt > 250) {
        this.phase = 'moving';
        this.peak = value;
        this.reached = false;
        this.holdStart = null;
        this.holdProgress = 0;
        const lasting = active.filter((e) => this.errFrames[e.id] >= REP_ERROR_FRAMES);
        this.repErrors = new Set(lasting.map((e) => e.id));
        for (const e of lasting) this.errTotals[e.id] = this.errTotals[e.id] || { msg: e.msg, count: 0 };
      }
    } else {
      this.peak = Math.max(this.peak, value);
      if (!this.reached) {
        if (value >= this.target) {
          if (ex.hold > 0) {
            if (this.holdStart == null) this.holdStart = now;
            this.holdProgress = Math.min(1, (now - this.holdStart) / (ex.hold * 1000));
            if (this.holdProgress >= 1) { this.reached = true; events.push({ type: 'held' }); }
          } else {
            this.reached = true;
          }
        } else if (this.holdStart != null && value < this.target - 3) {
          this.holdStart = null;
          this.holdProgress = 0;
        }
      }
      if (value < ex.start) {
        this.phase = 'rest';
        this.holdProgress = 0;
        if (this.reached && now - this.lastRepAt > MIN_REP_MS) {
          this.reps++;
          const ok = this.repErrors.size === 0;
          if (ok) this.good++;
          for (const id of this.repErrors) if (this.errTotals[id]) this.errTotals[id].count++;
          this.lastRepAt = now;
          this.romPeaks.push(Math.round(this.peak));
          events.push({ type: 'rep', good: ok, n: this.reps, errors: [...this.repErrors], nearTarget: this.peak < ex.target });
        } else if (!this.reached && this.peak > ex.start + (this.target - ex.start) * 0.4) {
          this.partials++;
          events.push({ type: 'partial', held: ex.hold > 0 && this.peak >= this.target });
        }
      }
    }
    return { events, active };
  }

  topErrors() {
    return Object.entries(this.errTotals)
      .filter(([, v]) => v.count > 0)
      .sort((a, b) => b[1].count - a[1].count)
      .map(([id, v]) => ({ id, ...v }));
  }
}
